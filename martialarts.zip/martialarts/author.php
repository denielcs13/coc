<?php

/**

 * The template for displaying Author pages.

 *

 */

get_header();

?>

<!-- Single Post Starts -->

<div class="blogpost-wrapper">
  <div class="container">
    <div class="row">
      <div class="blogpost-content">
        <article class="col-md-9"> 
          
          <!-- Post loop starts -->
          
          <div class="post-page">
            <?php if (have_posts()) : the_post(); ?>
            <h4><?php printf(AUTHOR_ARCHIVES,

                                "<a class='url fn n' href='" . get_author_posts_url(get_the_author_meta('ID')) . "' title='" . esc_attr(get_the_author()) . "' rel='me'>" . get_the_author() . "</a>"); ?></h4>
            <?php


                            if (get_the_author_meta('description')) :

                                ?>
            <?php echo get_avatar(get_the_author_meta('user_email'),

                apply_filters('twentyten_author_bio_avatar_size',

                        60)); ?>
            <h5 class="auth-title"><?php printf(ABOUT_AUTHOR,

                                get_the_author()); ?></h5>
            <p class="auth-desc">
              <?php the_author_meta('description'); ?>
            </p>
            <?php endif; ?>
          </div>
          <?php

                        rewind_posts();


                        get_template_part('loop',

                                'author');

                        ?>
          <?php endif; ?>
          
          <!-- Post loop ends -->
          
          <div class="clearfix"></div>
          <nav id="nav-single"> <span class="nav-previous">
            <?php next_posts_link(OLDER_POSTS); ?>
            </span> <span class="nav-next">
            <?php previous_posts_link(NEWER_POSTS); ?>
            </span> </nav>
          <div class="clearfix"></div>
        </article>
        <aside class="col-md-3"> 
          
          <!-- Sidebar Starts -->
          
          <?php get_sidebar(); ?>
          
          <!-- Sidebar Ends --> 
          
        </aside>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
