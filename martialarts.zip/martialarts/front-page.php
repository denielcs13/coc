<style>
.pmpro_checkout table th{
	font-weight:700;
}	
</style>
<?php
/**
* The main template file.
*
* This is the most generic template file in a WordPress theme
* and one of the two required files for a theme (the other being style.css).
* It is used to display a page when nothing more specific matches a query. 
* E.g., it puts together the home page when no home.php file exists.
* Learn more: http://codex.wordpress.org/Template_Hierarchy
*
*/
?>
<?php get_header(); ?>


  
  
  <!--*** About and Services section End ***-->
  
  <div class="clearfix"></div>
  
  <!-- Recent Closing End --> 
  <div class="main-content">
  <div class="container">
  <div class="row">


  <div class="col-md-8">
<div class="black-sec">
	<h2><?php echo layout_get_option('layout_metro_main_heading'); ?></h2>
<div class="metro-content">
<h3><?php echo layout_get_option('layout_heading_metro_open'); ?></h3>

<img src="<?php echo layout_get_option('layout_upload_metro_image'); ?>" alt="" class="alignleft" />
<p><?php echo layout_get_option('layout_metro_open'); ?><strong><a href="<?php echo layout_get_option('layout_btn_metro_open_link'); ?>" target="_blank"><?php echo layout_get_option('layout_btn_metro_open'); ?></a></strong></p>

</div>


	<h3><?php echo layout_get_option('layout_heading_main'); ?></h3> 

<table border="0" width="419" cellspacing="1" cellpadding="5" class="table table-dark  table-bordered">
<tbody>
<tr>
<td align="left" bgcolor="eeeeee" width="87" height="36"><b>Event Date</b></td>
<td bgcolor="f7f7f7" width="309"><b><?php echo layout_get_option('layout_event_date'); ?></b></td>
</tr>
<tr>
<td align="left" bgcolor="#FFFFFF" height="34"><b>Event Title</b></td>
<td bgcolor="#FFFFFF"><b><span style="color: #ff6600;"><?php echo layout_get_option('layout_event_title'); ?></span></b></td>
</tr>
<tr>
<td align="left" valign="top" bgcolor="eeeeee" height="40"><b>Hosted by</b></td>
<td valign="top" bgcolor="f7f7f7"><?php echo layout_get_option('layout_event_hosted'); ?></td>
</tr>
<tr>
<td align="left" valign="top" bgcolor="eeeeee" height="40"><b>Where</b></td>
<td valign="top" bgcolor="f7f7f7"><?php echo layout_get_option('layout_event_location'); ?><a href="<?php echo layout_get_option('layout_event_location_map_text_link'); ?>" target="_blank">
	<?php echo layout_get_option('layout_event_location_map_text'); ?>
</a></td>
</tr>
<tr>
<td align="left" bgcolor="#FFFFFF" height="31"><b>Phone</b></td>
<td bgcolor="#FFFFFF"><?php echo layout_get_option('layout_event_phone'); ?></td>
</tr>
<tr>
<td align="left" bgcolor="eeeeee" height="36"><b>Website</b></td>
<td bgcolor="f7f7f7"><a style="color: black;" href="<?php echo layout_get_option('layout_event_web'); ?>" target="_blank"><?php echo layout_get_option('layout_event_web'); ?></a></td>
</tr>
<tr>
<td align="left" bgcolor="#FFFFFF" height="37"><b>Email</b></td>
<td bgcolor="#FFFFFF"><a style="color: black;" href="mailto:<?php echo layout_get_option('layout_event_email'); ?>"><?php echo layout_get_option('layout_event_email'); ?></a></td>
</tr>
<tr>
<td align="left" valign="top" bgcolor="#FFFFFF" height="40"><b>Mail All Registration<br>
Forms to</b></td>
<td valign="top" bgcolor="#FFFFFF"><?php echo layout_get_option('layout_event_forms_regis'); ?></td>
</tr>
<tr>
<td align="left" valign="top" bgcolor="#FFFFFF" height="76"><b>Tournament General Admission</b></td>
<td valign="top" bgcolor="#FFFFFF"><?php echo layout_get_option('layout_event_tournament_adm'); ?></td>
</tr>
<tr>
<td align="left" valign="top" bgcolor="#EEEEEE" height="52"><b>Download Registration Forms (.pdf)</b></td>
<td align="left" bgcolor="#F7F7F7"><a style="color: black;" href="<?php echo layout_get_option('layout_competitor_url'); ?>" target="_blank"><b><?php echo layout_get_option('layout_competitor_text'); ?></b></a> | <a style="color: black;" href="<?php echo layout_get_option('layout_coach_url'); ?>" target="_blank"><b><?php echo layout_get_option('layout_coach_text'); ?></b></a> | <a style="color: black;" href="<?php echo layout_get_option('layout_program_url'); ?>" target="_blank"><b><?php echo layout_get_option('layout_program_text'); ?></b></a></td>
</tr>
</tbody>
</table>



  <?php 
//global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $pmpro_currency_symbol;
global $wpdb, $pmpro_msg, $pmpro_msgt, $current_user;

$pmpro_levels = pmpro_getAllLevels(false, true);
$pmpro_level_order = pmpro_getOption('level_order');

if(!empty($pmpro_level_order))
{
	$order = explode(',',$pmpro_level_order);

	//reorder array
	$reordered_levels = array();
	foreach($order as $level_id) {
		foreach($pmpro_levels as $key=>$level) {
			if($level_id == $level->id)
				$reordered_levels[] = $pmpro_levels[$key];
		}
	}

	$pmpro_levels = $reordered_levels;
}

$pmpro_levels = apply_filters("pmpro_levels_array", $pmpro_levels);
if($pmpro_msg)
{
?>
<div class="pmpro_message <?php echo $pmpro_msgt?>"><?php echo $pmpro_msg?></div>
<?php
}
?>
<table id="pmpro_levels_table" class="pmpro_checkout table table-bordered table-striped" style="width:100%">
<thead>
  <tr>
	<th><strong><?php _e('Registration Level', 'pmpro');?></strong></th>
	<th><strong><?php _e('Price', 'pmpro');?></strong></th>	
	<th>&nbsp;</th>
  </tr>
</thead>
<tbody>
	<?php
	/* $x = array_reverse($pmpro_levels,true);
    $y = array_reverse($pmpro_levels); */
    //echo '<pre>';print_r($y);echo '</pre>';die;	
	$count = 0;
	
	foreach($pmpro_levels as $level)
	{
	  if(isset($current_user->membership_level->ID))
		  $current_level = ($current_user->membership_level->ID == $level->id);
	  else
		  $current_level = false;
	?>
	<tr class="<?php if($count++ % 2 == 0) { ?>odd<?php } ?><?php if($current_level == $level) { ?> active<?php } ?>">
		<td><?php echo $current_level ? "<strong>{$level->name}</strong>" : $level->name?></td>
		<td>
			<?php 
				if(pmpro_isLevelFree($level))
					$cost_text = "<strong>Free</strong>";
				else
					$cost_text = pmpro_getLevelCost($level, true, true); 
				$expiration_text = pmpro_getLevelExpiration($level);
				if(!empty($cost_text) && !empty($expiration_text))
					echo $cost_text . "<br />" . $expiration_text;
				elseif(!empty($cost_text))
					echo $cost_text;
				elseif(!empty($expiration_text))
					echo $expiration_text;
			?>
		</td>
		<td>
		<?php if(empty($current_user->membership_level->ID)) { ?>
			<a class="pmpro_btn pmpro_btn-select" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https")?>"><?php _e('Select', 'pmpro');?></a>
		<?php } elseif ( !$current_level ) { ?>                	
			<a class="pmpro_btn pmpro_btn-select" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https")?>"><?php _e('Select', 'pmpro');?></a>
		<?php } elseif($current_level) { ?>      
			
			<?php
				//if it's a one-time-payment level, offer a link to renew				
				if(!pmpro_isLevelRecurring($current_user->membership_level))
				{
				?>
					<a class="pmpro_btn pmpro_btn-select" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https")?>"><?php _e('Renew', 'pmpro');?></a>
				<?php
				}
				else
				{
				?>
					<a class="pmpro_btn disabled" href="<?php echo pmpro_url("account")?>"><?php _e('Your&nbsp;Level', 'pmpro');?></a>
				<?php
				}
			?>
			
		<?php } ?>
		</td>
	</tr>
	<?php
	}
	?>
</tbody>
</table>

<div class="ads">
	<a href="<?php echo layout_get_option('layout_ad_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('layout_ad_image'); ?>" /></a>

</div>


  </div></div>

  <div class="col-12 col-sm-12 col-md-4 col-lg-4">
  	<?php get_sidebar(); ?>
  </div>


  </div>
 </div>
 </div>



<?php get_footer(); ?>
