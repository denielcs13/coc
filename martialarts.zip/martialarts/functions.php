<?php

$functions_path = get_template_directory() . '/functions/';
include_once get_template_directory() . '/functions/layout-functions.php';
/* These files build out the options interface.  Likely won't need to edit these. */
require_once ($functions_path . 'admin-functions.php');  // Custom functions and plugins
require_once ($functions_path . 'admin-interface.php');  // Admin Interfaces 
require_once ($functions_path . 'define_template.php'); // language
require_once ($functions_path . 'theme-options.php');   // Options panel settings and custom settings
require_once ($functions_path . 'dynamic-image.php');

/* ----------------------------------------------------------------------------------- */
/* Styles Enqueue */
/* ----------------------------------------------------------------------------------- */
/* jQuery Enqueue */
/* ----------------------------------------------------------------------------------- */

function layout_wp_enqueue_scripts() {
    if (!is_admin()) {
		
        wp_enqueue_script('layout-modernize', get_template_directory_uri() . '/js/modernizr.min.js', array('jquery'));
     
		
    } elseif (is_admin()) {
        
    }
}

add_action('wp_enqueue_scripts', 'layout_wp_enqueue_scripts');
/* ----------------------------------------------------------------------------------- */
/* Custom Jqueries Enqueue */
/* ----------------------------------------------------------------------------------- */

function layout_custom_jquery() {
        wp_enqueue_script('layout-bootstrap', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array('jquery')); 
		   wp_enqueue_script('layout-slider', get_template_directory_uri() . '/js/jquery.flexslider.js', array('jquery'));
        wp_enqueue_script('layout-imageloaded', get_template_directory_uri() . '/js/jquery.imagesloaded.js', array('jquery'));
        wp_enqueue_script('layout-custom', get_template_directory_uri() . '/js/custom.js', array('jquery'));
}

add_action('wp_footer', 'layout_custom_jquery');

/* ----------------------------------------------------------------------------------- */
/* Styles Enqueue */
/* ----------------------------------------------------------------------------------- */

function layout_add_stylesheet() {
    if (layout_get_option('layout_altstylesheet') != 'red') {
        
    }   
}

add_action('init', 'layout_add_stylesheet');

//Front Page Rename
$get_status = layout_get_option('re_nm');
$get_file_ac = get_template_directory() . '/front-page.php';
//True Part
if ($get_status === 'off' && file_exists($get_file_ac)) {
    rename("$get_file_ac", "$get_file_dl");
}
//False Part
if ($get_status === 'on' && file_exists($get_file_dl)) {
    rename("$get_file_dl", "$get_file_ac");
}

function layout_get_option($name) {
    $options = get_option('layout_options');
    if (isset($options[$name]))
        return $options[$name];
}

//
function layout_update_option($name, $value) {
    $options = get_option('layout_options');
    $options[$name] = $value;
    return update_option('layout_options', $options);
}

//
function layout_delete_option($name) {
    $options = get_option('layout_options');
    unset($options[$name]);
    return update_option('layout_options', $options);
}

//Enqueue comment thread js
function layout_enqueue_scripts() {
    if (is_singular() and get_site_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}

add_action('wp_enqueue_scripts', 'layout_enqueue_scripts');
add_theme_support('custom-background');

// comment form placeholder

add_filter( 'comment_form_default_fields', 'layout_comment_placeholders' );

/**
 * Change default fields, add placeholder and change type attributes.
 *
 * @param  array $fields
 * @return array
 */
function layout_comment_placeholders( $fields )
{
    $fields['author'] = str_replace(
        '<input',
        '<input placeholder="'
        /* Replace 'theme_text_domain' with your theme’s text domain.
         * I use _x() here to make your translators life easier. :)
         * See http://codex.wordpress.org/Function_Reference/_x
         */
            . _x(
                'Name',
                'comment form placeholder',
                'layout'
                )
            . '"',
        $fields['author']
    );
    $fields['email'] = str_replace(
        '<input id="email" name="email" type="text"',
        /* We use a proper type attribute to make use of the browser’s
         * validation, and to get the matching keyboard on smartphones.
         */
        '<input type="email" placeholder="contact@example.com"  id="email" name="email"',
        $fields['email']
    );
    $fields['url'] = str_replace(
        '<input id="url" name="url" type="text"',
        // Again: a better 'type' attribute value.
        '<input placeholder="http://example.com" id="url" name="url" type="url"',
        $fields['url']
    );
	

    return $fields;
}

// placeholder to textarea
function layout_comment_textarea_field($comment_field) {
 
    $comment_field = 
        '<p class="comment-form-comment">
            <textarea required placeholder="Enter Your Comment…" id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea>
        </p>';
 
    return $comment_field;
}
add_filter('comment_form_field_comment','layout_comment_textarea_field');
//comment text
function stefan_wrap_comment_text($content) {
    return "<div class=\"comment-text\"><a class='commenttext-arrow'></a>". $content ."</div>";
}
add_filter('comment_text', 'stefan_wrap_comment_text');

function breadcrum_block(){
 ?>
 <div class="breadcrum-wrapper" <?php if (layout_get_option('layout_headbg') != '') { ?>
 style="background: url(<?php echo layout_get_option('layout_headbg'); ?>) no-repeat center;"
 <?php } else {} ?>>
	<div class="container">
		<div class="row">
			<div class="breadcrum-inner">
				<div class="col-md-12">
					<div class="breadcrum clearfix">
						<h4><?php if (function_exists('layout_breadcrumbs')) layout_breadcrumbs(); ?></h4>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
 <?php
}


//====cleanupwp==========//
add_action('admin_menu','wphidenag');
function wphidenag() {
remove_action( 'admin_notices', 'update_nag', 3 );
}


function themeslug_theme_customizer( $wp_customize ) {
    // Fun code will go here
}
add_action( 'customize_register', 'themeslug_theme_customizer' );

function my_login_logo() { 
$logo = layout_get_option('layout_logo');

?>
    <style type="text/css">
        body.login div#login h1 a {
            background-image: url(<?php echo $logo ?>);
            padding-bottom: 0px;
			background-size: auto;
			width: auto;
			height: 100px;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo' );

function my_login_logo_url() {
    return get_bloginfo( 'url' );
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return get_bloginfo( 'description' );
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );


add_action( 'admin_bar_menu', 'remove_wp_logo', 999 );

function remove_wp_logo( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
}

//======footer copy right============//

function remove_footer_admin () {
    //echo 'Copyright - 2016 | <a href="" target="_blank">Developed by</a>';
    ?>
	<p>&#169; <?php echo date("Y") ?> <?php bloginfo( 'name' ); ?>. All rights reserved.
	<?php
	}

    add_filter('admin_footer_text', 'remove_footer_admin'); 
	
add_filter( 'update_footer',     '__return_empty_string', 11 );




	
//======theme editor============//	
$role_object = get_role( 'editor' );
$role_object->add_cap( 'edit_theme_options' );

	
add_filter('admin_title', 'my_admin_title', 10, 2);

function my_admin_title($admin_title, $title)
{
    return get_bloginfo('name').' &#8212; '.$title;
}

//======excerpt[...]========//
function new_excerpt_more( $more ) {
    return '';
}
add_filter('excerpt_more', 'new_excerpt_more');



// REMOVE WP EMOJI
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

remove_action('wp_head', 'wp_generator');

// Remove WP Version From Styles	
add_filter( 'style_loader_src', 'sdt_remove_ver_css_js', 9999 );
// Remove WP Version From Scripts
add_filter( 'script_loader_src', 'sdt_remove_ver_css_js', 9999 );

// Function to remove version numbers
function sdt_remove_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}

add_filter( 'feed_links_show_comments_feed', '__return_false' );

remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'feed_links', 2 );  

/**
* Dequeue jQuery Migrate script in WordPress.
*/
function isa_remove_jquery_migrate( &$scripts) {
    if(!is_admin()) {
        $scripts->remove( 'jquery');
        $scripts->add( 'jquery', false, array( 'jquery-core' ), '1.12.4' );
    }
}
add_filter( 'wp_default_scripts', 'isa_remove_jquery_migrate' );

remove_action( 'wp_head', 'wlwmanifest_link');
remove_action( 'wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rsd_link'); //removes EditURI/RSD (Really Simple Discovery) link.

remove_action('template_redirect', 'rest_output_link_header', 11, 0);
remove_action('wp_head', 'rest_output_link_wp_head', 10);

remove_action('wp_head', 'wp_resource_hints', 2);

/*----cbi plugin related function------*/

function csvinsertdb (){
	$upload_dir = wp_upload_dir();
	$basedir = $upload_dir['basedir'];
	$baseurl = $upload_dir['baseurl'];
	
	//$uploadDir = $basedir.'/send/';
	$uploadDir = $basedir.'/send/suretyclaims/';
	//$moveuploadDir = $basedir.'/processed/';
	//$moveuploadDirnotmatch = $basedir.'/nomatch/';
	
	
	$files = glob("$uploadDir/*.csv");
	//echo "Dinesh---".$files;
	
	if($files != null && $files != ""){
		foreach($files as $file) {

			if (($handle = fopen($file, "r")) !== FALSE) {
				echo "<b>Filename: " . basename($file) . "</b><br><br>";
				$i = 0;
				while (($data2 = fgetcsv($handle, 4096, ",")) !== FALSE) {
					
					
				
					if($i != 0)
					{
						/*
						echo "<pre>";
						var_dump($data2);
						echo "</pre>";
						echo "<hr>";
						exit;
						*/
						global $wpdb;
						
						$table_name = $wpdb->prefix . "csvread"; 
						/*
						$datearrs=explode("/",$data2[12]);
						$tsViolationDate=$datearrs[2].'-'.$datearrs[0].'-'.$datearrs[1];						
						*/
						$effdatearrs=explode("/",$data2[13]);
						$effViolationDate=$effdatearrs[2].'-'.$effdatearrs[0].'-'.$effdatearrs[1];
						$sql = $wpdb->prepare("INSERT INTO `$table_name` (`tsCaseNumber`,`tsBondNumber`,`tsViolatorIRNbr`,`tsViolatorName`,`tsViolationEffDate`,`tsPenaltyAmount`,`status`) 
						values (%s, %s, %s, %s, %s,%s,%d)", $data2[6], $data2[7], $data2[9], $data2[10], $effViolationDate,$data2[18],'0');

						$wpdb->query($sql);						
						
					}
					
					
					
					//echo implode("\t", $data);
				$i++;
				} 
				
				fclose($handle);
			} else {
				echo "Could not open file: " . $file;
			}

		}
	}else {
        echo "No files Found ";
    }

	
}
add_shortcode('csvinsertdb', 'csvinsertdb');	
function csvlisting()
{
	global $wpdb;
	$table_name = $wpdb->prefix . "csvread"; 
	$query = "SELECT * FROM $table_name  order by id DESC "; 	
	$myresult =$wpdb->get_results($query, OBJECT);
	if($myresult)
	{
		$showlist='
			<style>
			.rTable {
					display: table;
					width: 100%;
			}
			.rTableRow {
					display: table-row;
			}
			.rTableHeading {
					display: table-header-group;
					background-color: #ddd;
			}
			.rTableCell, .rTableHead {
					display: table-cell;
					padding: 3px 10px;
					border: 1px solid #999999;
			}
			.rTableHeading {
					display: table-header-group;
					background-color: #ddd;
					font-weight: bold;
			}
			.rTableFoot {
					display: table-footer-group;
					font-weight: bold;
					background-color: #ddd;
			}
			.rTableBody {
					display: table-row-group;
			}
			</style>
			<div class="rTable">
					 <div class="rTableRow">
					 <div class="rTableHead"><strong>tsCaseNumber</strong></div>
					 <div class="rTableHead"><strong>tsBondNumber</strong></div>
					 <div class="rTableHead"><strong>tsViolatorIRNbr</strong></div>
					 <div class="rTableHead"><strong>tsViolatorName</strong></div>
					 <div class="rTableHead"><strong>tsViolationDate</strong></div>	
					<div class="rTableHead"><strong>Action</strong></div>					 
					 </div>';
		foreach($myresult as $rowdata)
		{
			$showlist.='<div class="rTableRow">
						<div class="rTableCell">'.$rowdata->tsCaseNumber.'</div>
						<div class="rTableCell">'.$rowdata->tsBondNumber.'</div>
						<div class="rTableCell">'.$rowdata->tsViolatorIRNbr.'</div>
						<div class="rTableCell">'.$rowdata->tsViolatorName.'</div>
						<div class="rTableCell">'.$rowdata->tsViolationDate.'</div>
						<div class="rTableCell"> <a href="'.esc_url( get_permalink(225) ).'?tsid='.$rowdata->id.'">View</a></div>
						</div>';
		}		 
		$showlist.='</div>';
	}
	
	return $showlist;
}
add_shortcode('csvlisting', 'csvlisting');	

function insurancecommment()
{
		global $wpdb;
		$table_name = $wpdb->prefix . "csvread_comment"; 		
		if($_REQUEST['tsid']!='' && $_REQUEST['tscomment']!=''):
		
			$user = wp_get_current_user();
			$tsuser=$user->ID;			
			$blogtime = date( 'Y-m-d' ); 
			$sql_ts = $wpdb->prepare("INSERT INTO `$table_name` (`tsid`,`tsuserid`,`tscomment`,`tsdate`) 
						values (%s, %s, %s, %s)", $_REQUEST['tsid'], $tsuser, $_POST['tscomment'], $blogtime);						
			$wpdb->query($sql_ts);	
		endif;
		
		$insform='<form name="frmts" method="post" action="">
					<style>
			.rTable {
					display: table;
					width: 100%;
					
					}
			.rTableRow {
					display: table-row;
			}
			.rTableHeading {
					display: table-header-group;
					background-color: #ddd;
			}
			.rTableCell, .rTableHead {
					display: table-cell;
					padding: 3px 10px;
					border: 1px solid #999999;
			}
			.rTableHeading {
					display: table-header-group;
					background-color: #ddd;
					font-weight: bold;
			}
			.rTableFoot {
					display: table-footer-group;
					font-weight: bold;
					background-color: #ddd;
			}
			.rTableBody {
					display: table-row-group;
			}
			</style>';
		if($_REQUEST['tsid']!=''):
			$instable_single = $wpdb->prefix . "csvread"; 
			$query_inssingle = "SELECT * FROM $instable_single  where  id='".$_REQUEST['tsid']."' "; 	
			$result_inssingle =$wpdb->get_results($query_inssingle, OBJECT);
		$insform.='
				 <div class="rTable" style="margin-right:10px;">
				 <div class="rTableRow">
				 <div class="rTableHead"><strong>Case No.</strong></div>
				 <div class="rTableHead"><strong>Bond No.</strong></div>
				 <div class="rTableHead"><strong>ViolatorIRNbr</strong></div>
				 <div class="rTableHead"><strong>Violator Name</strong></div>
				 <div class="rTableHead"><strong>Violation Date</strong></div>									 
				 </div>';
		$insform.='<div class="rTableRow">
				 <div class="rTableCell">'.$result_inssingle[0]->tsCaseNumber.'</div>
				 <div class="rTableCell">'.$result_inssingle[0]->tsBondNumber.'</div>
				<div class="rTableCell">'.$result_inssingle[0]->tsViolatorIRNbr.'</div>
				<div class="rTableCell">'.$result_inssingle[0]->tsViolatorName.'</div>
				<div class="rTableCell">'.$result_inssingle[0]->tsViolationDate.'</div>				
				 </div>';
		$insform.='</div>';
		
		endif;
		$insform.='<br/><table border="0">
				<tr><td valign="top"><strong>Commemt</strong></td><td valign="top"><textarea name="tscomment" rows="4" cols="50" ></textarea></td></tr>
				<tr><td valign="top">&nbsp;</td><td valign="top">
				<input type="submit" name="submit" value="Send Comment" />
				<input type="hidden" name="tsid" value="'.$_REQUEST['tsid'].'" />
				<input type="hidden" name="sendts" value="1" />
				</td>
				</tr>	
				</table>';
		$insform.='</form>';
		
	$table_name1 = $wpdb->prefix . "csvread_comment"; 
	$tscquery = "SELECT * FROM $table_name  order by cid DESC "; 
	
	$result_tsc =$wpdb->get_results($tscquery, OBJECT);
	if($result_tsc)
	{
		$insform.='
		
		<h2>Comments Archive :</h2>
		<div class="rTable">
				 <div class="rTableRow">
				 <div class="rTableHead"><strong>Member</strong></div>
				 <div class="rTableHead"><strong>Comment</strong></div>
				 <div class="rTableHead"><strong>Date</strong></div>
						 
				 </div>';
				 $i=1;
		foreach($result_tsc as $rowdatas)
		{
		$meminfo=get_userdata( $rowdatas->tsuserid );
		$insform.='<div class="rTableRow">
				 <div class="rTableCell">'.$meminfo->first_name.'</div>
				 <div class="rTableCell">'.$rowdatas->tscomment.'</div>
				<div class="rTableCell">'.$rowdatas->tsdate.'</div>
				
				 </div>';
				 $i++;
		}		 
		$insform.='</div>';
	}
			return $insform;
			
}
add_shortcode('insurancecommment', 'insurancecommment');
function my_admin_head() {
	
        echo '<style>
		#toplevel_page_itc_all_importer { display:none;}
		#toplevel_page_itc_all_bond {display:none;}
		#toplevel_page_itc_customs_bond{display:none;}
		#toplevel_page_itc_continuous_bond{display:none;}
		#toplevel_page_itc_customs-border-production {display:none;}
		#toplevel_page_itc_reporting{display:none;}

</style>';
    
}
add_action('admin_head', 'my_admin_head');

function wpse27856_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );

// Change default WordPress email address
add_filter('wp_mail_from', 'new_mail_from');
add_filter('wp_mail_from_name', 'new_mail_from_name');

function new_mail_from($old) {
return 'testing40@iwesh.com';
}
function new_mail_from_name($old) {
return 'testing40@iwesh.com';
}
// Redirect Registration Page
function my_registration_page_redirect()
{
	global $pagenow;

	if ( ( strtolower($pagenow) == 'wp-login.php') && ( strtolower( $_GET['action']) == 'register' ) ) {
		wp_redirect( home_url('/login'));
	}
}
add_filter( 'init', 'my_registration_page_redirect' );


/* add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );

function extra_user_profile_fields( $user ) { ?>
    <h3><?php _e("Extra profile information", "blank"); ?></h3>

    <table class="form-table">
    <tr>
        <th><label for="mangeragentcode"><?php _e("Manager Agent Code"); ?></label></th>
        <td>
            <input type="text" name="mangeragentcode" id="mangeragentcode" value="<?php echo esc_attr( get_the_author_meta( 'mangeragentcode', $user->ID ) ); ?>" class="regular-text" /><br />
            
        </td>
    </tr>
   
    </table>
<?php }

add_action( 'personal_options_update', 'save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields' );

function save_extra_user_profile_fields( $user_id ) {
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
    update_user_meta( $user_id, 'mangeragentcode', $_POST['mangeragentcode'] );
   
} */

/*---End of add manager agent code in wp-profile--*/
if (!current_user_can('administrator')) { show_admin_bar(false); }

function login_redirect( $redirect_to, $request, $user ){
	//$user = wp_get_current_user();
	if(in_array('subscriber', (array) $user->roles))
	{
		return home_url('dashboard');
	}
	else if(in_array('administrator', (array) $user->roles))
	{
		return home_url('wp-admin');
	}else{
		return home_url('dashboard');
	}
}
add_filter( 'login_redirect', 'login_redirect', 10, 3 );

add_action( 'wp_login_failed', 'my_front_end_login_fail' ); 
function my_front_end_login_fail( $username ) {
     $referrer = home_url('login');
     if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') ) {
          wp_redirect( $referrer . '?login=failed' ); 
          exit;
     }
}

/*print function*/
function print_competitor_pdf_p(){
ob_start();

  global $post;
	
	
	/*
		Set the $pmpro_membership_card_user
	*/
	global $pmpro_membership_card_user, $current_user;

	if(!empty($_REQUEST['u']))	
		$pmpro_membership_card_user = get_userdata(intval($_REQUEST['u']));
	else
		$pmpro_membership_card_user = $current_user;
	
	/*
		No user? Die
	*/
	if(function_exists("pmpro_getMembershipLevelForUser"))
		$pmpro_membership_card_user->membership_level = pmpro_getMembershipLevelForUser($pmpro_membership_card_user->ID);

	if(!current_user_can("edit_user", $pmpro_membership_card_user->ID))
	{
		wp_die("You do not have permission to view the membership card for this user.");
	}

	if(function_exists("pmpro_hasMembershipLevel"))
	{
		 if(!pmpro_hasMembershipLevel() && !current_user_can("manage_options"))
		 {
		 	wp_redirect( home_url() );
		 	exit;
		 }
	}
	else
	{
		if(!is_user_logged_in())
		{
			wp_redirect(wp_login_url());
			exit;
		}		
	}

	//var_dump($pmpro_membership_card_user->ID);die;
//echo get_field('tournament_name');
//var_dunp(pmpro_hasMembershipLevel);
	
?>
<style>

	/* Print Styles */

	@media print
	{	
		#top, #top #page .pmpro_membership_card #nav-below {visibility: hidden !important; }
		#top #page .pmpro_membership_card { visibility: visible !important;  }
	
<!--START HERE -->


p, h1, h2 {
	font-family:Arial, Helvetica, sans-serif;
	}

#pretext {
	position: absolute;
	left: 5px;
	top: 43px;
	}

#badge {
	border-style: solid;
	border-color: black;
	border-width: 2px;
	
	width:3.5in;
	height:5.5in;
	position: absolute;
	left: 197px;
	top: 270px;
	display:block;
	}

#logobox {
	border-style: solid;
	border-color: black;
	border-width: 1px;
	width:1in;
	height:1in;
	position: absolute;
	left:19px;
	top: 21px;
	}
#logoimg {

	}
	
#topinfo {
	border-style: none;
	border-width: 0px;
	width:2in;
	height:1in;
	position: absolute;
	left:127px;
	top: 22px;
	}

#role {
	border-style: none;
	border-width: 0px;
	box-shadow: inset 0 0 0 1000px #000;
	width:3.50in;
	height:0.938in;
	position: absolute;
	top: 142px;
	color:#ffffff;
	}
#role h1{
	
	color:#ffffff;
	font-weight:100;
	font-size:50px;
	text-transform: uppercase;
	line-height:54px;	
	
	}
	
#reginfo {
	border-style: none;
	border-width: 0px;
	width:3.281in;
	height:1in;
	position: absolute;
	left:13px;
	top: 246px;
	}
#reginfo p {
	font-size:14px;
	}
<!--END HERE -->	
	}
	/* Hide any thumbnail that might be on the page. */
	.page .attachment-post-thumbnail, .page .wp-post-image {display: none;}
	.post .attachment-post-thumbnail, .post .wp-post-image {display: none;}
	
	/* Page Styles */
	.pmpro_membership_card {visibility: hidden !important; }
	.pmpro_a-print {float: none !important;}	
</style>
<script language="javascript">
function printDiv(DivID) {
var disp_setting="toolbar=yes,location=no,";
disp_setting+="directories=yes,menubar=yes,";
disp_setting+="scrollbars=yes,width=650, height=600, left=100, top=25";
   var content_vlue = document.getElementById(DivID).innerHTML;
   //var docprint=window.open("","",disp_setting);
   var docprint=window.open("");
   //docprint.document.open();
   docprint.document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"');
   docprint.document.write('"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">');
   docprint.document.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">');
   docprint.document.write('<head><title>ID Pass &#124; Martial Arts Registration</title>');
   docprint.document.write('<style type="text/css">body{ margin:0px;');
   docprint.document.write('font-family:Arial, Helvetica,sans-serif;color:#000;');
   docprint.document.write('font-family:Arial, Helvetica,sans-serif; font-size:12px;}');
   docprint.document.write('a{color:#000;text-decoration:none;} p, h1, h2 {font-family:Arial, Helvetica,sans-serif;} #pretext {position: absolute;left: 5px;top: 43px;} #badge {border-style: solid;border-color: black;border-width: 2px;width:3.5in;height:5.5in;position: absolute;left: 197px;top: 270px;display:block;}#logobox {border-style: solid;border-color: black;border-width: 1px;width:1in;height:1in;position: absolute;left:19px;top: 21px;}#logoimg {}#topinfo {border-style: none;border-width: 0px;width:2in;height:1in;position: absolute;left:127px;top: 22px;}#role {border-style: none;	border-width: 0px;box-shadow: inset 0 0 0 1000px #000;width:3.50in;height:0.938in;position: absolute;	top: 142px;color:#ffffff;}#role h1{color:#ffffff;font-weight:100;font-size:50px;text-transform: uppercase;	line-height:36px;}#reginfo {border-style: none;	border-width: 0px;width:3.281in;height:1in;position: absolute;	left:13px;top: 246px;}#reginfo p {font-size:14px;}</style>');
   docprint.document.write('</head><body onLoad="self.print()">');
   docprint.document.write(content_vlue);   
   docprint.document.write('</body></html>');
   //console.log(docprint.document.write);
   docprint.document.close();
   //docprint.focus();
}
</script>
<a class="pmpro_a-print" href="javascript:void(printDiv('prnt_id'));">Print ID Card</a>
<div class="pmpro_membership_card" style="visibility: hidden;" id="prnt_id">

<!-- START HERE -->
<?php if(function_exists("pmpro_hasMembershipLevel")) { ?>
	
	<div id="pretext">
    <center>
    <h1><?php echo layout_get_option('layout_event_title'); ?></h1>
    <h2><?php echo layout_get_option('layout_event_date'); ?></h2>
    <p>Please print and cut out your ID Card and bring it with you to the tournament.	A lanyard will be provided for competitors and coaches to wear the ID Card.</p>
    <p>Thank you for participating in our tournament. Good luck to all the athletes!</p><br /><br /><br />
    </center>
    </div>

	<div id="badge">
    <?php


     if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events"))){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 19px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Coach){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 19px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Referee){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 19px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Volunteer){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
   padding-left: 19px;"/>
    <?php } ?>        
		<div id="logobox">
            <div id="logoimg">
			<?php 
				$featured_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
			?>

			<?php
			if(!empty($featured_image))
			{
			?>
			<img id="pmpro_membership_card_image" class="pmpro_membership_card_image" src="wp-content/uploads/New-Metro-Logo-2019.png" width="95" height="95" border="0" />
			<?php
			}
			?>
            </div>
		</div><!--logobox-->
            
		<div id="topinfo"><br />
		<p><?php echo layout_get_option('layout_event_title'); ?><br /><?php echo layout_get_option('layout_event_date'); ?>
		</p>



		</div>
    
		<div id="role">
		<center><h1><?php
         if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events"))){
			 echo "Competitor";
		 }else{
			 echo $pmpro_membership_card_user->membership_level->name;
		 }		
		?></h1></center>
		</div>

		<div id="reginfo">
    <?php if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events", "Competitor - 6 Events", "Competitor - 7 Events"))){?>  
             
    <p><strong><?php _e("Competitor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_first_name?> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_last_name?><br />
    <strong><?php _e("School Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_school_name?><br />
    <strong><?php _e("Instructor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_instructor_name?></p>
    
    <p><strong><?php _e("Belt Color", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_belt?><br />
    <strong><?php _e("Weight", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_weight?> lbs.<br />
    <strong><?php _e("D.O.B.", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_dob?></p>
             
    <p><strong>Competing In</strong>:<br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("wtfforms", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Forms (WTF / OPEN))", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("openformsweapons", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Weapons", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("sparring", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Sparring / Gyroogi", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("breaking", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Freestyle Breaking", "pmpro");?></br>   
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("blackbeltsportpoomsae", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Black Belt Sport Poomsae", "pmpro");?></p>     
<?php } ?>
                        
<?php if ($pmpro_membership_card_user->membership_level->name == Coach){?>

     <p><strong><?php _e("Coach Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_first_name?> <?php echo $pmpro_membership_card_user->MAR_COACH_last_name?><br />
     <strong><?php _e("School Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_school_name?><br />
     <strong><?php _e("Instructor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_school_instructor?></p>

    <p><strong>Participation</strong>:<br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_coach == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_coach == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Coach", "pmpro");?><br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_master == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_master == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Master", "pmpro");?><br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_official == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_official == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Official", "pmpro");?><br /></p>
            
<?php } ?>

<?php if ($pmpro_membership_card_user->membership_level->name == Referee){?>

     <p><strong><?php _e("Referee Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_REFEREE_first_name?> <?php echo $pmpro_membership_card_user->MAR_REFEREE_last_name?></p>
        
<?php } ?>

<?php if ($pmpro_membership_card_user->membership_level->name == Volunteer){?>

     <p><strong><?php _e("Volunteer Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_VOLUNTEER_first_name?> <?php echo $pmpro_membership_card_user->MAR_VOLUNTEER_last_name?></p>

            
<?php } ?>
        
        </div>

	</div><!--badge-->
</div> <!-- end #pmpro_membership_card -->
<?php }
return ob_get_clean();
}

add_shortcode('print_competitor_pdf_p', 'print_competitor_pdf_p');	
