<?php

/*

  Template Name: Visitor

 */



get_header();

?>

<!-- Fullwidth page Starts -->
 <?php if (have_posts()) while (have_posts()) : the_post(); 
 $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
?>
     <div class="innner-page-title" style="<?php if($url!="") { ?>background-image:url('<?php echo $url; ?>'); <?php }  else { ?> background-image:url('<?php echo get_template_directory_uri(); ?>/images/custom-bg.jpg')<?php } ?>">
                  <h1 class="post-page-head"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">
                <?php the_title(); ?>
                </a></h1>

     </div>

<?php endwhile; ?>
<?php ?>


<main class="blogpost-wrapper">
  <div class="container">
    <div class="row">
      <div class="blogpost-content">
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <?php if (have_posts()) while (have_posts()) : the_post(); ?>
          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-page" style="margin-right: 0;">
             
              <?php the_content(); ?>
            </div>
          </div>
          <?php endwhile; ?>
          <div class="clearfix"></div>
          <div class="clearfix"></div>
        </article>
      </div>
    </div>
  </div>
</main>

<div class="side-top-footer" style="background-image:url('images/slider1-600x300-1.jpg');">
      <div class="inner-side-top">
        <div class="container">
          <div class="row">
            <div class="col-sm-8">
              <div class="top-footer-text">
                <p><?php echo layout_get_option('email_cta_title'); ?></p>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="top-footer-btn"> <a href="<?php echo layout_get_option('email_cta_button_link'); ?>"> <?php echo layout_get_option('email_cta_button'); ?><i class="fa fa-chevron-right" aria-hidden="true"></i> </a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php get_footer(); ?>
