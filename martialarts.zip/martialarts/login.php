<?php
/*

Template Name: Login

 */
get_header();

?>

<!-- Fullwidth page Starts -->

<div class="inner-title">
  
    <h1 class="post-page-head"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">
                <?php the_title(); ?>
                </a></h1> 
</div>

<main class="blogpost-wrapper">
  <div class="container">
    <div class="row">
      <div class="blogpost-content">
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <?php if (have_posts()) while (have_posts()) : the_post(); ?>
          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-page" style="margin-right: 0;">
            <?php
global $wpdb, $user_ID; 

//Check whether the user is already logged in 
if (!$user_ID) {

// Default page shows register form. 
// To show Login form set query variable action=login
$action = (isset($_GET['action']) ) ? $_GET['action'] : 0;



?>
<section class="aa_loginForm">
        <?php 
            global $user_login; 
			
            // In case of a login error.
            if ( isset( $_GET['login'] ) && $_GET['login'] == 'failed' ) : ?>
    	            <div class="aa_error">
    		            <p><?php _e( 'Enter valid login detail!', 'AA' ); ?></p>
    	            </div>
            <?php 
                endif;
            // If user is already logged in.
            if ( is_user_logged_in() ) : ?>

                <div class="aa_logout"> 
                    
                    <?php 
                        _e( 'Hello', 'AA' ); 
                        echo $user_login; 
                    ?>
                    
                    </br>
                    
                    <?php _e( 'You are already logged in.', 'AA' ); ?>

                </div>

                <a id="wp-submit" href="<?php echo wp_logout_url(); ?>" title="Logout">
                    <?php _e( 'Logout', 'AA' ); ?>
                </a>

            <?php 
                // If user is not logged in.
                else: 
                
                    if ( isset( $_GET['action'] ) && $_GET['action'] == 'reset_success' ) 
					{
						echo '<div class="sucess">Your password reset sucessfully,please check your mail inbox.</div><br/>';
					}
					
					// Login form arguments.
                    
					
					$args = array(
                        'echo'           => true,
                        'redirect'       => home_url( '/dashboard/' ), 
                        'form_id'        => 'loginform',
                        'label_username' => __( 'Username' ),
                        'label_password' => __( 'Password' ),
                        'label_remember' => __( 'Remember Me' ),
                        'label_log_in'   => __( 'Log In' ),
                        'id_username'    => 'user_login',
                        'id_password'    => 'user_pass',
                        'id_remember'    => 'rememberme',
                        'id_submit'      => 'wp-submit',
                        'remember'       => true,
                        'value_username' => NULL,
                        'value_remember' => true
                    ); 
                    
                    // Calling the login form.
                    wp_login_form( $args );
                endif;
        ?> 
		<div>
	<ul class="tml-action-links">
<li><a href="<?php echo site_url().'/lost-password';?>" rel="nofollow">Lost Password</a></li>
</ul>
	</div>

</section>
<?php 
}
?>

            </div>
          </div>
          <?php endwhile; ?>
          <div class="clearfix"></div>
          <div class="clearfix"></div>
        </article>
      </div>
    </div>
  </div>
</main>
<?php get_footer(); ?>
