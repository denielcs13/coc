<?php
/*
Template Name: Card Customizations
*/


  global $post;
	
	
	/*
		Set the $pmpro_membership_card_user
	*/
	global $pmpro_membership_card_user, $current_user;

	if(!empty($_REQUEST['u']))	
		$pmpro_membership_card_user = get_userdata(intval($_REQUEST['u']));
	else
		$pmpro_membership_card_user = $current_user;
	
	/*
		No user? Die
	*/
	if(function_exists("pmpro_getMembershipLevelForUser"))
		$pmpro_membership_card_user->membership_level = pmpro_getMembershipLevelForUser($pmpro_membership_card_user->ID);

	if(!current_user_can("edit_user", $pmpro_membership_card_user->ID))
	{
		wp_die("You do not have permission to view the membership card for this user.");
	}

	if(function_exists("pmpro_hasMembershipLevel"))
	{
		 if(!pmpro_hasMembershipLevel() && !current_user_can("manage_options"))
		 {
		 	wp_redirect( home_url() );
		 	exit;
		 }
	}
	else
	{
		if(!is_user_logged_in())
		{
			wp_redirect(wp_login_url());
			exit;
		}		
	}

	//var_dump($pmpro_membership_card_user->ID);die;
//echo get_field('tournament_name');
//var_dunp(pmpro_hasMembershipLevel);
	
?>
<style>

	/* Print Styles */
	@media print
	{	
		.page, .page .pmpro_membership_card #nav-below {visibility: hidden !important; }
		.page .pmpro_membership_card { visibility: visible !important;  }
	
<!--START HERE -->


p, h1, h2 {
	font-family:Arial, Helvetica, sans-serif;
	}

#pretext {
	position: absolute;
	left: 5px;
	top: 43px;
	}

#badge {
	border-style: solid;
	border-color: black;
	border-width: 2px;
	
	width:3.5in;
	height:5.5in;
	position: absolute;
	left: 197px;
	top: 270px;
	display:block;
	}

#logobox {
	border-style: solid;
	border-color: black;
	border-width: 1px;
	width:1in;
	height:1in;
	position: absolute;
	left:19px;
	top: 21px;
	}
#logoimg {

	}
	
#topinfo {
	border-style: none;
	border-width: 0px;
	width:2in;
	height:1in;
	position: absolute;
	left:127px;
	top: 22px;
	}

#role {
	border-style: none;
	border-width: 0px;
	box-shadow: inset 0 0 0 1000px #000;
	width:3.50in;
	height:0.938in;
	position: absolute;
	top: 142px;
	color:#ffffff;
	}
#role h1{
	
	color:#ffffff;
	font-weight:100;
	font-size:50px;
	text-transform: uppercase;
	line-height:25px;	
	
	}
	
#reginfo {
	border-style: none;
	border-width: 0px;
	width:3.281in;
	height:1in;
	position: absolute;
	left:13px;
	top: 246px;
	}
#reginfo p {
	font-size:14px;
	}
<!--END HERE -->	
	}
	/* Hide any thumbnail that might be on the page. */
	.page .attachment-post-thumbnail, .page .wp-post-image {display: none;}
	.post .attachment-post-thumbnail, .post .wp-post-image {display: none;}
	
	/* Page Styles */
	/*.pmpro_membership_card {visibility: hidden !important; }*/
	.pmpro_a-print {float: none !important;}	
</style>
<a class="pmpro_a-print" href="javascript:window.print()">Print ID Card</a>
<div class="pmpro_membership_card" >

<!-- START HERE -->
<?php if(function_exists("pmpro_hasMembershipLevel")) { ?>
	
	<div id="pretext">
    <center>
    <h1><?php echo layout_get_option('layout_event_title'); ?></h1>
    <h2><?php echo layout_get_option('layout_event_date'); ?></h2>
    <p>Please print and cut out your ID Card and bring it with you to the tournament.	A lanyard will be provided for competitors and coaches to wear the ID Card.</p>
    <p>Thank you for participating in our tournament. Good luck to all the athletes!</p><br /><br /><br />
    </center>
    </div>

	<div id="badge">
    <?php


     if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events"))){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 20px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Coach){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 20px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Referee){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 20px;"/>
    <?php } ?>
    <?php if ($pmpro_membership_card_user->membership_level->name == Volunteer){?>  
    <img src="../wp-content/uploads/New-Metro-Logo-2019.png" width="97" height="97" style="margin-top: 22px;
    padding-left: 20px;"/>
    <?php } ?>        
		<div id="logobox">
            <div id="logoimg">
			<?php 
				$featured_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
			?>

			<?php
			if(!empty($featured_image))
			{
			?>
			<img id="pmpro_membership_card_image" class="pmpro_membership_card_image" src="wp-content/uploads/New-Metro-Logo-2019.png" width="95" height="95" border="0" />
			<?php
			}
			?>
            </div>
		</div><!--logobox-->
            
		<div id="topinfo"><br />
		<p><?php echo layout_get_option('layout_event_title'); ?><br /><?php echo layout_get_option('layout_event_date'); ?>
		</p>



		</div>
    
		<div id="role">
		<center><h1><?php
         if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events"))){
			 echo "Competitor";
		 }else{
			 echo $pmpro_membership_card_user->membership_level->name;
		 }		
		?></h1></center>
		</div>

		<div id="reginfo">
    <?php if (in_array($pmpro_membership_card_user->membership_level->name, array("Competitor - 1 Event", "Competitor - 2 Events", "Competitor - 3 Events", "Competitor - 4 Events", "Competitor - 5 Events", "Competitor - 6 Events", "Competitor - 7 Events"))){?>  
             
    <p><strong><?php _e("Competitor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_first_name?> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_last_name?><br />
    <strong><?php _e("School Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_school_name?><br />
    <strong><?php _e("Instructor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_instructor_name?></p>
    
    <p><strong><?php _e("Belt Color", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_belt?><br />
    <strong><?php _e("Weight", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_weight?> lbs.<br />
    <strong><?php _e("D.O.B.", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COMPETITOR_dob?></p>
             
    <p><strong>Competing In</strong>:<br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("wtfforms", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Forms (WTF / OPEN))", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("openformsweapons", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Weapons", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("sparring", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Sparring / Gyroogi", "pmpro");?><br />
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("breaking", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Freestyle Breaking", "pmpro");?></br>   
    <?php $compcat = $pmpro_membership_card_user->MAR_COMPETITOR_category; if (in_array("blackbeltsportpoomsae", $compcat)) {echo " [ <strong>X</strong> ] ";} else {echo " [&nbsp;&nbsp;&nbsp;&nbsp;] ";}?><?php _e("Black Belt Sport Poomsae", "pmpro");?></p>     
<?php } ?>
                        
<?php if ($pmpro_membership_card_user->membership_level->name == Coach){?>

     <p><strong><?php _e("Coach Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_first_name?> <?php echo $pmpro_membership_card_user->MAR_COACH_last_name?><br />
     <strong><?php _e("School Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_school_name?><br />
     <strong><?php _e("Instructor Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_COACH_school_instructor?></p>

    <p><strong>Participation</strong>:<br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_coach == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_coach == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Coach", "pmpro");?><br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_master == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_master == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Master", "pmpro");?><br />
    <?php if ($pmpro_membership_card_user->MAR_COACH_category_official == 1){?> [ <strong>X</strong> ] <?php } ?><?php if ($pmpro_membership_card_user->MAR_COACH_category_official == 0){?> [&nbsp;&nbsp;&nbsp;&nbsp;] <?php } ?> <?php _e("Official", "pmpro");?><br /></p>
            
<?php } ?>

<?php if ($pmpro_membership_card_user->membership_level->name == Referee){?>

     <p><strong><?php _e("Referee Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_REFEREE_first_name?> <?php echo $pmpro_membership_card_user->MAR_REFEREE_last_name?></p>
        
<?php } ?>

<?php if ($pmpro_membership_card_user->membership_level->name == Volunteer){?>

     <p><strong><?php _e("Volunteer Name", "pmpro");?>:</strong> <?php echo $pmpro_membership_card_user->MAR_VOLUNTEER_first_name?> <?php echo $pmpro_membership_card_user->MAR_VOLUNTEER_last_name?></p>

            
<?php } ?>
        
        </div>

	</div><!--badge-->
<?php } ?>    
<!-- END HERE -->      
    
</div> <!-- end #pmpro_membership_card -->
	


