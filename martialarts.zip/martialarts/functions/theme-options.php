<?php

add_action('init', 'of_options');
if (!function_exists('of_options')) {

    function of_options() {
        // VARIABLES
        $themename = 'Theme ';
        $shortname = "of";
        // Populate OptionsFramework option in array for use in theme
        global $of_options;
        $of_options = layout_get_option('of_options');
        //Front page on/off
        $file_rename = array("on" => "On", "off" => "Off");
        $showhide_sections = array("Show" => "Show", "Hide" => "Hide");
        // Background Defaults
        $background_defaults = array('color' => '', 'image' => '', 'repeat' => 'repeat', 'position' => 'top center', 'attachment' => 'scroll');
        
        // Pull all the categories into an array
        $options_categories = array();
        $options_categories_obj = get_categories();
        foreach ($options_categories_obj as $category) {
        $options_categories[$category->cat_ID] = $category->cat_name;
        }

        // Populate OptionsFramework option in array for use in theme
        $contact_option = array("on" => "On", "off" => "Off");
        $captcha_option = array("on" => "On", "off" => "Off");
        // Pull all the pages into an array
        $options_pages = array();
        $options_pages_obj = get_pages('sort_column=post_parent,menu_order');
        $options_pages[''] = 'Select a page:';
        foreach ($options_pages_obj as $page) {
            $options_pages[$page->ID] = $page->post_title;
        }
        // If using image radio buttons, define a directory path
        $imagepath = get_template_directory_uri() . '/images/';

		
		//*** GENERAL SETTING OPTIONS ***//
        $options = array();
        $options[] = array("name" => "General Settings",
            "type" => "heading");
		
		// Brand Setting ***//
        $options[] = array("name" => "Brand Setting",
            "type" => "saperate",
            "class" => "saperator");

        $options[] = array("name" => "Main Logo",
            "desc" => "Upload main logo for your Website.",
            "id" => "main_logo",
            "type" => "upload");
			
		$options[] = array("name" => "Favicon",
            "desc" => "Upload a Favicon. (Recommended size: 80px X 80px)",
            "id" => "website_favicon",
            "type" => "upload");
			
		$options[] = array("name" => "Admin Logo",
            "desc" => "Upload a logo for Admin Panel.",
            "id" => "admin_logo",
            "type" => "upload");

        // Location Setting ***//
		$options[] = array("name" => "Location Details",
            "type" => "saperate",
            "class" => "saperator");
			
		$options[] = array("name" => "Street Address",
            "desc" => "Enter Street Address.",
            "id" => "street_address",
            "type" => "text");
		
		$options[] = array("name" => "City",
            "desc" => "Enter CITY.",
            "id" => "address_city",
            "type" => "text");
			
		$options[] = array("name" => "State",
            "desc" => "Enter State.",
            "id" => "address_state",
            "type" => "text");
			
		$options[] = array("name" => "ZIP",
            "desc" => "Enter ZIP.",
            "id" => "address_zip",
            "type" => "text");
		
		$options[] = array("name" => "Google Map",
            "desc" => "Embed Google Map Code.",
            "id" => "address_gmap",
            "type" => "text");
			
		// Contact Setting ***//
		$options[] = array("name" => "Contact Details",
            "type" => "saperate",
            "class" => "saperator");

		$options[] = array("name" => "Contact Title",
            "desc" => "Enter title here.",
            "id" => "contact_title",
            "type" => "text");
			
		$options[] = array("name" => "Phone",
            "desc" => "Enter Phone # here.",
            "id" => "contact_phone",
            "type" => "text");
			
		$options[] = array("name" => "Email",
            "desc" => "Enter Email ID here.",
            "id" => "contact_email",
            "type" => "text");
		
		$options[] = array("name" => "Fax",
            "desc" => "Enter Fax # here.",
            "id" => "contact_fax",
            "type" => "text");


            // Time hours ***//
        $options[] = array("name" => "Time Hours",
            "type" => "saperate",
            "class" => "saperator");

       
        
        $options[] = array("name" => "Time Hours",
            "desc" => "Time hours Text.",
            "id" => "time_hours",
            "type" => "textarea");
			

        //****=============================================================================****//

            
        $options[] = array("name" => "Metro Open Content Section",
            "type" => "heading");

         $options[] = array("name" => "Main Heading",
            "desc" => "Mention the main heading here.",
            "id" => "layout_metro_main_heading",
            "type" => "text");


        $options[] = array("name" => "Heading",
            "desc" => "Mention the heading here.",
            "id" => "layout_heading_metro_open",
            "type" => "text");

        $options[] = array("name" => "image upload",
            "desc" => "Upload images.",
            "id" => "layout_upload_metro_image",
            "type" => "upload");

        $options[] = array("name" => "Metro Open Description",
            "desc" => "Enter Description",
            "id" => "layout_metro_open", 
            "type" => "textarea");

         $options[] = array("name" => "btn text",
            "desc" => "Mention the btn text here.",
            "id" => "layout_btn_metro_open",
            "type" => "text");


           $options[] = array("name" => "btn text link",
            "desc" => "Mention the btn link here.",
            "id" => "layout_btn_metro_open_link",
            "type" => "text");


        //****=============================================================================****//

			
        $options[] = array("name" => "Cup Championship",
            "type" => "heading");


           $options[] = array("name" => "Heading",
            "desc" => "Mention the heading here.",
            "id" => "layout_heading_main",
            "type" => "text");

		
		$options[] = array("name" => "Event Table",
            "type" => "saperate",
            "class" => "saperator");

         $options[] = array("name" => "Event Date",
            "desc" => "Enter Event Date",
            "id" => "layout_event_date",
            "type" => "text");


         $options[] = array("name" => "Event Title",
            "desc" => "Enter Event Title",
            "id" => "layout_event_title",
            "type" => "text");

          $options[] = array("name" => "Event Hosted by",
            "desc" => "Enter Hosted bye",
            "id" => "layout_event_hosted",
            "type" => "textarea");

          $options[] = array("name" => "Event Location",
            "desc" => "Enter Event Location",
            "id" => "layout_event_location",
            "type" => "textarea");


          $options[] = array("name" => "Event Location Google map text",
            "desc" => "Enter Event Location Google map text",
            "id" => "layout_event_location_map_text",
            "type" => "text");

          $options[] = array("name" => "Event Location Google map text Link",
            "desc" => "Enter Event Location Google map text Link",
            "id" => "layout_event_location_map_text_link",
            "type" => "text");

          $options[] = array("name" => "Event Phone Number",
            "desc" => "Enter Event Phone Number",
            "id" => "layout_event_phone",
            "type" => "text");

          $options[] = array("name" => "Event Website",
            "desc" => "Enter Event Website",
            "id" => "layout_event_web",
            "type" => "text");

           $options[] = array("name" => "Event Email",
            "desc" => "Enter Event Email",
            "id" => "layout_event_email",
            "type" => "text");

            $options[] = array("name" => "Mail All Registration Forms to",
            "desc" => "Enter Event Mail All Registration Forms to",
            "id" => "layout_event_forms_regis",
            "type" => "textarea");
        

         $options[] = array("name" => "Tournament General Admission",
            "desc" => "Enter Event Tournament General Admission",
            "id" => "layout_event_tournament_adm",
            "type" => "textarea");


        $options[] = array("name" => "Event Table Download Registration",
            "type" => "saperate",
            "class" => "saperator");

         $options[] = array("name" => "Competitor Text",
            "desc" => "Enter Competitor Text",
            "id" => "layout_competitor_text",
            "type" => "text");

        $options[] = array("name" => "Competitor Text Link",
            "desc" => "Enter Competitor Text Link",
            "id" => "layout_competitor_url",
            "type" => "text");


        $options[] = array("name" => "Coach Text",
            "desc" => "Enter Coach Text",
            "id" => "layout_coach_text",
            "type" => "text");

        $options[] = array("name" => "Coach Text Link",
            "desc" => "Enter Coach Text Link",
            "id" => "layout_coach_url",
            "type" => "text");


         $options[] = array("name" => "Referee Text",
            "desc" => "Enter Referee Text",
            "id" => "layout_referee_text",
            "type" => "text");

        $options[] = array("name" => "Referee Text Link",
            "desc" => "Enter Referee Text Link",
            "id" => "layout_referee_url",
            "type" => "text");


   $options[] = array("name" => "Program Book Text",
            "desc" => "Enter Program Book Text",
            "id" => "layout_program_text",
            "type" => "text");

        $options[] = array("name" => "Program Book Text Link",
            "desc" => "Enter Program Book Text Link",
            "id" => "layout_program_url",
            "type" => "text");


			
		//****=============================================================================****//
        
        //HomePage Columns		
        $options[] = array("name" => "Home Sidebar",
            "type" => "heading");


        // Column Block 1
        $options[] = array("name" => "First Column",
            "type" => "saperate",
            "class" => "saperator");

        $options[] = array("name" => "First Column Image",
            "desc" => "Upload First Column Image",
            "id" => "first_column_image",
            "type" => "upload");

			
		// Column Block 2


        $options[] = array("name" => "Second Column",
            "type" => "saperate",
            "class" => "saperator");

           $options[] = array("name" => "Second Column Title",
            "desc" => "Enter Second Column Title",
            "id" => "second_column_title",
            "type" => "text");

        $options[] = array("name" => "Second Column Image",
            "desc" => "Upload Second Column Image",
            "id" => "second_column_image",
            "type" => "upload");

		
		$options[] = array("name" => "Second Column Description",
            "desc" => "Enter Second Column Description",
            "id" => "second_column_desc",
            "type" => "textarea");

          $options[] = array("name" => "Second Column Button Link",
            "desc" => "Enter Second Column Button Link",
            "id" => "second_column_button_link",
            "type" => "text");


// Column Block 3


        $options[] = array("name" => "Third Column",
            "type" => "saperate",
            "class" => "saperator");

        $options[] = array("name" => "Third Column Image",
            "desc" => "Upload Third Column Image",
            "id" => "third_column_image",
            "type" => "upload");
       
        $options[] = array("name" => "Third Column Description",
            "desc" => "Enter Third Column Description",
            "id" => "third_column_desc",
            "type" => "textarea");

          $options[] = array("name" => "Third Column Button Link",
            "desc" => "Enter Third Column Button Link",
            "id" => "third_column_button_link",
            "type" => "text");




// Column Block 4

        $options[] = array("name" => "Fourth Column",
            "type" => "saperate",
            "class" => "saperator");

      $options[] = array("name" => "Fourth Column Heading",
            "desc" => "Enter Fourth Column heading",
            "id" => "fourth_column_heading",
            "type" => "text");

        $options[] = array("name" => "Fourth Column Image",
            "desc" => "Upload Fourth Column Image",
            "id" => "fourth_column_image",
            "type" => "upload");


         $options[] = array("name" => "Fourth Column Image",
            "desc" => "Upload Fourth Column Image",
            "id" => "fourth_column_image_one",
            "type" => "upload");

            $options[] = array("name" => "Fourth Column Image",
            "desc" => "Upload Fourth Column Image",
            "id" => "fourth_column_image_two",
            "type" => "upload");
     
     
          $options[] = array("name" => "Fourth Column image Link",
            "desc" => "Enter Fourth Column image Link",
            "id" => "fourth_column_image_link",
            "type" => "text");

           $options[] = array("name" => "Fourth Column image Link",
            "desc" => "Enter Fourth Column image Link",
            "id" => "fourth_column_image_one_link",
            "type" => "text");

           $options[] = array("name" => "Fourth Column image Link",
            "desc" => "Enter Fourth Column image Link",
            "id" => "fourth_column_image_one_two_link",
            "type" => "text");



// Column Block 5

        $options[] = array("name" => "Five Column",
            "type" => "saperate",
            "class" => "saperator");

        $options[] = array("name" => "Five Column Image",
            "desc" => "Upload Five Column Image",
            "id" => "fifth_column_image",
            "type" => "upload");


         $options[] = array("name" => "Five Column Image",
            "desc" => "Upload Five Column Image",
            "id" => "fifth_column_image_one",
            "type" => "upload");
     
     
          $options[] = array("name" => "Five Column image Link",
            "desc" => "Enter Five Column image Link",
            "id" => "fifth_column_button_link",
            "type" => "text");




	
		//****=============================================================================****//


   //HomePage Columns       
        $options[] = array("name" => "Home Ads",
            "type" => "heading");


          $options[] = array("name" => "Home Ads",
            "desc" => "Upload here Ad image",
            "id" => "layout_ad_image",
            "type" => "upload");
     
     
          $options[] = array("name" => "Home Ad Link",
            "desc" => "Enter Home Ad Link",
            "id" => "layout_ad_link",
            "type" => "text");


//****=============================================================================****//

		//Call to Action
        $options[] = array("name" => "CTA",
            "type" => "heading");
			
			$options[] = array("name" => "CTA: Focused on Email/Contact Form",
            "type" => "saperate",
            "class" => "saperator");
			
			$options[] = array("name" => "Email-Call To Action: Title",
            "desc" => "Enter Call to Action Title.",
            "id" => "email_cta_title",
            "type" => "text");
			
			$options[] = array("name" => "Email-Call To Action: Description",
            "desc" => "Enter Call to Action Description.",
            "id" => "email_cta_description",
            "type" => "text");
			
			$options[] = array("name" => "Email-Call To Action: Button",
            "desc" => "Enter Call to Action Button Text.",
            "id" => "email_cta_button",
            "type" => "text");
			
			$options[] = array("name" => "Email-Call To Action: Button Link",
            "desc" => "Enter Call to Action Button Link.",
            "id" => "email_cta_button_link",
            "type" => "text");
			

	
			      
			
//****=============================================================================****//

//****=============================================================================****//
		//Call to Action
        $options[] = array("name" => "CBI Email Setting",
            "type" => "heading");
			
			$options[] = array("name" => "CBI Register Mail Setting",
            "type" => "saperate",
            "class" => "saperator");
			
			$options[] = array("name" => "Send To Emails",
            "desc" => "Enter multiple To email with comma seprate",
            "id" => "cbi_register_to",
            "type" => "text");
			
			$options[] = array("name" => "Send Bcc Emails",
            "desc" => "Enter multiple To email with comma seprate",
            "id" => "cbi_register_bcc",
            "type" => "text");
			
			$options[] = array("Registration Mail Subject",
            "desc" => "Registration Mail Subject",
            "id" => "cbi_register_subject",
            "type" => "text");
			
	
			
			$options[] = array("name" => "CBI Forgot Password Mail",
            "type" => "saperate",
            "class" => "saperator");
			
			$options[] = array("name" => "CBI Forgot Password Subject",
            "desc" => "Enter Call to Action Title.",
            "id" => "cbi_forgot_subject",
            "type" => "text");

			$options[] = array("name" => "CBI Generate CTB Mail",
            "type" => "saperate",
            "class" => "saperator");
			
			$options[] = array("name" => "Send To Emails",
            "desc" => "Enter multiple To email with comma seprate",
            "id" => "cbi_generate_ctb_to",
            "type" => "text");
			
			$options[] = array("name" => "Send Bcc Emails",
            "desc" => "Enter multiple Bcc email with comma seprate",
            "id" => "cbi_generate_ctb_bcc",
            "type" => "text");
			
			$options[] = array("name" => "Subject of Generate CTB",
            "desc" => "Enter multiple Bcc email with comma seprate",
            "id" => "cbi_generate_ctb_subject",
            "type" => "text");	
			      
			
//****=============================================================================****//
        layout_update_option('of_template', $options);
        layout_update_option('of_themename', $themename);
        layout_update_option('of_shortname', $shortname);
    }
}
?>