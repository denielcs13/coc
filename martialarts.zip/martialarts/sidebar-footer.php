<!-- Footer Starts -->

<footer>
<?php if(wp_is_mobile()) { 

} else { ?>


<?php } ?>
<!-- Footer Ends -->