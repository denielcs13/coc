<!-- Footer Sidebar Starts -->
<?php get_sidebar('footer'); ?>
<!-- Footer Sidebar Ends -->


  <div class="footer-copyright-wrapper">
    <div class="container">
      <div class="row">
        <div class="col-sm-5">
          <div class="footer-copyright">
           <p>&#169; <?php echo date("Y") ?>
              <?php bloginfo( 'name' ); ?>. All rights reserved.</p>
          </div>
        </div>
        <div class="col-sm-7">

          <div class="footer-menu nav-collapse">
          <?php dynamic_sidebar('footer-menu'); ?> | 
          Website by <a href="http://biggerfishmarketing.com/" target="_blank">BiggerFish Marketing.</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
</main>

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<script type="text/javascript">
jQuery(window).load(function() {            
jQuery('.flexslider').flexslider({
	slideshowSpeed: parseInt(<?php echo layout_get_option('layout_slider_speed'); ?>);
	controlNav: true,                
directionNav: true,              

	});	
});
</script> 

<script type="text/javascript">
    var jQuery_1_11_2 = $.noConflict(true);
</script> 
<!-- <script src="<?php bloginfo('template_url'); ?>/js/jquery.slicknav.js"></script>  -->
<!-- <script type="text/javascript"> 
jQuery(document).ready(function(){
	jQuery('.menu-sp').slicknav();
});
</script> -->


<script>
jQuery(document).ready(function () {

   jQuery(".icon").click(function () {

      jQuery(".mobilenav").fadeToggle(500);

      jQuery(".top-menu").toggleClass("top-animate");

      jQuery(".mid-menu").toggleClass("mid-animate");

      jQuery(".bottom-menu").toggleClass("bottom-animate");

    });

  });
    </script> 
<script>
jQuery(document).ready(function(){
  jQuery('.menu_icon').click(function(){
    jQuery('.mobile_menu_section').slideToggle();
  });
  
  jQuery('.down').click(function(){
    jQuery('.sub-menu').toggle();
  });
});
</script> 
<?php wp_footer(); ?>
</body></html>