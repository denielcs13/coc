<form role="search" method="get" class="searchform" action="<?php echo home_url('/'); ?>">

    <div>

        <input type="text" placeholder="Search" name="s" id="search" />

        <input type="submit" id="searchsubmit" value="Search" />

    </div>

</form>

<div class="clear"></div>

