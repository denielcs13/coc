/* wookmark gallery */

(function (jQuery){



      jQuery('#tiles').imagesLoaded(function() {

        // Prepare layout options.

        var options = {

          autoResize: true, // This will auto-update the layout when the browser window is resized.

          container: jQuery('#main'), // Optional, used for some extra CSS styling

          offset: 35, // Optional, the distance between grid items

          itemWidth: 261, // Optional, the width of a grid item

          fillEmptySpace: true // Optional, fill the bottom of each column with widths of flexible height

        };



        // Get a reference to your grid items.

        var handler = jQuery('#tiles li'),

            filters = jQuery('#filters li');

 jQuery('#tiles').imagesLoaded(function() {

      // Prepare layout options.

      // Get a reference to your grid items.

      // Call the layout function.

      handler.wookmark(options);

    });

        // Call the layout function.



        /**

         * When a filter is clicked, toggle it's active state and refresh.

         */

        var onClickFilter = function(event) {

          var item = jQuery(event.currentTarget),

              activeFilters = [];



          if (!item.hasClass('active')) {

            filters.removeClass('active');

          }

          item.toggleClass('active');



          // Filter by the currently selected filter

          if (item.hasClass('active')) {

            activeFilters.push(item.data('filter'));

          }



          handler.wookmarkInstance.filter(activeFilters);

        }



        // Capture filter click events.

        filters.click(onClickFilter);

      });

    })(jQuery);

/* *

 * Parallax Scrolling Tutorial

 * For NetTuts+

 *  

 * Author: Mohiuddin Parekh

 *	http://www.mohi.me

 * 	@mohiuddinparekh   

 */





jQuery(document).ready(function(){

	  /* bx slider */

	jQuery('.bxslider').bxSlider({

	  auto: true,

	  autoControls: true,

	  captions: true,

	  mode: 'fade',

	  adaptiveHeight: true

	});

	  /* bx slider ends */

	// Cache the Window object

	$window = jQuery(window);

                

   jQuery('section[data-type="background"]').each(function(){

     var $bgobj = jQuery(this); // assigning the object

                    

      jQuery(window).scroll(function() {

                    

		// Scroll the background at var speed

		// the yPos is a negative value because we're scrolling it UP!								

		var yPos = -($window.scrollTop() / $bgobj.data('speed')); 

		

		// Put together our final background position

		var coords = '50% '+ yPos + 'px';



		// Move the background

		$bgobj.css({ backgroundPosition: coords });

		

}); // window scroll Ends



 });	



}); 

/* 

 * Create HTML5 elements for IE's sake

 */



document.createElement("article");

document.createElement("section");



/* catch ie10 */

if (/*@cc_on!@*/false) {  

    document.documentElement.className+=' ie10';  

}

/* slider */
jQuery(window).load(function() {
    jQuery('.flexslider').flexslider({
	//slideshowSpeed: parseInt(jQuery("#txt_name").val())
	controlNav: true,                
directionNav: true,              

	});
    jQuery('ul.sf-menu').superfish();
  });