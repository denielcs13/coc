<?php

/*
 * Template Name: All Services Page
 */

get_header();

?>

<!-- Single Post Starts -->

 <div class="clearfix"></div>



<main class="blogpost-wrapper">

    <div class="container">

        <div class="row">
		
            <div class="blogpost-content">

                      <article class="col-xs-12 col-sm-8 col-md-9 col-lg-9">

                                            <?php
                        $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
                        $wp_query = new WP_Query('post_type=service&posts_per_page=12&paged=' . $paged);
                        if ($wp_query->have_posts()) {
                            while ($wp_query->have_posts()) {
                                $wp_query->the_post();
                                $title = get_the_title();
                                $services_meta = get_post_meta($post->ID);

                                $servicesimg_id = $services_meta['_thumbnail_id'][0];
                                $servicesimg_src = wp_get_attachment_image_src($servicesimg_id, 'full');
                                $service_type_image_id = $services_meta['service_type_image'][0];
                                $service_type_image_src = wp_get_attachment_image_src($service_type_image_id, 'full');
                               
                                ?>


                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="block">                    
                                        <div class="img">
                                            <a href="<?php the_permalink(); ?>"><img src="<?php echo $servicesimg_src[0]; ?>" alt="<?php echo $title; ?>"/></a>
                                        </div>
                                        <div class="block-icon">
                                            <img src="<?php echo $service_type_image_src[0]; ?>"/>
                                        </div>                  
                                        <div class="description">
                                            <p><a href="<?php the_permalink(); ?>"><?php echo $title; ?></a></p>
											<?php echo the_content(); ?>
                                        </div>                  
                                    </div>
                                </div>
                                <?php
                              
                            }
                        } else {

                        }
                        wp_reset_postdata();
                        ?>   



                </article>

                   <aside class="col-xs-12 col-sm-4 col-md-3 col-lg-3">

                    <!-- Sidebar Starts -->

                    <?php get_sidebar(); ?>

                    <!-- Sidebar Ends -->

                </aside>

            </div>

		   
        </div>
    </div>

</main>

<?php get_footer(); ?>