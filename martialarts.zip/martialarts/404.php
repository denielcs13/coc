<?php

/*

 * The template for displaying 404 pages (Not Found)

 */

get_header();

?>

<!-- Single Post Starts -->
<main class="blogpost-wrapper">
  <div class="container">
    <div class="row">
      <div class="blogpost-content">
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 
          
          <!-- Post loop starts --> 
          
          <!-- Post1 Starts -->
          
          <div class="post-page not-found ">
            <div class="post-heading">
              <h1><?php echo THIS_IS_SOMEWHAT_EMBRASSING; ?></h1>
            </div>
            <div class="post-content clear">
              <p> 404 </p>
            </div>
          </div>
          <div class="clearfix"></div>
          
          <!-- Post1 Starts Ends --> 
          
          <!-- Post loop ends -->
          
          <div class="clearfix"></div>
        </article>
      </div>
    </div>
  </div>
</main>
<?php get_footer(); ?>
