<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php wp_title('&#124;', true, 'right'); ?><?php bloginfo('name'); ?></title>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" /> 
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/retina.css" /> 

<?php wp_head(); ?>

</head>
<body id="top">
<main id="page">


  <a href="#mm-menu" class="icon menu_icon">
  <div class="hamburger">
    <div class="menui top-menu"></div>
    <div class="menui mid-menu"></div>
    <div class="menui bottom-menu"></div>
  </div>
  </a>

 <div class="mobile_menu_section">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mobile_navigation">
<!-- 
               <?php if (is_front_page()) { ?>
            <?php layout_frontpage_nav() ?>
            <?php } else { ?>
            <?php layout_nav(); ?>
            <?php } ?> -->

              <ul class="sf-menu">
<?php
if ( is_user_logged_in() ) {
  ?>
<li class="btn-log"><a href="<?php echo site_url('/dashboard/')?>" aria-current="page">Profile</a></li>  
<li class="btn-log"><a href="<?php echo wp_logout_url('login/'); ?>">Logout</a></li> 
  <?php
}
else
{
  ?>
<li class="btn-log"><a href="<?php echo site_url('/login/')?>">Account Login</a></li>
<!--li class="btn-log"><a href="<?php echo site_url('/register/')?>">Register</a></li-->
<?php
}
?>
    </ul>


          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- mobile Logo and Phone -->
<div class="mobile-logo">
  <div class="row">
    <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
      <div class="logo">
        <?php if (layout_get_option('main_logo') != '') { ?>
        <a href="<?php echo home_url(); ?>"> <img src="<?php echo layout_get_option('main_logo'); ?>" alt="<?php bloginfo('name'); ?>"> </a>
        <?php } else { ?>
        <div class="logo-header">
          <h1><a href="<?php echo home_url(); ?>">
            <?php bloginfo('name'); ?>
            </a></h1>
          <p>
            <a href="tel:<?php echo layout_get_option('contact_phone'); ?>"><?php echo layout_get_option('contact_phone'); ?></a>
          </p>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<!-- End Mobile -->



<div class="menu-wrapper single-page-nav clearfix">
    <div class="menu-wrapper-bg">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-4 col-md-4"> 
            
               <div class="logo">
            <?php if (layout_get_option('main_logo') != '') { ?>
            <a href="<?php echo home_url(); ?>"> <img src="<?php echo layout_get_option('main_logo'); ?>" alt="<?php bloginfo('name'); ?>"> </a>
            <?php } else { ?>
            <div class="logo-header">
              <h1><a href="<?php echo home_url(); ?>">
                <?php bloginfo('name'); ?>
                </a></h1>
              <p>
                <?php bloginfo('description'); ?>
              </p>
            </div>
            <?php } ?>
          </div>
       

          </div>
  <?php if(wp_is_mobile()) { 

} else { ?>
        <div class="col-12 col-lg-8 col-md-8">
                    <nav class="menu-sp">
               <!--   <?php if (is_front_page()) { ?>
            <?php layout_frontpage_nav() ?>
            <?php } else { ?>
            <?php layout_nav(); ?>
            <?php } ?> -->
      <ul class="sf-menu">
<?php
if ( is_user_logged_in() ) {
  ?>
<li class="btn-log"><span><a href="<?php echo site_url('/dashboard/')?>" aria-current="page">Dashboard</a></span></li>  
<li class="btn-log"><span><a href="<?php echo wp_logout_url('login/'); ?>">Logout</a></span></li> 
  <?php
}
else
{
  ?>
<li class="btn-log"><span><a href="<?php echo site_url('/login/')?>">Account Login</a></span></li>
<!--li class="btn-log"><span><a href="<?php echo site_url('/register/')?>">Register</a></span></li-->
<?php
}
?>
    </ul>
          </nav>
        </div>
<?php } ?>
        </div>
      </div>
    </div>
  </div>



<!-- MENU BOTTOM LOGO -->


<!-- Header Ends -->