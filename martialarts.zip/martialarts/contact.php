<?php

/**

 * 

  Template Name: Contact

 *

 */

get_header();

?>

<!-- Contact Page Starts -->

 <?php if (have_posts()) while (have_posts()) : the_post(); 
 $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
?>
     <div class="innner-page-title" style="<?php if($url!="") { ?>background-image:url('<?php echo $url; ?>'); <?php }  else { ?> background-image:url('<?php echo get_template_directory_uri(); ?>/images/custom-bg.jpg')<?php } ?>">
                  <h1 class="post-page-head"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">
                <?php the_title(); ?>
                </a></h1>

     </div>

<?php endwhile; ?>
<?php ?>
<div class="blogpost-wrapper">
  <div class="container">
      <div class="blogpost-content">
         <div class="row">

 





          <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="loc"> <span><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;&nbsp;</span>  <?php echo layout_get_option('street_address'); ?><br>
                    <?php echo layout_get_option('address_city'); ?><br>
 <?php echo layout_get_option('address_state'); ?> <?php echo layout_get_option('address_zip'); ?></div>
                  <br>
                  <div class="loc"> <span><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;&nbsp;</span> <?php echo layout_get_option('contact_phone'); ?> </div>
                  <div class="loc"> <span><i class="fa fa-fax" aria-hidden="true"></i>&nbsp;&nbsp;</span> <?php echo layout_get_option('contact_fax'); ?> </div>
                  <div class="loc"> <span><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp;&nbsp;</span><?php echo layout_get_option('time_hours'); ?> </div>
                </div>



        <div class="col-12 col-sm-12 col-md-6 col-lg-6"> 
           <?php if (have_posts()) while (have_posts()) : the_post(); ?>
          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-page page-contact">
         
              <?php the_content(); ?>
            </div>
            <?php endwhile; ?>
            <div class="contact-container clearfix"> 
              
              <!-- social icons starts -->
              
              <div class="saperator animated bottom-to-top">
                <ul class="social-icons">
                  <?php if (layout_get_option('layout_facebook') != '') { ?>
                  <li class="fb"><a href="<?php echo layout_get_option('layout_facebook'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                  <?php if (layout_get_option('layout_twitter') != '') { ?>
                  <li class="tw"><a href="<?php echo layout_get_option('layout_twitter'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                  <?php if (layout_get_option('layout_google') != '') { ?>
                  <li class="gp"><a href="<?php echo layout_get_option('layout_google'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                  <?php if (layout_get_option('layout_rss') != '') { ?>
                  <li class="rs"><a href="<?php echo layout_get_option('layout_rss'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                  <?php if (layout_get_option('layout_pinterest') != '') { ?>
                  <li class="pn"><a href="<?php echo layout_get_option('layout_pinterest'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                  <?php if (layout_get_option('layout_linkedin') != '') { ?>
                  <li class="ln"><a href="<?php echo layout_get_option('layout_linkedin'); ?>" target="_blank"></a></li>
                  <?php } else {} ?>
                </ul>
              </div>
              
              <!-- social icons starts Ends --> 
              
            </div>
          </div>
          
          <!-- Post loop ends -->
          
          <div class="clearfix"></div>

          
        </div>
      </div>
    </div>
  </div>
</div> 
 
<?php get_footer(); ?>
