<?php
/**
 * The Sidebar containing the main widget area
 *
 */
?>
<div class="sidebar-home">
        <div class="first-box bdr-btm">
        <img src="<?php echo layout_get_option('first_column_image'); ?>" alt="" />
        </div>

        <div class="second-box bdr-btm">
            <h3><?php echo layout_get_option('second_column_title'); ?></h3>
            <a href="<?php echo layout_get_option('second_column_button_link'); ?>"><img src="<?php echo layout_get_option('second_column_image'); ?>" alt="" /></a>
            <p><?php echo layout_get_option('second_column_desc'); ?></p>
        </div>


    <div class="third-box bdr-btm">

            <a href="<?php echo layout_get_option('third_column_button_link'); ?>"><img src="<?php echo layout_get_option('third_column_image'); ?>" alt="" /></a>
            <p><?php echo layout_get_option('third_column_desc'); ?></p>
        </div>


<div class="fourth-box bdr-btm">
    <h3><?php echo layout_get_option('fourth_column_heading'); ?></h3>
           
            <a href="<?php echo layout_get_option('fourth_column_image_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('fourth_column_image'); ?>" alt="" /></a>

            <a href="<?php echo layout_get_option('fourth_column_image_one_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('fourth_column_image_one'); ?>" alt="" /></a>

            <a href="<?php echo layout_get_option('fourth_column_image_one_two_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('fourth_column_image_two'); ?>" alt="" /></a>
            
        </div>


<div class="five-box">
           
            <a href="<?php echo layout_get_option('fifth_column_button_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('fifth_column_image'); ?>" alt="" /></a>

            <a href="<?php echo layout_get_option('fifth_column_button_link'); ?>" target="_blank"><img src="<?php echo layout_get_option('fifth_column_image_one'); ?>" alt="" /></a>

          
            
        </div>

    </div>