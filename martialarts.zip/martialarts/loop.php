<!-- Post1 Starts -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <div class="post-page">
    <h1 class="post-page-head"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
      <?php the_title(); ?>
      </a></h1>
    
    <?php if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())) { ?>
    <?php layout_get_thumbnail(798,
                            398);
                    ?>
    <?php } else { ?>
    <img src=" https://via.placeholder.com/800x400" alt="">
    <?php
                }
                ?>
				<?php the_excerpt(); ?>
    <a href="<?php the_permalink() ?>" class="more-btn">Read More</a> </div>
</div>
<?php
    endwhile;
else:
    ?>
<div>
  <p>
    <?php _e('Sorry no post matched your criteria',
            'layout'); ?>
  </p>
</div>
<?php endif; ?>
<div class="clearfix"></div>
<!-- Post1 Starts Ends -->