<?php

/*

  Template Name: Register

 */



get_header();

?>

<!-- Fullwidth page Starts -->

<div class="inner-title">
  
    <h1 class="post-page-head"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">
                <?php the_title(); ?>
                </a></h1> 
</div>

<main class="blogpost-wrapper">
  <div class="container">
    <div class="row">
      <div class="blogpost-content">
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <?php if (have_posts()) while (have_posts()) : the_post(); ?>
          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-page" style="margin-right: 0;">
    
              						<div class="register">
									

<?php
global $wpdb, $user_ID; 

//Check whether the user is already logged in 
if (!$user_ID) {

// Default page shows register form. 
// To show Login form set query variable action=login
$action = (isset($_GET['action']) ) ? $_GET['action'] : 0;


 // Register Page ?>

<?php
if ( $_POST['submit']=='SignUp' ) {

$error = 0;

$username = esc_sql($_REQUEST['username']); 
if ( empty($username) ) {

echo '<div class="col-12 register-error">User name should not be empty.</div>'; 
$error = 1;
}

$email = esc_sql($_REQUEST['email']);
if ( !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email) ) { 

echo '<div class="col-12 register-error">Please enter a valid email.</div>';
$error = 1;
}

$pass1 = esc_sql($_REQUEST['pass1']); 
$pass2 = esc_sql($_REQUEST['pass2']);
if ( empty($pass1) ) {

echo '<div class="col-12 register-error">Password should not be empty.</div>'; 
$error = 1;
}

if ( isset( $pass1 ) && $pass1 != $pass2 ) {
						
						echo '<div class="col-12 register-error">The passwords do not match.</div>'; 
$error = 1;
}

if ( empty($_REQUEST['agent_code'])) {
			
echo '<div class="col-12 register-error">Please select agent code.</div>'; 
$error = 1;
}
else
{
	
	$res_agentcodes = $wpdb->get_var("SELECT id FROM agent_code where agent_code='".$_REQUEST['agent_code']."' and  status=1");
	if(!$res_agentcodes){ 

		echo '<div class="col-12 register-error">This Agent Code is not valid.</div>'; 
		$error = 1;
	}
}


if ( $error == 0 ) {

//$random_password = wp_generate_password( 12, false ); 
$random_password = $pass1;
$user_id = wp_create_user( $username, $random_password, $email ); 

if ( is_wp_error($user_id) ) {

echo '<div class="col-12 register-error">Username already exists. Please try another one.</div>'; 
} else {

$from = get_option('admin_email'); 
update_user_meta( $user_id, 'first_name', $first_name );
			update_user_meta( $user_id, 'last_name', $last_name );
			update_user_meta( $user_id, 'user_type', $user_type );
			update_user_meta( $user_id, 'company_name', '' ); 
			update_user_meta( $user_id, 'agent_code', $res_agentcodes);
			update_user_meta( $user_id, 'user_type', 1); 			
		
			//update_user_meta( $user_id, $wpdb->prefix . 'capabilities', array('subscriber' => true) );
			
			update_user_meta( $user_id, $wpdb->prefix . 'capabilities', array('inactive' => true) );
			
			$admin_email = get_option( 'admin_email' ); 
		
			$headers[]= "MIME-Version: 1.0\n";
			$headers[]= "Content-Type: text/html; charset=utf-8\n";
			$headers[]= "From:" . $user_email;
			if (layout_get_option('cbi_register_bcc') != '') 
			{
				$bcc_to=explode(',',layout_get_option('cbi_register_bcc'));
				foreach($bcc_to as $email){
					$headers[] = 'Bcc: '.$email;
					
				}
			}
			if (layout_get_option('cbi_register_subject') != '') 
			{
				$subject = layout_get_option('cbi_register_subject');
			}
			else
			{
				$subject = "New user has registered to CBICustomsbonds.com";
			}
			 
		
			
			$message='<!DOCTYPE HTML><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CBI E-mail Template</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:32px;
	font-family:Arial, Helvetica, sans-serif;
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background: #005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}

.btn-green
{width: auto;
    padding: 5px 20px;
    background: #98ce7e;
    font-size: 16px;
    font-weight: 600;}
	


.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background: #DCDCDC;
}
table {
	font-size:14px;
}
table p {
	font-size:10pt;
	line-height:25px;
	padding-bottom:15px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:12px;
	line-height:20px;
}
table .tableBox {
	font-size:12px;
}
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}
table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}

 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="'.site_url().'"><img src="'.site_url().'/images/logo.png" alt="" height="45" border="0" /></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr bgcolor="#ffffff">
          <td align="center" valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="20"></td>
            </tr>
            <tr>
              <td><p>New user '.$email.' has  registered on the site. <br><br>
						Please Login and approve the user</p></td>
            </tr>
			 <tr>
              <td><p><strong>Please login at: </strong> '.site_url("login").'</p></td>
            </tr> 
			
            <tr>
              <td height="10"></td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
  <tr bgcolor="#69c4a9">
   <td align="center">CBI Inc. | Ph:843-249-1994 <br> 1632 Crosswinds Avenue, North Myrtle Beach, SC 29582</td>
  </tr>
 
  
</table>
</body>
</html>';	
			//$loginUrl = '<a href="'.site_url().'/login">'.site_url().'/login</a>';
					
			$message = "$message\r\n<br>";
			//$message .= "Login Url: $loginUrl\r\n<br>";

			$subject = $subject;
			
			if (layout_get_option('cbi_register_to') != '') 
			{
				$to = layout_get_option('cbi_register_to');
			}
			else
			{
				$to = $admin_email;
			}
			
			wp_mail($to, $subject, $message, $headers);
			
			/*---Send mail to agent code email---*/
			$res_agentcode_email = $wpdb->get_var("SELECT agent_code_email FROM agent_code where agent_code='".$_REQUEST['agent_code']."' and  status=1");
			if($res_agentcode_email)
			{
				wp_mail($res_agentcode_email, $subject, $message, $headers);
			}
			/*---End of send mail to agent code email---*/

echo "Please check your email for login details."; 

$error = 2; // We will check for this variable before showing the sign up form. 
}
}

}

if ( $error != 2 ) { ?> 

<?php if(get_option('users_can_register')) { ?>

<div class="col-md-12 manual-register-form">

<form action="" method="post"> 
<p> 
<label for="user_login">Username</label>
<input type="text" name="username" placeholder="Enter your Username Here" class="register-input mb-4" value="<?php if( ! empty($username) ) echo $username; ?>" /><br />
</p>
<p> 
<label for="user_email">Email</label>
<input type="text" name="email" placeholder="Enter your Email" class="register-input mb-4" value="<?php if( ! empty($email) ) echo $email; ?>" /> <br /> 
</p>
<p> 
<label for="agent_code">Registration Code</label>
<input type="text" name="agent_code" placeholder="Enter Registration Code" class="register-input mb-4" value="<?php if( ! empty($agent_code) ) echo $agent_code; ?>" /> <br /> 
</p>

<p> 
<label for="pass1">Password</label>
<input autocomplete="off" name="pass1" id="pass1" class="input" value="" type="password"> <br /> 
</p>
<p> 
<label for="pass2">Confirm Password</label>
<input autocomplete="off" name="pass2" id="pass2" class="input" size="20" value="" type="password"> <br /> 
</p>
<input type="submit" id="register-submit-btn" class="mb-4" name="submit" value="SignUp" /> 
</form>

<p class="text-center" style="padding-top:15px;">Already have an account? <a href="/login">Login Here</a></p>

</div>

<?php } else {

echo "Registration is currently disabled. Please try again later."; 

}

} ?>

<?php 

} else { ?>

<p>You are logged in. Click <a href="<?php bloginfo('wpurl'); ?>">here to go home</a></p>

<?php } ?>

</div>
            </div>
          </div>
          <?php endwhile; ?>
          <div class="clearfix"></div>
          <div class="clearfix"></div>
        </article>
      </div>
    </div>
  </div>
</main>
<?php get_footer(); ?>
