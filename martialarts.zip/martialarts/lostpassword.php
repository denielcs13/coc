<?php
/*
Template Name: Password Reset

*/
global $wpdb, $user_ID;

function tg_validate_url() {
	global $post;
	$page_url = esc_url(get_permalink( $post->ID ));
	$urlget = strpos($page_url, "?");
	if ($urlget === false) {
		$concate = "?";
	} else {
		$concate = "&";
	}
	return $page_url.$concate;
}

if (!$user_ID) { //block logged in users

	if(isset($_GET['key']) && $_GET['action'] == "reset_pwd") {
		$reset_key = $_GET['key'];
		$user_login = $_GET['login'];
		$user_data = $wpdb->get_row($wpdb->prepare("SELECT ID, user_login, user_email FROM $wpdb->users WHERE user_activation_key = %s AND user_login = %s", $reset_key, $user_login));
		
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		if (layout_get_option('cbi_forgot_subject') != '') 
			{
				$subject = layout_get_option('cbi_forgot_subject');
			}
			else
			{
				$subject = 'Password Reset Request';
			}
		
		if(!empty($reset_key) && !empty($user_data)) {
			$new_password = wp_generate_password(7, false);
				//echo $new_password; exit();
				wp_set_password( $new_password, $user_data->ID );
				//mailing reset details to the user
		/* 	$message = __('Your new password for the account at:') . "\r\n\r\n";
			$message .= get_option('siteurl') . "\r\n\r\n";
			$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
			$message .= sprintf(__('Password: %s'), $new_password) . "\r\n\r\n";
			$message .= __('You can now login with your new password at: ') . get_option('siteurl')."/login" . "\r\n\r\n"; */
			
						$message='<!DOCTYPE HTML><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Martial Arts Registration E-mail Template</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:32px;
	font-family:Arial, Helvetica, sans-serif;
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background: #005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}

.btn-green
{width: auto;
    padding: 5px 20px;
    background: #98ce7e;
    font-size: 16px;
    font-weight: 600;}
	


.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background: #DCDCDC;
}
table {
	font-size:14px;
}
table p {
	font-size:10pt;
	line-height:25px;
	padding-bottom:15px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:12px;
	line-height:20px;
}
table .tableBox {
	font-size:12px;
}
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}
table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}

 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="'.site_url().'"><img src="'.site_url().'/images/logo.png" alt="" height="45" border="0" /></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr bgcolor="#ffffff">
          <td align="center" valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="20"></td>
            </tr>
            <tr>
              <td><p>Your new password for the account at <br>
			  <br>'.get_option('siteurl').'<br/><br/></p></td>
            </tr>
			<tr>
              <td><strong>Username : </strong>'.$user_login.' </p></td>
            </tr>
			<tr>
              <td><strong>Password : </strong>'.$new_password.' </p></td>
            </tr>
			 <tr>
              <td><p>You can now login with your new password at: '.site_url("login").'</p></td>
            </tr> 
			
            <tr>
              <td height="10"></td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
  <tr bgcolor="#69c4a9">
   <td align="center">© 2019 Martial Arts Registration. All rights reserved.</td>
  </tr>
 
  
</table>
</body>
</html>';
			
			if ( $message && !wp_mail($user_email, $subject, $message) ) {
				$errorshow= "<div class='error'>Email failed to send for some unknown reason</div>";
				
			}
			else {
				$redirect_to = get_bloginfo('url')."/login?action=reset_success";
				wp_safe_redirect($redirect_to);
				exit();
			}
		} 
		else exit('Not a Valid Key.');
		
	}
	//exit();

	if($_POST['action'] == "tg_pwd_reset"){
		if ( !wp_verify_nonce( $_POST['tg_pwd_nonce'], "tg_pwd_nonce")) {
		 // exit("No trick please");
	   }  
		if(empty($_POST['user_input'])) {
			$errorshow= "<div class='error'>Please enter your Username or E-mail address</div>";
			
		}
		//We shall SQL escape the input
		$user_input = $wpdb->escape(trim($_POST['user_input']));
		
		if ( strpos($user_input, '@') ) {
			$user_data = get_user_by_email($user_input);
			if(empty($user_data) || $user_data->caps[administrator] == 1) { //delete the condition $user_data->caps[administrator] == 1, if you want to allow password reset for admins also
			$errorshow="<div class='error'>Invalid E-mail address!</div>";
				
			}
		}
		else {
			$user_data = get_userdatabylogin($user_input);
			if(empty($user_data) || $user_data->caps[administrator] == 1) { //delete the condition $user_data->caps[administrator] == 1, if you want to allow password reset for admins also
				$errorshow="<div class='error'>Invalid Username!</div>";
				
			}
		}
		
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		
		$key = $wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login));
		if(empty($key)) {
			//generate reset key
			$key = wp_generate_password(20, false);
			$wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));	
		}
		
		//mailing reset details to the user
		/* $message = __('Someone requested that the password be reset for the following account:') . "\r\n\r\n";
		$message .= get_option('siteurl') . "\r\n\r\n";
		$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
		$message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
		$message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
		$message .= tg_validate_url() . "action=reset_pwd&key=$key&login=" . rawurlencode($user_login) . "\r\n"; */
		$resetlink='<a href="'.tg_validate_url() . 'action=reset_pwd&key='.$key.'&login=' . rawurlencode($user_login).'">'.tg_validate_url() . 'action=reset_pwd&key='.$key.'&login=' . rawurlencode($user_login).'</a>';
					$message='<!DOCTYPE HTML><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Martial Arts Registration E-mail Template</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:32px;
	font-family:Arial, Helvetica, sans-serif;
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background: #005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}

.btn-green
{width: auto;
    padding: 5px 20px;
    background: #98ce7e;
    font-size: 16px;
    font-weight: 600;}
	


.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background: #DCDCDC;
}
table {
	font-size:14px;
}
table p {
	font-size:10pt;
	line-height:25px;
	padding-bottom:15px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:12px;
	line-height:20px;
}
table .tableBox {
	font-size:12px;
}
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}
table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}

 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="'.site_url().'"><img src="'.site_url().'/images/logo.png" alt="" height="45" border="0" /></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr bgcolor="#ffffff">
          <td align="center" valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="20"></td>
            </tr>
            <tr>
              <td><p>Someone requested that the password be reset for the following account: <br><br>
						'.get_option('siteurl').'</p></td>
            </tr>
			<tr>
              <td><p><strong>Username: </strong> '.$user_login.' <br></p></td>
            </tr>
			<tr>
              <td><p>If this was a mistake, just ignore this email and nothing will happen.</p></td>
            </tr>
			<tr>
              <td><p>To reset your password, visit the following address: </p></td>
            </tr>
			 <tr>
              <td><p>'.$resetlink.'</p></td>
            </tr> 
			
            <tr>
              <td height="10"></td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
  <tr bgcolor="#69c4a9">
   <td align="center">© 2019 Martial Arts Registration. All rights reserved.</td>
  </tr>
 
  
</table>
</body>
</html>';
		
		if ( $message && !wp_mail($user_email, 'Password Reset Request', $message) ) {
			$errorshow="<div class='error'>Email failed to send for some unknown reason.</div>";
		
		}
		else {
			$message="<div class='success'>We have just sent you an email with Password reset instructions.</div>";
			
		}
		
	} 
get_header(); ?>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main lost-password" role="main">

			
<?php
if(isset($errorshow) && $errorshow!="")
{
	?>
<div class="error" style="color:red;text-agign:center;"><?php echo $errorshow;?></div><br/><br/>
<?php
}
?>

<?php
if(isset($message) && $message!="")
{
	?>
<?php echo $message;?><br/><br/>
<?php
}
?>
		    <div id="password-lost-form" class="widecolumn">
            <form class="user_form" id="wp_pass_reset" action="" method="post">	
            <label for="user_login">Username or E-mail:</label><br />	
			<input type="text" class="text" name="user_input" value="" /><br />
			<input type="hidden" name="action" value="tg_pwd_reset" />
			<input type="hidden" name="tg_pwd_nonce" value="<?php echo wp_create_nonce("tg_pwd_nonce"); ?>" />
			<input type="submit" id="submitbtn" class="reset_password" name="submit" value="Reset Password" />					
			</form>
			<div id="result"></div> <!-- To hold validation results -->
			<script type="text/javascript">  						
			$("#wp_pass_reset").submit(function() {			
			$('#result').html('<span class="loading">Validating...</span>').fadeIn();
			var input_data = $('#wp_pass_reset').serialize();
			$.ajax({
			type: "POST",
			url:  "<?php echo get_permalink( $post->ID ); ?>",
			data: input_data,
			success: function(msg){
			$('.loading').remove();
			$('<div>').html(msg).appendTo('div#result').hide().fadeIn('slow');
			}
			});
			return false;
			
			});
			</script>
</div>



		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .wrap -->

<?php
get_footer();

}
else {
	wp_redirect( home_url('login') ); exit;
	//redirect logged in user to home page
}
