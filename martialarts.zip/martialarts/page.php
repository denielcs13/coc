<?php

/**

 * The template for displaying all pages

 *

 * This is the template that displays all pages by default.

 * Please note that this is the WordPress construct of pages and that

 * other 'pages' on your WordPress site will use a different template.

 *

 */

get_header();

?>

<!-- Single Post Starts -->



<div class="clearfix"></div>
<div class="blogpost-wrapper">



  <div class="container">
<div class="blogpost-content">
         <div class="row">
        <div class="col-12 col-sm-12 col-md-8 col-lg-8"> 
          <div class="black-sec">
          
          <!-- Post loop starts --> 
          
          <!-- Post1 Starts -->
          
          <?php if (have_posts()) while (have_posts()) : the_post(); ?>
          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-page">
              <h1><?php the_title(); ?></h1>
            
              <?php the_content(); ?>
            </div>
          </div>
          <?php endwhile; ?>
          <div class="clearfix"></div>
          
          <!-- Post1 Starts Ends --> 
          
          <!-- Post loop ends --> 
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-4 col-lg-4">
          <?php get_sidebar(); ?>
        </div>
       
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
