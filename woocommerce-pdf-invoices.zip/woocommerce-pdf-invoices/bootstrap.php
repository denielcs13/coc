<?php
/**
 * Plugin Name:       WooCommerce PDF Invoices
 * Plugin URI:        https://wordpress.org/plugins/woocommerce-pdf-invoices
 * Description:       Automatically generate and attach customizable PDF Invoices to WooCommerce emails and connect with Dropbox, Google Drive, OneDrive or Egnyte.
 * Version:           2.9.16
 * Author:            Bas Elbers
 * Author URI:        http://wcpdfinvoices.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       woocommerce-pdf-invoices
 * Domain Path:       /lang
 * WC requires at least: 2.6.14
 * WC tested up to: 3.4.4
 */

defined( 'ABSPATH' ) or exit;

/**
 * @deprecated instead use WPI_VERSION.
 */
define( 'BEWPI_VERSION', '2.9.16' );

define( 'WPI_VERSION', '2.9.16' );

/**
 * Load WooCommerce PDF Invoices plugin.
 */
function _bewpi_load_plugin() {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	/**
	 * @deprecated instead use `WPI_FILE`.
	 */
	if ( ! defined( 'BEWPI_FILE' ) ) {
		define( 'BEWPI_FILE', __FILE__ );
	}

	/**
	 * @deprecated instead use `WPI_DIR`.
	 */
	if ( ! defined( 'BEWPI_DIR' ) ) {
		define( 'BEWPI_DIR', plugin_dir_path( __FILE__ ) );
	}

	/**
	 * @deprecated instead use `plugin_basename( WPI_FILE )`.
	 */
	if ( ! defined( 'BEWPI_PLUGIN_BASENAME' ) ) {
		define( 'BEWPI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
	}

	if ( ! defined( 'WPI_FILE' ) ) {
		define( 'WPI_FILE', __FILE__ );
	}

	if ( ! defined( 'WPI_DIR' ) ) {
		define( 'WPI_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
	}

	if ( file_exists( WPI_DIR . '/vendor/autoload.php' ) ) {
		require_once WPI_DIR . '/vendor/autoload.php';
	}

	/**
	 * Main instance of BE_WooCommerce_PDF_Invoices.
	 *
	 * @since  2.5.0
	 * @deprecated Use WPI() instead.
	 *
	 * @return BE_WooCommerce_PDF_Invoices
	 */
	function BEWPI() {
		return BE_WooCommerce_PDF_Invoices::instance();
	}
	BEWPI();

	/**
	 * Main instance of BE_WooCommerce_PDF_Invoices.
	 *
	 * @since  2.9.1
	 * @return BE_WooCommerce_PDF_Invoices
	 */
	function WPI() {
		return BE_WooCommerce_PDF_Invoices::instance();
	}
	WPI();

	if ( is_admin() ) {
		_bewpi_on_plugin_update();
	}
}
add_action( 'plugins_loaded', '_bewpi_load_plugin', 10 );

/**
 * On plugin update.
 *
 * @since 2.5.0
 */
function _bewpi_on_plugin_update() {
	$current_version = get_site_option( 'bewpi_version' );

	if ( false === $current_version ) {

		// First time creation of directories.
		WPI()->setup_directories();

		add_site_option( 'bewpi_version', WPI_VERSION );

	} elseif ( WPI_VERSION !== $current_version ) {

		// Update directories.
		WPI()->setup_directories();

		// temporary change max execution time to higher value to prevent internal server errors.
		$max_execution_time = (int) ini_get( 'max_execution_time' );
		if ( 0 !== $max_execution_time ) {
			set_time_limit( 360 );
		}

		// version 2.6.1- need to be updated with new email options and postmeta.
		if ( version_compare( $current_version, '2.6.1' ) <= 0 ) {
			update_email_type_options();
			update_postmeta();
		}

		// version 2.7.0- uploads folder changed to uploads/woocommerce-pdf-invoices.
		if ( version_compare( $current_version, '2.7.0' ) <= 0 ) {
			// Move invoice from uploads/bewpi-invoices to uploads/woocommerce-pdf-invoices/attachments.
			move_pdf_invoices();

			// Rename uploads/bewpi-templates/invoices to uploads/bewpi-templates/invoice.
			$upload_dir = wp_upload_dir();
			rename( BEWPI_CUSTOM_TEMPLATES_INVOICES_DIR, $upload_dir['basedir'] . '/bewpi-templates/invoice' );
		}

		// version 2.9.2- need to update "Attach to Emails" option to recursive structure.
		if ( version_compare( $current_version, '2.9.2' ) <= 0 ) {
			update_email_types_options_to_recursive();
		}

		if ( version_compare( $current_version, '2.9.3' ) <= 0 ) {
			update_email_types_options();
		}

		set_time_limit( $max_execution_time );

		update_site_option( 'bewpi_version', WPI_VERSION );
	}
}

/**
 * "Attach to Email" and "Attach to new order email" options changed to multi-checkbox, so update settings accordingly.
 *
 * @since 2.5.0
 */
function update_email_type_options() {
	$general_options = get_option( 'bewpi_general_settings' );
	// check if we need to add and/or remove options.
	if ( isset( $general_options['bewpi_email_type'] ) ) {
		$email_type = $general_options['bewpi_email_type'];
		if ( ! empty( $email_type ) ) {
			// set new email type option.
			$general_options[ $email_type ] = 1;
		}
		// delete old option.
		unset( $general_options['bewpi_email_type'] );

		update_option( 'bewpi_general_settings', $general_options );
	}

	if ( isset( $general_options['bewpi_new_order'] ) ) {
		$email_type = $general_options['bewpi_new_order'];
		if ( $email_type ) {
			// set invoice attach to new order email option.
			$general_options['new_order'] = 1;
		}
		// delete old option.
		unset( $general_options['bewpi_new_order'] );

		update_option( 'bewpi_general_settings', $general_options );
	}
}

/**
 *  Update postmeta in database.
 */
function update_postmeta() {
	$posts = get_posts( array(
		'numberposts' => -1,
		'post_type'   => 'shop_order',
		'post_status' => array_keys( wc_get_order_statuses() ),
		'fields'      => 'ids',
	) );

	$template_options = get_option( 'bewpi_template_settings' );

	$date_format = $template_options['bewpi_date_format'];
	if ( empty( $date_format ) ) {
		$date_format = (string) get_option( 'date_format' );
	}

	foreach ( $posts as $post_id ) {
		// Create pdf path postmeta for all shop orders.
		create_pdf_path_postmeta( $post_id, $template_options );

		// Format date postmeta to mysql date.
		update_date_format_postmeta( $post_id, $date_format );
	}
}

/**
 * Create full path postmeta for all orders that have a pdf invoice generated.
 *
 * @param int   $post_id Post ID or WC Order ID.
 * @param array $template_options User template options.
 *
 * @since 2.6.0
 */
function create_pdf_path_postmeta( $post_id, $template_options ) {
	$pdf_path = get_post_meta( $post_id, '_bewpi_invoice_pdf_path', true );
	if ( $pdf_path ) {
		return;
	}

	$formatted_invoice_number = get_post_meta( $post_id, '_bewpi_formatted_invoice_number', true );
	if ( ! $formatted_invoice_number ) {
		return;
	}

	// One folder for all invoices.
	$new_pdf_path = $formatted_invoice_number . '.pdf';
	if ( (bool) $template_options['bewpi_reset_counter_yearly'] ) {
		// Yearly sub-folders.
		$invoice_year = get_post_meta( $post_id, '_bewpi_invoice_year', true );
		if ( $invoice_year ) {
			$new_pdf_path = $invoice_year . '/' . $formatted_invoice_number . '.pdf';
		}
	} else {
		$new_pdf_path = $formatted_invoice_number . '.pdf';
	}

	if ( file_exists( BEWPI_INVOICES_DIR . $new_pdf_path ) ) {
		update_post_meta( $post_id, '_bewpi_invoice_pdf_path', $new_pdf_path );
	}
}

/**
 * Format date postmeta to mysql date.
 *
 * @param int    $post_id Post ID or WC Order ID.
 * @param string $date_format User option date format.
 *
 * @since 2.6.0
 */
function update_date_format_postmeta( $post_id, $date_format ) {
	$invoice_date = get_post_meta( $post_id, '_bewpi_invoice_date', true );
	if ( ! $invoice_date ) {
		return;
	}

	$date = DateTime::createFromFormat( $date_format, $invoice_date );
	if ( ! $date ) {
		return;
	}

	update_post_meta( $post_id, '_bewpi_invoice_date', $date->format( 'Y-m-d H:i:s' ) );
}

/**
 * Move all invoices to new uploads dir.
 */
function move_pdf_invoices() {
	$files = glob( BEWPI_INVOICES_DIR . '/*' );
	foreach ( $files as $file ) {

		if ( is_dir( $file ) ) {
			wp_mkdir_p( WPI_ATTACHMENTS_DIR . '/' . basename( $file ) );

			$files_year = glob( $file . '/*' );
			foreach ( $files_year as $file_year ) {
				if ( is_file( $file_year ) ) {
					$pdf_path = str_replace( BEWPI_INVOICES_DIR . '/', '', $file_year );
					copy( $file_year, WPI_ATTACHMENTS_DIR . '/' . $pdf_path );
				}
			}

			continue;
		}

		copy( $file, WPI_ATTACHMENTS_DIR . '/' . basename( $file ) );
	}
}

/**
 * Update email types options to recursive array structure.
 */
function update_email_types_options_to_recursive() {
	$general_options = get_option( 'bewpi_general_settings' );
	$email_types     = array( 'new_order', 'customer_on_hold_order', 'customer_processing_order', 'customer_completed_order', 'customer_invoice', 'new_renewal_order', 'customer_completed_switch_order', 'customer_processing_renewal_order', 'customer_completed_renewal_order', 'customer_renewal_invoice' );

	foreach ( $email_types as $email_type ) {
		if ( isset( $general_options[ $email_type ] ) ) {
			$general_options['bewpi_email_types'] = array(
				$email_type => $general_options[ $email_type ],
			);

			// Remove older option.
			unset( $general_options[ $email_type ] );
		}
	}

	update_option( 'bewpi_general_settings', $general_options );
}

/**
 * Update email types for plugin version 2.9.4+.
 */
function update_email_types_options() {
	$general_settings = get_option( 'bewpi_general_settings' );
	$email_types = array();

	foreach ( (array) $general_settings['bewpi_email_types'] as $email_type => $enabled ) {
		if ( $enabled ) {
			$email_types[] = $email_type;
		}
	}

	$general_settings['bewpi_email_types'] = $email_types;

	update_option( 'bewpi_general_settings', $general_settings );
}

/**
 * Save install date, plugin version to db and set transient to show activation notice.
 *
 * @since 2.5.0
 */
function _bewpi_on_plugin_activation() {
	add_site_option( 'bewpi_install_date', current_time( 'mysql' ) );
	set_transient( 'bewpi-admin-notice-activation', true, 30 );
}
register_activation_hook( __FILE__, '_bewpi_on_plugin_activation' );
