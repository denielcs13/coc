<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Openassessment extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->load->library('form_validation');
		$this->common->check_login();
	}
	
	public function index(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('openassessment',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data['page'] = 'assessment_list';
		$this->load->library('pagination');
		$config['base_url'] = base_url('openassessment/index');
		$config['total_rows'] = $this->sm->num_assessment();
		$config['per_page'] = 10;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['role_list'] = $this->sm->get_assessment_list($config["per_page"], $page);
		$this->load->view('assessment/assessment_list',$data);
		
	}
	
	/*
	* Add functionality for Category module
	*/
	public function add(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		$emp_id = $this->session->userdata('emp_id');
		if(!in_array('roles/add',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$permisssion = array();
		$data['page'] = 'assessment';
		
		if($this->uri->segment(3) != ''){
			redirect(base_url('openassessment'));
		}
		if($this->input->post('submit') == 'Add Role'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('period_from', 'Period From', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
		
					$submi_from2=explode("/",$submi_from);
					$submi_from1=$submi_from2[2].'-'.$submi_from2[0].'-'.$submi_from2[1];
					
					$submi_to2=explode("/",$submi_to);
					$submi_to1=$submi_to2[2].'-'.$submi_to2[0].'-'.$submi_to2[1];
					$role_detail = array(
						'period_from' => $period_from,
						'period_to' => $period_to,
						'submi_from' => $submi_from1,
						'submi_to' => $submi_to1,						
						'user_id' => $emp_id
					);
					
					//Inserting Role
					$role_id = $this->common->insert_record('tbl_open_assessment',$role_detail);
					
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Assessment added successfully!</p>');
					
					redirect(base_url('openassessment'));
				
			}
		}
		$data['all_modules'] = $this->common->get_selected_columns('tbl_modules',$columns = array(),$where=array(),'multiple',$obj=true);
		$data['modules_action'] = $this->common->get_selected_columns('tbl_modules_action',$columns = array(),$where=array(),'multiple',$obj=true);
		$this->load->view('assessment/add_assessment',$data);
	}
	
	/*
	* Add functionality for Category module
	*/
	public function edit($role_id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		$emp_id = $this->session->userdata('emp_id');
		if(!in_array('openassessment/edit',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		
		$data['page'] = 'openassessment';
		if($this->uri->segment(3) == ''){
			redirect(base_url('openassessment'));
		}
		/*
		Get/Edit Indivisual Role detail by id 
		*/
		if(!empty($role_id)){
			$data['role'] = $this->common->get_selected_columns('tbl_open_assessment',$columns = array('asid','period_from','period_to','submi_from','submi_to'),$where = array('asid'=>$role_id),$reocrd = 'single',$obj=true);
			
			
			
		}
		
		if($this->input->post('submit') == 'Add Role'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('period_from', 'Period From', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
			
					
					$submi_from2=explode("/",$submi_from);
					$submi_from1=$submi_from2[2].'-'.$submi_from2[0].'-'.$submi_from2[1];
					
					$submi_to2=explode("/",$submi_to);
					$submi_to1=$submi_to2[2].'-'.$submi_to2[0].'-'.$submi_to2[1];
					$role_detail = array(
						'period_from' => $period_from,
						'period_to' => $period_to,
						'submi_from' => $submi_from1,
						'submi_to' => $submi_to1,						
						'user_id' => $emp_id
					);
				
					if(!empty($role_id)){
						
						//updating Role
						$update = $this->common->update_record('tbl_open_assessment',array('asid'=>$role_id),$role_detail);
						if($update){
					
							$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Assessment updated successfully!</p>');
						}
					}
					redirect(base_url('openassessment'));
				
			}
		}
		$data['all_modules'] = $this->common->get_selected_columns('tbl_modules',$columns = array(),$where=array(),'multiple',$obj=true);
		$data['modules_action'] = $this->common->get_selected_columns('tbl_modules_action',$columns = array(),$where=array(),'multiple',$obj=true);
		
		$this->load->view('assessment/add_assessment',$data);
	}
	
	public function delete($id){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('openassessment/delete',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$delete_role = $this->common->delete_record('tbl_open_assessment',array('asid'=>$id));
		
		if($delete_role){
			
						
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Assessment deleted successfully!</p>');
			redirect(base_url('openassessment'));
			
		}else{
			
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
			
		}
	}
}