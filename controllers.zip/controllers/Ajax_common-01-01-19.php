<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_common extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->common->check_login();
	}
	
	public function get_manager_list($id=''){
		$result = array();
		$result['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('id','CONCAT(first_name," ",last_name) as name','email'),array('role_id'=>3,'id !='=>$id),'multiple',$obj=true);
		$result['success'] = true;
		echo json_encode($result);die;
	}
	public function delete_record(){
		
		$result = array();
		$id = $this->input->post('row_id');
		$table = $this->input->post('record_frm');
		$del_slry = $this->common->delete_record($table,array('id'=>$id));
		$result['success'] = ($del_slry) ? true : false;
		echo json_encode($result);die;
	}
	/*Send self assessment review to employee after adding question part is finished*/
	public function send_review_employee(){
		$result = array();
		$emp_id = $this->input->post('emp_id');
		$prev_review_status = $this->input->post('prev_review_status');
		$review_status = $this->input->post('review_status');
		$updated = $this->common->update_record('tbl_assign_question',array('emp_id'=>$emp_id,'status'=>1,'review_status'=>$prev_review_status),array('review_status'=>$review_status));
		if($updated){
			$result['success'] = true;
			$result['msg'] = 'Sent successfully !';
		}else{
			$result['success'] = false;
			$result['msg'] = 'Server error, Please try after some time !';
		}
		echo json_encode($result);die;
	}
	public function save_self_assessment(){
		$result = array();
		$post = $this->input->post();
		extract($post);
		if($type == 'review'){
			//$result['title'] = 'Remarks';
			$result['title'] = '';
			if($this->common->update_record('tbl_assign_question',array('assign_id'=>$assign_id),array('remarks'=>$answer))){
				$blank_remarks = $this->common->get_selected_columns('	tbl_assign_question',array('assign_id'),array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id,'remarks'=>''),'multiple');
				$count_blank_remarks = count($blank_remarks);
				if($count_blank_remarks == 0){
					//$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>3));
					$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>2));
				}
				$result['success'] = true;
			}else{
				$result['success'] = false;
			}
		}
		if($type == 'self asmnt'){
			$result['title'] = 'Review';
			$sa_answer = '';
			$empty = 1;
			foreach($answer as $ans){
				if($ans != ''){
					$empty--;
					break;
				}
			}
			if($empty == 0 && !empty($answer)){
				$sa_answer = json_encode($answer);
			}
			
			$update = $this->common->update_record('tbl_assign_question',array('assign_id'=>$assign_id),array('answer'=> $sa_answer));
			
			if($update){
				$result['success'] = true;
			}else{
				$result['success'] = false;
			}
		}
		echo json_encode($result);die;
	}
	
	/*----Send question to manager----*/
	public function send_review_manager(){
		$result = array();
		$emp_id = $this->input->post('emp_id');
		$prev_review_status = $this->input->post('prev_review_status');
		$review_status = $this->input->post('review_status');
		$updated = $this->common->update_record('tbl_teamassign_question',array('emp_id'=>$emp_id,'status'=>1,'review_status'=>$prev_review_status),array('review_status'=>$review_status));
		if($updated){
			$result['success'] = true;
			$result['msg'] = 'Sent successfully !';
		}else{
			$result['success'] = false;
			$result['msg'] = 'Server error, Please try after some time !';
		}
		echo json_encode($result);die;
	}
	/*----End of Send question to manager----*/
}