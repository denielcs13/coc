<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
error_reporting(1);
ini_set('display_errors', 1);  
class Staff extends CI_Controller {
	
	function __construct(){
		
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->load->model('question_model','qm');
		$this->load->library('form_validation');
		$this->load->library('general_functions');
		$this->load->helper('genral_helper');
		
	}
	public function index($role_name=""){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		if($role_name=='all-team-list')
		{
		
		$data['role_name'] = $role_name;
		$data['page'] = 'staff_list';
		$this->load->library('pagination');
		$role_id = (isset($role->id) && !empty($role->id)) ? $role->id : '';
		
		$config['base_url'] = base_url('staff/index/'.$role_name.'/');
		
		$config['total_rows'] = $this->sm->num_all_leader();
		$config['per_page'] = 10;
		$config['uri_segment'] = 4;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['leader_list'] = $this->sm->all_leader_list($config["per_page"], $page);
		$this->load->view('staff/all_team_list',$data);
		}
		else
		{
		
		$data['role_name'] = $role_name;
		$data['page'] = 'staff_list';
		$this->load->library('pagination');
		/*Gettin role id for the employee list by their role*/
		$role = $this->common->get_selected_columns('tbl_roles',$columns = array('id'),$where = array('LOWER(role_name)'=>urldecode(strtolower($role_name))),$reocrd = 'single',$obj=true);
		$role_id = (isset($role->id) && !empty($role->id)) ? $role->id : '';
		
		$config['base_url'] = base_url('staff/index/'.$role_name.'/');
		$config['total_rows'] = $this->sm->num_staffs($role_id);
		$config['per_page'] = 10;
		$config['uri_segment'] = 4;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['employee_list'] = $this->sm->get_staff_list($role_id,$config["per_page"], $page);
		$this->load->view('staff/staff_list',$data);
		}
	}
	
	public function not_authorized(){
		$this->load->view('not_authorized');
	}
	/*
	* Add functionality for Employee module
	*/
	public function add(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/add',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$salary_detail = array();
		$data['page'] = 'staff';
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('first_name', 'First name', 'trim|required');
			$this->form_validation->set_rules('last_name', 'Last name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('emp_role', 'Employee role', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
			$this->form_validation->set_rules('employee_id', 'Employee id', 'trim|required');
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_employee_exist($email,$id='');
				$check_emp_id = $this->sm->is_employee_id_exist($employee_id,$id='');
				if($this->input->post('join_dbi')!="")
				{
					$join_dbi=explode('/',$this->input->post('join_dbi'));
					$join_dbi=$join_dbi[2].'-'.$join_dbi[0].'-'.$join_dbi[1];
				}
				else
				{
					$join_dbi=date('Y-m-d');
				}
				if($check_existance){
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Email already exists!</p>');
				}else if($check_emp_id){
					$this->session->set_flashdata('empid_message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Id already taken!</p>');
				}else{
							$emp_image = $_FILES['emp_image']['name'];
				
					if (isset($emp_image) && !empty($emp_image)) {
						
					$config['upload_path']   =  './assets/images/staff_image/';
				
                $config['allowed_types']        = 'gif|jpg|png';
               

                $this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('emp_image') )
                {
                        $error = array('error' => $this->upload->display_errors());

                      
						$image=$this->input->post('file_path');
                }
				else{
					 $succ = array('upload_data' => $this->upload->data());
				  	$image = $succ['upload_data']['file_name'];
				}
						$del_img = './assets/images/staff_image/' . $this->input->post('hidden_emp_img');
						if ($this->input->post('hidden_emp_img') != '' && file_exists($del_img)) {
							unlink($del_img);
						}
					} else {
						$image = $this->input->post('hidden_emp_img');
					}
					$emp_detail = array(
						'first_name' => $first_name,
						'last_name' => $last_name,
						'email' => $email,
						'phone' => $phone,
						'role_id' => $emp_role,
						'manager_id'=>$manager_id,
						'status' => ($status == 1) ? 1 : 0,
						'created_at' => date('Y-m-d H:i:sa'),
						'password' => md5($password),
						'profile_img' => $image,
						'employee_id' => $employee_id,
						'join_dbi'=>$join_dbi,
					);
					$role_id = $this->session->userdata('role_id');
					if($role_id > 1){
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> You are not authorized for this action!</p>');
						//redirect(base_url('staff/'.strtolower($hidden_role_name)));
						redirect(base_url('staff/all-team-list'));
					}
					
					//Inserting employee
					$emp_id = $this->common->insert_record('tbl_employees',$emp_detail);
					if($emp_id){
						if(isset($from_date) && isset($to_date)){
							for($i=0;$i<count($from_date);$i++){
								if(!empty($from_date[$i]) && !empty($to_date[$i])){
								$salary_detail[] = array(
									'emp_id'=>$emp_id,
									'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
								);	
								}
							}
						}
						if(!empty($salary_detail)){
							$this->db->insert_batch('tbl_employee_salary_details',$salary_detail);
						}
						$message = 'Hi '.$first_name.' '.$last_name.',<br/>
						Your account has been created, Below are the credential to login to your account.<br/>
						Url: '.base_url().'<br/>
						Username/Email : '.$email.'<br/>
						Password : '.$password.'<br/>
						';
						$this->general_functions->send_email($from_email="testing10@iwesh.com", $from_name="Employee review", $to_email=$email, $subject="Employee Registration",$message,$protocol="");
						
						//sendmail($to = $email,$subject = 'Employee Registration',$message,$from = 'testing10@iwesh.com');
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee details added successfully!</p>');
						//redirect(base_url('staff/'.strtolower($hidden_role_name)));
						redirect(base_url('staff/all-team-list'));
						
					}else{
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some time!</p>');
					}
				}
			}
		}
		$emp_id="";
		$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('id','CONCAT(first_name," ",last_name) as name','email'),array('role_id'=>3,'id !='=>$emp_id),'multiple',$obj=true);
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/add_staff',$data);
	}
	
	public function edit($emp_id){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/edit',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$data = array();
		$data['page'] = 'staff';
		$data['userid'] = $emp_id;
		$update_salary_detail = array();
		$insert_salary_detail = array();
		/*
		Get/Edit Indivisual employee detail by id 
		*/
		if(!empty($emp_id)){
			$data['emp'] = $this->sm->get_staff_by_id($emp_id);
			$data['empstatus'] = $this->sm->get_staffinfo_by_id($emp_id);	
			if(isset($data['emp']->role_id) && $data['emp']->role_id == 4){
				$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('id','CONCAT(first_name," ",last_name) as name','email'),array('role_id'=>3,'id !='=>$emp_id),'multiple',$obj=true);
			}
			$data['salary_detail'] = $this->sm->staff_salary($emp_id);
		}
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('first_name', 'First name', 'trim|required');
			$this->form_validation->set_rules('last_name', 'Last name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('emp_role', 'Employee role', 'trim|required');
			$this->form_validation->set_rules('employee_id', 'Employee id', 'trim|required');
			
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_employee_exist($email,$emp_id);
				if($this->input->post('join_dbi')!="")
				{
					$join_dbi=explode('/',$this->input->post('join_dbi'));
					$join_dbi=$join_dbi[2].'-'.$join_dbi[0].'-'.$join_dbi[1];
				}
				else
				{
					$join_dbi=date('Y-m-d');
				}
				$check_emp_id = $this->sm->is_employee_id_exist($employee_id,$emp_id);
				if($check_existance){
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Email already exists!</p>');
				}else if($check_emp_id){
					$this->session->set_flashdata('empid_message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Id already taken!</p>');
				}else{
					$emp_image = $_FILES['emp_image']['name'];
					if (isset($emp_image) && !empty($emp_image)) {
						$config = [
							'upload_path' => './assets/images/staff_image/',
							'allowed_types' => 'jpg|png|jpeg'
						];
						$this->load->library('upload', $config);
						if ($this->upload->do_upload("emp_image")) {
							$filedata = $this->upload->data();
							$file_name = $filedata['file_name'];
							$image = $file_name;
						}
						$del_img = './assets/images/staff_image/' . $this->input->post('hidden_emp_img');
						if ($this->input->post('hidden_emp_img') != '' && file_exists($del_img)) {
							unlink($del_img);
						}
					} else {
						$image = $this->input->post('hidden_emp_img');
					}
					$emp_detail = array(
						'first_name' => $first_name,
						'last_name' => $last_name,
						'email' => $email,
						'phone' => $phone,
						'role_id' => $emp_role,
						'manager_id'=>$manager_id,
						'status' => ($status == 1) ? 1 : 0,
						'profile_img' => $image,
						'employee_id' => $employee_id,
						'join_dbi' => $join_dbi,
					);
					
					
				
					if(!empty($emp_id)){
						if($data['emp']->password != $password){
							$emp_detail['password'] = md5($password);
						}
						//updating employee
						$update = $this->common->update_record('tbl_employees',array('id'=>$emp_id),$emp_detail);
						
					/* 	if($update){
							if(isset($from_date) && isset($to_date)){
							for($i=0;$i< count($from_date);$i++){
								if(!empty($row_id[$i]) && !empty($from_date[$i]) && !empty($to_date[$i])){
									$update_salary_detail[] = array(
										'id'=>$row_id[$i],
										'emp_id'=>$emp_id,
										'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
									);
								}
								if(empty($row_id[$i]) && !empty($from_date[$i]) && !empty($to_date[$i])){
									$insert_salary_detail[] = array(
										'emp_id'=>$emp_id,
										'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
									);
								}
							}
							}
							
							if(!empty($update_salary_detail)){
								$this->db->update_batch('tbl_employee_salary_details',$update_salary_detail,'id');
							}
							if(!empty($insert_salary_detail)){
								$this->db->insert_batch('tbl_employee_salary_details',$insert_salary_detail);
							}
						} */
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee details updated successfully!</p>');
					}
					redirect(base_url('staff/'.strtolower($hidden_role_name)));
				}
			}
		}
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/add_staff',$data);
	}
	
	public function delete_staff(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/delete_staff',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$action = $this->uri->segment(3);
		$id = $this->uri->segment(4);
		$staffinfo=$this->sm->get_staff_by_id($id);
		if($staffinfo->role_id=='3')
		{
			/*--Delete team memeber data----*/
			$this->common->delete_record('tbl_teamassign_question',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_salary_details',array('emp_id'=>$id));
			$this->common->delete_record('tbl_question',array('user_id'=>$id));
			
			$this->common->delete_record('tbl_assign_question',array('leader_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('leader_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('leader_id'=>$id));
			/*
			$update_empquestionry = $this->common->update_record('tbl_assign_question',array('leader_id'=>$id),array('leader_id'=>''));
			
			$update_empassess = $this->common->update_record('tbl_employee_assessment',array('leader_id'=>$id),array('leader_id'=>''));
			$update_empsalary = $this->common->update_record('tbl_employee_assevaluation',array('leader_id'=>$id),array('leader_id'=>''));
			*/
			/*---End of delete team memeber data----*/
		}
		else if($staffinfo->role_id=='4')
		{
			/*--Delete employee data----*/
			$this->common->delete_record('tbl_assign_question',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_salary_details',array('emp_id'=>$id));
			
			
			$update_manager = $this->common->update_record('tbl_employees',array('id'=>$id),array('manager_id'=>0));
			/*--Delete employee data----*/
		}
		$delete_emp=$this->common->delete_record('tbl_employees',array('id'=>$id));
		//$delete_emp = $this->common->update_record('tbl_employees',array('id'=>$id),array('status'=>0,'is_deleted'=>1));
		if($delete_emp){
			//$this->common->delete_record('tbl_assign_question',array('emp_id'=>$id));
			if (!empty($user['profile_img']) && file_exists(FCPATH . '/assets/images/staff_image/' . $staffinfo->profile_img)) {
				$del_img = FCPATH . '/assets/images/staff_image/' . $staffinfo->profile_img;
				unlink($del_img);
			}
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Staff deleted successfully!</p>');
			redirect(base_url('staff/'.$action));
		}else{
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
		}
	}
	
	/******Employee self assesment******/
	
	public function self_assesment(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('employee/self-assesment',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$employee_id = $this->session->userdata('emp_id');
		$data = array();
		$data['page'] = 'assessment';
		
		if($this->session->userdata('role_id')==3)
			{
				/*----Send review by manager----*/
						/*If Answer is submitted by Employee*/
			if($this->input->post('submit') == 'Self Assesment'){
				/*
				*** $answer - posted answer is in form of array, 
				where Answer array -  
				1 - key : assignment id(primary key of assign question tbl)
				2 - value is corresponding answer for that particular question
				*/
				//echo "<pre>";print_r($this->input->post());die;
				$ans = array();
				$answer = $this->input->post('answer');
				$assign_id = $this->input->post('assign_id');
				$curpage = $this->input->post('curpage');
				$ttl_count = count($assign_id);
				$emp_answer = array();
				foreach($answer as $answ){
					$empty = 1;
					foreach($answ as $val){
						if($val != ''){
							$empty--;
							break;
						}
					}
					if($empty == 0 && !empty($answ)){
						$ans_val = json_encode($answ);
					}else{
						$ans_val = '';
					}
					$ans[] = $ans_val;
				}
				$i=0;
				foreach($assign_id as $val){
					/* $key - Assign id*/
					/* $val - Employee Answer for that particular question*/
					$emp_answer = array(
							   'answer'=> $ans[$i]
							  );
					$query = $this->common->update_record('tbl_teamassign_question',array('assign_id'=>$val),$emp_answer);
					$i++;		  
				}
				//$query = $this->db->update_batch('tbl_assign_question',$emp_answer,'assign_id');
				
				if($query){
					//$download_pdf_url = base_url('employee/genrate_pdf');
					
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
					//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
					$totalquestion = $this->qm->num_manager_self_assesment($employee_id,$status=1,$review_status=1);
					if($totalquestion > 1)
					{
						if($curpage > 0)
						{
							$nextpage=$curpage+1;
							if($nextpage < $totalquestion)
							{
							redirect(base_url('employee/questionaire/'.$nextpage.'?'));
							}
							else
							{
								redirect(base_url('employee/questionaire/'.$curpage.'?'));
							}
						}
						else
						{
						redirect(base_url('employee/questionaire/1?'));
						}
					}
					else
					{
						redirect(base_url('employee/questionaire/'));
					}
					
				}else{
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
					
				}
			}
			/*---pagination of questionory---*/
			$this->load->library('pagination');
			$data['page'] = 'question_list';
			$config['base_url'] = base_url('employee/questionaire');
			$config['total_rows'] = $this->qm->num_manager_self_assesment($employee_id,$status=1,$review_status=1);
			$config['per_page'] = 1;
			$config['uri_segment'] = 3;
			$data['total_rows'] = $config['total_rows'];
			if (isset($_GET)) {
				$config['enable_query_string'] = TRUE;
				$config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config["base_url"] . $config['suffix'];
			}
			$this->pagination->initialize($config);

			$page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
			$data['page_no'] = $page;
			$last_record_per_page = $config["per_page"] + ($data['page_no']);
			if ($data['total_rows'] < $last_record_per_page) {
				$last_record_per_page = $data['total_rows'];
			}
			$data["last_record_per_page"] = $last_record_per_page;
			$data["links"] = $this->pagination->create_links();
			
			/*----end of pagination of questionry---*/
			
			$self_assesment = $this->qm->all_manager_self_assesment($employee_id,$status=1,$review_status=1,$config["per_page"], $page);
			
			
			$data['self_assesment'] = $self_assesment;
			$this->load->view('staff/team_self_assesment',$data);
				/*----End of send review by manager---*/
			
		}
		else
		{
		
		/*If Answer is submitted by Employee*/
		if($this->input->post('submit') == 'Self Assesment'){
			/*
			*** $answer - posted answer is in form of array, 
			where Answer array -  
			1 - key : assignment id(primary key of assign question tbl)
			2 - value is corresponding answer for that particular question
			*/
			//echo "<pre>";print_r($this->input->post());die;
			$ans = array();
			$answer = $this->input->post('answer');
			$assign_id = $this->input->post('assign_id');
			$curpage = $this->input->post('curpage');
			$ttl_count = count($assign_id);
			$emp_answer = array();
			foreach($answer as $answ){
				$empty = 1;
				foreach($answ as $val){
					if($val != ''){
						$empty--;
						break;
					}
				}
				if($empty == 0 && !empty($answ)){
					$ans_val = json_encode($answ);
				}else{
					$ans_val = '';
				}
				$ans[] = $ans_val;
			}
			$i=0;
			foreach($assign_id as $val){
				/* $key - Assign id*/
				/* $val - Employee Answer for that particular question*/
				$emp_answer = array(
						   'answer'=> $ans[$i]
						  );
				$query = $this->common->update_record('tbl_assign_question',array('assign_id'=>$val),$emp_answer);
				$i++;		  
			}
			//$query = $this->db->update_batch('tbl_assign_question',$emp_answer,'assign_id');
			
			if($query){
				//$download_pdf_url = base_url('employee/genrate_pdf');
				
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Saved Successfully.</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
					$totalquestion = $this->qm->num_employee_self_assesment($employee_id,$status=1,$review_status=1);
					if($totalquestion > 1)
					{
						if($curpage > 0)
						{
							$nextpage=$curpage+1;
							if($nextpage < $totalquestion)
							{
							redirect(base_url('employee/questionaire/'.$nextpage.'?'));
							}
							else
							{
								redirect(base_url('employee/questionaire/'.$curpage.'?'));
							}
						}
						else
						{
						redirect(base_url('employee/questionaire/1?'));
						}
					}
					else
					{
						redirect(base_url('employee/questionaire/'));
					}
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		/*---pagination of questionory---*/
		$this->load->library('pagination');
		$data['page'] = 'question_list';
		$config['base_url'] = base_url('employee/questionaire');
		$config['total_rows'] = $this->qm->num_employee_self_assesment($employee_id,$status=1,$review_status=1);
		$config['per_page'] = 1;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
		
		/*----end of pagination of questionry---*/
		
		$self_assesment = $this->qm->all_employee_self_assesment($employee_id,$status=1,$review_status=1,$config["per_page"], $page);
		
		
		$data['self_assesment'] = $self_assesment;
		$this->load->view('staff/self_assesment',$data);
		}
	}
	/*Function to add remarks and download assesement as pdf by manager on employee self assessment*/
	public function review($emp_id){
		
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		
		if(!in_array('employee/review',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$employee_id = $emp_id;
		$data = array();
		$data['page'] = 'assessment';
		$staffinfo=$this->sm->get_staff_by_id($emp_id); 
		if($staffinfo->role_id==3)
		{
			
					/*If Answer is submitted by Manager*/
		if($this->input->post('submit') == 'submit remarks'){
			
			$remarks = $this->input->post('remarks');
			$assign_id = $this->input->post('assign_id');
			$i=0;
			foreach($remarks as $val){
				$query = $this->common->update_record('tbl_teamassign_question',array('assign_id'=>$assign_id[$i],'status'=>1,'review_status'=>2),array('remarks'=>$val));
				$i++;
			}
			
			if($query){
				$blank_remarks = $this->common->get_selected_columns('	tbl_teamassign_question',array('assign_id'),array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id,'remarks'=>''),'multiple');
				$count_blank_remarks = count($blank_remarks);
				if($count_blank_remarks == 0){
					//$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>3));
					$this->common->update_record('tbl_teamassign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>2));
				}
				//$download_pdf_url = base_url('employee/genrate_pdf/'.$emp_id);
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
				//redirect(base_url('employee/review/'.$emp_id));
				redirect(base_url('staff/team-leader/'));
				
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		$self_assesment = $this->qm->get_manager_self_assesment($employee_id,$status=1,$review_status=2);
		$data['self_assesment'] = $self_assesment;
		//echo "<pre>";print_r($data);die;
		$this->load->view('staff/team_review_assesment',$data);
		}
		else
		{
		/*If Answer is submitted by Employee*/
		if($this->input->post('submit') == 'submit remarks'){
			
			$remarks = $this->input->post('remarks');
			$assign_id = $this->input->post('assign_id');
			$i=0;
			foreach($remarks as $val){
				$query = $this->common->update_record('tbl_assign_question',array('assign_id'=>$assign_id[$i],'status'=>1,'review_status'=>2),array('remarks'=>$val));
				$i++;
			}
			
			if($query){
				$blank_remarks = $this->common->get_selected_columns('	tbl_assign_question',array('assign_id'),array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id,'remarks'=>''),'multiple');
				$count_blank_remarks = count($blank_remarks);
				if($count_blank_remarks == 0){
					//$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>3));
					$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>2));
				}
				//$download_pdf_url = base_url('employee/genrate_pdf/'.$emp_id);
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
				//redirect(base_url('employee/review/'.$emp_id));
				redirect(base_url('staff/employee/'));
				
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		$self_assesment = $this->qm->get_employee_self_assesment($employee_id,$status=1,$review_status=2);
		$data['self_assesment'] = $self_assesment;
		//echo "<pre>";print_r($data);die;
		$this->load->view('staff/review_assesment',$data);
		}
	}
	
	/*Function to generate pdf of self assesment*/
	public function genrate_pdf($emp_id=false){
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$this->common->check_login();
		
		$employee_id = ($emp_id) ? $emp_id : $this->session->userdata('emp_id');
		/*if employee has been logged in then status will be 2 otherwise 3 in case of manager*/
		$status = ($this->session->userdata('role_id') == 4) ? 2 : 3;
		/*----check pdf access by  by specific user----*/
		if($this->session->userdata('role_id')==1 || $this->session->userdata('role_id')==2 || $this->session->userdata('role_id')==3)
		{	
		
		if($this->session->userdata('role_id')==3)
		{
			 $loginid=$this->session->userdata('emp_id');
			$check_emp_leader=$this->sm->check_employee_leader($emp_id,$loginid);
		
			if($check_emp_leader < 1)
			{
				redirect(base_url('not-authorized'));		
				exit;
			}
		}
		
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['fromdate']=date('F d,Y',strtotime($sumitdb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d,Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
			}
		$staffinfo=$this->sm->get_staff_by_id($emp_id); 
		$data['staffinfo']=$staffinfo;
		if($staffinfo->role_id==4)
		{
		$data['self_assesment'] = $this->qm->get_employee_self_assesment($employee_id,$status=1,$review_status=2);
			}
			else
			{
			
				$data['self_assesment'] = $this->qm->get_manager_self_assesment($employee_id,$status=1,$review_status=2);
				
			}
			
		// Load all views as normal
		$html = $this->load->view('self_assesment_pdf',$data,true);
		//echo $html;
		// Load library
	 $this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("self_assesment.pdf"); 
		}
		else
		{
				redirect(base_url('not-authorized'));
		}
	}
	
	public function import_staffs_data() {
        $this->common->check_login();
		$data['page'] = 'staff';
        $this->load->library('Excel');
        $arr['error'] = '';    //initialize image upload error array to empty
//$csv_file = $_FILES['upload_csv']['name'];
        if (isset($_FILES) && !empty($_FILES)) 
		{
            $csv_file = $_FILES['upload_csv']['name'];
            $config['upload_path'] = FCPATH . 'assets/uploads/';
            $config['allowed_types'] = 'csv|xls|xlsx';
            //$config['max_size'] = '2000';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('upload_csv')) {
              $arr['error'] = $this->upload->display_errors();
            } else {
				
                $file_data = $this->upload->data();
                $file_path = FCPATH . 'assets/uploads/' . $file_data['file_name'];
                $my_data = array();
                $header_array = Array
                    ('EmployeeId','FirstName', 'LastName', 'Email', 'Phone', 'Role', 'Manager', 'Photo', 'Password' , 'Password', 'startdate');
                $count = 0;
                $compare = '';
                $arr_max_id = $this->common->get_max_id('tbl_employee_salary_details');
                $insert_id = $arr_max_id['id'] + 1;
//read file from path
                $objPHPExcel = PHPExcel_IOFactory::load($file_path);
// Get Highest Column
                $highestColumm = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); // e.g. "EL"
// Get Highest Row
                $highestRow = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();  // e.g. 5
                $highestColumm++;
                for ($row = 1; $row < $highestRow + 1; $row++) {
                    $dataset = array();
                    for ($column = 'A'; $column != $highestColumm; $column++) {
                        $dataset[] = $objPHPExcel->setActiveSheetIndex(0)->getCell($column . $row)->getValue();
                    }
                    $datasets[] = $dataset;
                }
			
				$errorEmp = 0;
				$errorFrDt = 0;
				$errorToDt = 0;
				$join_dbi="";
                foreach ($datasets as $csv_array) {
                    if ($count > 0) {
						$employee = $this->common->get_selected_columns('tbl_employees',array('id'),array('email'=>$csv_array[3]),'single',$obj_form=true);
                        if (empty($employee)) {
						
						$manager = $this->common->get_selected_columns('tbl_employees',array('id'),array('employee_id'=>$csv_array[6]),'single',$obj_form=true);
							$createdate1=date("Y-m-d H:i:s");
							if(!empty($csv_array[9]))
							{
								
								$join_dbi=date('Y-m-d', strtotime('+1 day',PHPExcel_Shared_Date::ExcelToPHP($csv_array[9])));
								
							}
							else
							{
								$join_dbi="";
							}
                            $my_data[] = array(                               
                                'employee_id' => (!empty($csv_array[0])) ? ($csv_array[0]) : '',                                
                                'first_name' => (!empty($csv_array[1])) ? ($csv_array[1]) : '',
                                'last_name' => (!empty($csv_array[2])) ? $csv_array[2] : '',
                                'email' => (!empty($csv_array[3])) ? $csv_array[3] : '',
                                'password' => (!empty($csv_array[8])) ? md5($csv_array[8]) : '',
                                'phone' => (!empty($csv_array[4])) ? $csv_array[4] : '',
                                'role_id' => (!empty($csv_array[5])) ? $csv_array[5] : '',
                                'manager_id' => $manager->id,
                                'profile_img' => (!empty($csv_array[7])) ? $csv_array[7] : '',
								'join_dbi' => $join_dbi,
                                'created_at' => $createdate1,
                                'status' => '1',
                            );
                        } else {
							
								$errorEmp++;
							
                            
                        }
                        $insert_id++;
                    } else {
                        $compare = array_diff($csv_array, $header_array);
                        if (count($compare) > 0) {
                            $this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> We need proper format to upload. Please check your format before uploading!</p>');
                            if (file_exists($file_path)) {
                                unlink($file_path);
                            }
                            break;
                        }
                    }
                    $count++;
                }
				
				$err_msg = '';
				if(!empty($errorEmp)){
					$err_msg = ' and '.$errorEmp.' rows failed to upload due to blank or duplicate Email';
				}
                if (!empty($my_data)) {
                    $this->db->insert_batch('tbl_employees', $my_data);

                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
					
                    $this->session->set_flashdata('message', '<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Staffs Data Imported Successfully'.$err_msg.'!</p>');
                    redirect(base_url('staff/employee'));
                } else {
                    $this->session->set_flashdata('message', '<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> The file you have uploaded is not uploaded'.$err_msg.'!</p>');
					
                    redirect(base_url('staff/employee'));
                }
            }
        }
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/import_staffs_data',$data);
    }
	
	public function questionaire_preview(){
				$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$employee_id = $this->session->userdata('emp_id');
		/*if employee has been logged in then status will be 2 otherwise 3 in case of manager*/
		
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['sumitdb_from']=$row_ass->submi_from;;
					  }
					  else
						{
							
							 $sumitdb_from="";
							  $data['sumitdb_from']="";
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['sumitdb_to']=$row_ass->submi_to;
				}
				else
				{
				
					$sumitdb_to="";
					 $data['sumitdb_to']="";
				}
			}
		
			if($this->session->userdata('role_id')==3)
			{
		
				$data['self_assesment'] = $this->qm->mamanger_questionry($employee_id,$status=1,$from=$sumitdb_from,$todate=$sumitdb_to);
				$this->load->view('staff/team_questionaire_preview',$data);
			}
			else
			{
				$data['self_assesment'] = $this->qm->employee_questionry($employee_id,$status=1,$from=$sumitdb_from,$todate=$sumitdb_to);
				$this->load->view('staff/questionaire_preview',$data);
			}
		
	}

/*------start assessment-------*/
	public function employee_assessment($emp_id){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		/* if(!in_array('staff/add',$role_permission)){
			redirect(base_url('not-authorized'));
		} */
	
	
		$data = array();
		$data['emp_id']=$emp_id;
		$salary_detail = array();
		$data['page'] = 'staff';
		$data['staffinfo'] = $this->common->get_selected_columns('tbl_employees',array('first_name,last_name'),array('id ='=>$emp_id),'single',$obj=true);
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('goalof_1', 'Goal', 'trim|required');
			$this->form_validation->set_rules('currentof_1', 'Current Goal', 'trim|required');
			$this->form_validation->set_rules('goaltype_1', 'Type', 'trim|required');
			
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				
				
				$post = $this->input->post();
				extract($post);
				
				$ass_id = $this->input->post('ass_id');
				if(isset($ass_id) && !empty($ass_id))
				{
					$this->common->delete_record('tbl_employee_assevaluation',array('empasid'=>$ass_id));
					$this->common->delete_record('tbl_employee_assessment',array('empasid'=>$ass_id));
				}
				else
				{
					
				}
				$goalof_1 = $this->input->post('goalof_1');
				$currentof_1 = $this->input->post('currentof_1');
				$goaltype_1 = $this->input->post('goaltype_1');
				
				$goalof_2 = $this->input->post('goalof_2');
				$currentof_2 = $this->input->post('currentof_2');
				$goaltype_2 = $this->input->post('goaltype_2');
				
				$goalof_3 = $this->input->post('goalof_3');
				$currentof_3 = $this->input->post('currentof_3');
				$goaltype_3 = $this->input->post('goaltype_3');
				
				$accomplishment = $this->input->post('accomplishment');
				$imporvment = $this->input->post('imporvment');
				$summery = $this->input->post('summery');
				$projects_worked = $this->input->post('projects_worked');
				$favorite_projects = $this->input->post('favorite_projects');
				
				
				$emp_id = $this->input->post('emp_id');
				$leader_id=$this->session->userdata('emp_id');
						
					$emp_detail = array(
						'emp_id' => $emp_id,
						'leader_id' => $leader_id,
						'billable_goal' => $goalof_1,
						'billable_current' => $currentof_1,
						'billable_type' => $goaltype_1,
						'nobillable_goal' => $goalof_2,
						'nobillable_current' => $currentof_2,
						'nobillable_type' => $goaltype_2,
						'complete_goal' => $goalof_3,
						'complete_current' => $currentof_3,
						'complete_type' => $goaltype_3,						
						'goal_period' => date('Y-m-d H:i:sa'),
						'accomplishment' => $accomplishment,
						'imporvment' => $imporvment,
						'summery' => $summery,
						'projects_worked' => $projects_worked,
						'favorite_projects' => $favorite_projects,
						
					);
										
					//Inserting employee
					$ass_id = $this->common->insert_record('tbl_employee_assessment',$emp_detail);
					if($ass_id){
					
							for($i=0;$i<count($editgoal);$i++){
								if(!empty($editgoal[$i]) && !empty($editgoal_type[$i])){
								$salary_detail[] = array(
									'empasid'=>$ass_id,
									'emp_id'=>$emp_id,
									'leader_id'=>$leader_id,
									'editable_goal'=>$editgoal[$i],
									'editable_type'=>$editgoal_type[$i],
									'editable_date' => date('Y-m-d H:i:sa'),
								);	
								}
							}
						
						if(!empty($salary_detail)){
							$this->db->insert_batch('tbl_employee_assevaluation',$salary_detail);
						}
					
						
						//sendmail($to = $email,$subject = 'Employee Registration',$message,$from = 'testing10@iwesh.com');
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Assessment added successfully!</p>');
						redirect(base_url('employee/assessment/'.$emp_id));
					}else{
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some time!</p>');
					}
				
			}
		}
		
		$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id !='=>$emp_id),'single',$obj=true);
		$data['role_list'] = $this->sm->get_all_roles();
		
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
				$leader_id=$this->session->userdata('emp_id');
				$data['emp_assesment'] = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
			}
		$data['emp_salary'] = $this->qm->employee_salary_detail($emp_id);	
		$this->load->view('staff/employee_assessment',$data);
	}
	
	public function assessmentpdf($emp_id=false){
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
		
		/*----check pdf access by  by specific user----*/
		if($this->session->userdata('role_id')==1 || $this->session->userdata('role_id')==2 || $this->session->userdata('role_id')==3)
		{	
		
		if($this->session->userdata('role_id')==3)
		{
			 $loginid=$this->session->userdata('emp_id');
			$check_emp_leader=$this->sm->check_employee_leader($emp_id,$loginid);
		
			if($check_emp_leader < 1)
			{
				redirect(base_url('not-authorized'));		
				exit;
			}
		}
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['fromdate']=date('F d,Y',strtotime($sumitdb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d,Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_salary_detail($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
		 $html = $this->load->view('emp_assesment_pdf',$data,true);
		// Load library
		$this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_assesment_".$emp_id.".pdf"); 
		}
		else
		{
			redirect(base_url('not-authorized'));		
		}	
	}	
/*------end of start assessment---*/
/*------Start Historical data---*/
	public function historicalpdf($emp_id=false){
		  $this->load->library('html2pdf_lib');

    /********
     * $content = the html content to be converted
     * you can use file_get_content() to get the html from other location
     *
     * $filename = filename of the pdf file, make sure you put the extension as .pdf
     * $save_to = location where you want to save the file,
     *            set it to null will not save the file but display the file directly after converted
     * ******/
   
  
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
			/*----check pdf access by  by specific user----*/
		if($this->session->userdata('role_id')==1 || $this->session->userdata('role_id')==2 || $this->session->userdata('role_id')==3)
		{	
		
		if($this->session->userdata('role_id')==3)
		{
			 $loginid=$this->session->userdata('emp_id');
			$check_emp_leader=$this->sm->check_employee_leader($emp_id,$loginid);
		
			if($check_emp_leader < 1)
			{
				redirect(base_url('not-authorized'));		
				exit;
			}
		}
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					   $perioddb_from=$row_ass->period_from;
					  $data['fromdate']=date('F d, Y',strtotime($sumitdb_from));
					  
					  $data['period_year']=date('Y',strtotime($perioddb_from));
					  $data['period_month']=date('F',strtotime($perioddb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d, Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name,profile_img,join_dbi,role_id'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_historical_detail($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
		$data['num_team_employee'] = $this->sm->num_team_employee($emp_id);
		
		$data['total_assessment'] = $this->common->get_selected_columns('tbl_employee_assessment',array('count(empasid) as totalassessment'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['query_ctitle'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('count(DISTINCT  current_title) as titlechange'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['total_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('sum(total_bonus) as total_bonus , sum(total_period_bonus) as total_period_bonus, sum(total_review_period_compensation) as total_review_period_compensation,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours)  as avg_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['total_avg_non_billable_hours'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours)  as avg_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['title_history_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,current_title '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,base_billable_hours  as min_base_billable_hours,billable_hours  as max_base_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,non_billable_hours  as min_non_billable_hours,basenone_billable  as max_non_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		$data['bonus_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,team_bonus,billable_bonus,discretionary_bonus '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['anual_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,total_period_bonus,current_salary,current_salary_review_period '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['compsation_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,billable_bonus,total_bonus,current_salary_review_period,current_salary '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(base_billable_hours)  as total_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['no_basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(non_billable_hours)  as total_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['compensation_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_review_period_compensation)  as total_review_period_compensation '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary_review_period)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['previous_salary'] = $this->qm->employee_previous_salary($emp_id);
		$data['first_salary'] = $this->qm->employee_first_salary($emp_id);
		$data['salary_count'] = $this->qm->employee_salary_count($emp_id);
		$data['simulater'] = $this->common->get_selected_columns('tbl_simulater',array('*'),array('id ='=>1),'single',$obj=true);
		
		$data['total_team_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(team_bonus)  as total_team_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['total_billable_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(billable_bonus)  as total_billable_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_discretionary_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(discretionary_bonus)  as total_discretionary_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_management_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(management_bonus)  as total_management_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_profit_share'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(profit_share)  as total_profit_share '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		
		$data['total_total_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_bonus)  as total_total_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['simulater_list'] = $this->common->simulater_list();
		$data['team_emp_list'] = $this->sm->team_employee_list($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
		
		//echo $html;
		/* $qry=$this->db->query("SELECT * FROM `tbl_print` where print_id='".$emp_id."'");
		$print_row=$qry->row();
		$html=$print_row->print_data;
	 $html=base64_decode($html); */
		
		 /*  //Tcpdf
		  $this->load->library("Pdf");
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);    
		 //set document information
       
		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		 //set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM); 
		// set some language-dependent strings (optional)
		if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
			require_once(dirname(__FILE__).'/lang/eng.php');
			$pdf->setLanguageArray($l);
		}  
		// set default font subsetting mode
		$pdf->SetFont('helvetica', 'B', 20);
		$pdf->SetPrintHeader(false);
		$pdf->SetPrintFooter(false);
	    //	 add a page
		$pdf->AddPage();
		$pdf->SetFont('helvetica', '', 10);
		
		 $html1 = <<<EOD
     		$html	    
EOD;
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 0, 0, true, '', true);
		//$pdf->IncludeJS($html1);
        $pdf->Output("employee_historical_".$emp_id.".pdf", 'I');   */
		 
		
		
		
		
		
		
		
		
	  $html=$this->load->view('emp_historical_pdf',$data,true);
		
 	 	 // Load library
	 	   $this->load->library('dompdf_gen');
		// Convert to PDF
		 $this->dompdf->load_html($html);
		
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_historical_".$emp_id.".pdf");   
		
 
   	
		}
		else
		{
			redirect(base_url('not-authorized'));		
		}
	}	

	
		public function historicalpdf2($emp_id=false){ 
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
			/*----check pdf access by  by specific user----*/
		if($this->session->userdata('role_id')==1 || $this->session->userdata('role_id')==2 || $this->session->userdata('role_id')==3)
		{	
		
		if($this->session->userdata('role_id')==3)
		{
			 $loginid=$this->session->userdata('emp_id');
			$check_emp_leader=$this->sm->check_employee_leader($emp_id,$loginid);
		
			if($check_emp_leader < 1)
			{
				redirect(base_url('not-authorized'));		
				exit;
			}
		}
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					   $perioddb_from=$row_ass->period_from;
					  $data['fromdate']=date('F d, Y',strtotime($sumitdb_from));
					  
					  $data['period_year']=date('Y',strtotime($perioddb_from));
					  $data['period_month']=date('F',strtotime($perioddb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d, Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name,profile_img,join_dbi,role_id'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_historical_detail($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
		$data['num_team_employee'] = $this->sm->num_team_employee($emp_id);
		
		$data['total_assessment'] = $this->common->get_selected_columns('tbl_employee_assessment',array('count(empasid) as totalassessment'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['query_ctitle'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('count(DISTINCT  current_title) as titlechange'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['total_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('sum(total_bonus) as total_bonus , sum(total_period_bonus) as total_period_bonus, sum(total_review_period_compensation) as total_review_period_compensation,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours)  as avg_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['total_avg_non_billable_hours'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours)  as avg_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['title_history_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,current_title '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,base_billable_hours  as min_base_billable_hours,billable_hours  as max_base_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,non_billable_hours  as min_non_billable_hours,basenone_billable  as max_non_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		$data['bonus_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,team_bonus,billable_bonus,discretionary_bonus '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['anual_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,total_period_bonus,current_salary,current_salary_review_period '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['compsation_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,billable_bonus,total_bonus,current_salary_review_period,current_salary '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(base_billable_hours)  as total_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['no_basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(non_billable_hours)  as total_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['compensation_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_review_period_compensation)  as total_review_period_compensation '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary_review_period)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['previous_salary'] = $this->qm->employee_previous_salary($emp_id);
		$data['first_salary'] = $this->qm->employee_first_salary($emp_id);
		$data['salary_count'] = $this->qm->employee_salary_count($emp_id);
		$data['simulater'] = $this->common->get_selected_columns('tbl_simulater',array('*'),array('id ='=>1),'single',$obj=true); 
		
		$data['total_team_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(team_bonus)  as total_team_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['total_billable_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(billable_bonus)  as total_billable_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_discretionary_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(discretionary_bonus)  as total_discretionary_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_management_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(management_bonus)  as total_management_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_profit_share'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(profit_share)  as total_profit_share '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		
		$data['total_total_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_bonus)  as total_total_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['simulater_list'] = $this->common->simulater_list();
		$data['team_emp_list'] = $this->sm->team_employee_list($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
	
		    // $html = $this->load->view('emp_historical_pdf2',$data,true); 
			echo $html = $this->load->view('emp_historical_pdf',$data,true); 
		  
		 
  // Load library
	 	/*   $this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_historical_".$emp_id.".pdf");   */ 
		}
		else
		{
			redirect(base_url('not-authorized'));		
		}
	}				

	
	/*------end of Historical data---*/	

/*---import staff salary data-------*/
	public function import_employee_salary() {
        $this->common->check_login();
		$data['page'] = 'staff';
        $this->load->library('Excel');
        $arr['error'] = '';    //initialize image upload error array to empty
//$csv_file = $_FILES['upload_csv']['name'];
                if (isset($_FILES) && !empty($_FILES)) {
            $csv_file = $_FILES['upload_csv']['name'];
            $config['upload_path'] = FCPATH . 'assets/uploads/';
            $config['allowed_types'] = 'csv|xls|xlsx';
            //$config['max_size'] = '2000';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('upload_csv')) {
              $arr['error'] = $this->upload->display_errors();
            } else {
				
                $file_data = $this->upload->data();
                $file_path = FCPATH . 'assets/uploads/' . $file_data['file_name'];
                $my_data = array();
                $header_array = Array
                    ('EmployeeId','FromDate','ToDate','CurrentTitle', 'CurrentSalary', 'CurrentSalaryReviewPeriod', 'BaseBillableHours','BillableHours','BaseNonBillable','NonBillableHours','BillableBonus','DiscretionaryBonus','TeamBonus','Management Bonus','Profit Share','Revenue','Expense','AdjustedSalary','AdjustedTitle'
					,'Rate-1','Rate-2','Rate-3','Rate-4','Rate-5','Rate-6','Rate-1'
					,'Bonus-1','Bonus-2','Bonus-3','Bonus-4','Bonus-5','Bonus-6');
                $count = 0;
                $compare = '';
                $arr_max_id = $this->common->get_max_id('tbl_employee_salary_details');
                $insert_id = $arr_max_id['id'] + 1;
//read file from path
                $objPHPExcel = PHPExcel_IOFactory::load($file_path);
// Get Highest Column
                $highestColumm = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); // e.g. "EL"
// Get Highest Row
                $highestRow = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();  // e.g. 5
                $highestColumm++;
                for ($row = 1; $row < $highestRow + 1; $row++) {
                    $dataset = array();
                    for ($column = 'A'; $column != $highestColumm; $column++) {
                        $dataset[] = $objPHPExcel->setActiveSheetIndex(0)->getCell($column . $row)->getValue();
                    }
                    $datasets[] = $dataset;
                }
				//$from_date = $this->input->post('from_date');
				//$to_date = $this->input->post('to_date');
			
				$errorEmp = 0;
				$errorFrDt = 0;
				$errorToDt = 0;
				$billable_bonus=0;
				$discretionary_bonus=0;
				$team_bonus=0;
				$perc_billable_bonus=0;
				$total_bonus=0;
				$perc_billable_bonus=0;				
				$perc_discretionary_bonus=0;
				$perc_discretionary_bonus=0;				
				$perc_team_bonus=0;
				$perc_team_bonus=0;				
				$total_review_period_compensation=0;
				$variance=0;
				$management_bonus=0;
				/* echo '<pre>';
				var_dump($datasets);
				echo '</pre>';
				exit; */
				
                foreach ($datasets as $csv_array) {
					
				
                    if ($count > 0) {
				
						$employee = $this->common->get_selected_columns('tbl_employees',array('id'),array('employee_id'=>$csv_array[0]),'single',$obj_form=true);
                        if (!empty($employee)) {
							
                            if($csv_array[1]!="")
							{
								
								$fromdate=date('Y-m-d', strtotime('+1 day',PHPExcel_Shared_Date::ExcelToPHP($csv_array[1])));
								
							}
							
							if($csv_array[2]!="")
							{
								$todateArr=explode("/",$csv_array[2]);
								$todate=date('Y-m-d', strtotime('+1 day',PHPExcel_Shared_Date::ExcelToPHP($csv_array[2])));
								
							}
							/*----calculation of salary---*/
						
							if($csv_array[10]!="")
							{
								$billable_bonus=$csv_array[10];
							}
							if($csv_array[11]!="")
							{
								$discretionary_bonus=$csv_array[11];
							}
							if($csv_array[12]!="")
							{
								$team_bonus=$csv_array[12];
							}
							
							if($csv_array[13]!="")
							{
								$management_bonus=$csv_array[13];
							}
							
							if($csv_array[14]!="")
							{
								$profit_share=$csv_array[14];
							}
							
							if($csv_array[15]!="")
							{
								$revenue=$csv_array[15];
							}
							
							if($csv_array[16]!="")
							{
								$expense=$csv_array[16];
							}
							$total_bonus=$csv_array[10]+$csv_array[11]+$csv_array[12]+$csv_array[13];
							
							if($total_bonus > 0)
							{
								$perc_billable_bonus=($billable_bonus/$total_bonus)*100;
								$perc_billable_bonus=round($perc_billable_bonus);
								
								$perc_discretionary_bonus=($discretionary_bonus/$total_bonus)*100;
								$perc_discretionary_bonus=round($perc_discretionary_bonus);
								
								$perc_team_bonus=($team_bonus/$total_bonus)*100;
								$perc_team_bonus=round($perc_team_bonus);
								
								$total_review_period_compensation=$total_bonus+$csv_array[5];
								
								$perc_bonus=($total_bonus/$total_review_period_compensation)*100;
								$perc_bonus=round($perc_bonus);
							}
							
							if($csv_array[17]!="")
							{
								$variance=$csv_array[17]-$csv_array[4];
							}
							
							if($csv_array[5]!="")
							{
								$perc_salary=($csv_array[5]/$total_review_period_compensation)*100;
								$perc_salary=round($perc_salary);
							}
							
							if($csv_array[6]!="" && $csv_array[7]!="")
							{
								
								$surplus_billable_hours=$csv_array[6]-$csv_array[7];
								$billable_surplus_combined=$csv_array[6]+$csv_array[7];
								$total_submitted_hours=$billable_surplus_combined+$csv_array[9];
							}
							/*----end of calculation of salary----*/
							
										
							$my_data[] = array(
                                'id' => $insert_id,
                                'emp_id' => $employee->id,
                                'from_date' => $fromdate,
                                'to_date' => $todate,
                                'current_title' => (!empty($csv_array[3])) ? ($csv_array[3]) : '',
                                'current_salary' => (!empty($csv_array[4])) ? $csv_array[4] : '',
                                'current_salary_review_period' => (!empty($csv_array[5])) ? $csv_array[5] : '','total_period_bonus'=>$total_bonus, 
								'total_review_period_compensation' =>$total_review_period_compensation,
								'perc_salary' =>$perc_salary,
								'perc_bonus' =>$perc_bonus,
                                'base_billable_hours' => (!empty($csv_array[6])) ? $csv_array[6] : '',
                                'surplus_billable_hours' => $surplus_billable_hours,
								'billable_surplus_combined' =>$billable_surplus_combined,                                
                                'non_billable_hours' => (!empty($csv_array[9])) ? $csv_array[9] : '',
								'total_submitted_hours' =>$total_submitted_hours,                                
                                'billable_bonus' => (!empty($csv_array[10])) ? $csv_array[10] : '',
                                'discretionary_bonus' => (!empty($csv_array[11])) ? $csv_array[11] : '',
                                'team_bonus' => (!empty($csv_array[12])) ? $csv_array[12] : '',
                                'total_bonus' =>$total_bonus,
								'perc_billable_bonus' =>$perc_billable_bonus,
								'perc_discretionary_bonus' =>$perc_discretionary_bonus,
								'perc_team_bonus' =>$perc_team_bonus,
                                'adjusted_salary' => (!empty($csv_array[17])) ? $csv_array[17] : '',
								'variance' =>$variance,                               
                                'adjusted_title' => (!empty($csv_array[18])) ? $csv_array[18] : '',
								'billable_hours' => (!empty($csv_array[7])) ? $csv_array[7] : '',
								'basenone_billable' => (!empty($csv_array[8])) ? $csv_array[8] : '',
								'management_bonus' => (!empty($csv_array[13])) ? $csv_array[13] : '',
								'profit_share' => (!empty($csv_array[14])) ? $csv_array[14] : '',
								'revenue' => (!empty($csv_array[15])) ? $csv_array[15] : '',
								'expense' => (!empty($csv_array[16])) ? $csv_array[16] : '',
								'rate1' => (!empty($csv_array[19])) ? $csv_array[19] : '',
								'rate2' => (!empty($csv_array[20])) ? $csv_array[20] : '',
								'rate3' => (!empty($csv_array[21])) ? $csv_array[21] : '',
								'rate4' => (!empty($csv_array[22])) ? $csv_array[22] : '',
								'rate5' => (!empty($csv_array[23])) ? $csv_array[23] : '',
								'rate6' => (!empty($csv_array[24])) ? $csv_array[24] : '',
								'bonus1' => (!empty($csv_array[25])) ? $csv_array[25] : '',
								'bonus2' => (!empty($csv_array[26])) ? $csv_array[26] : '',
								'bonus3' => (!empty($csv_array[27])) ? $csv_array[27] : '',
								'bonus4' => (!empty($csv_array[28])) ? $csv_array[28] : '',
								'bonus5' => (!empty($csv_array[29])) ? $csv_array[29] : '',
								'bonus6' => (!empty($csv_array[30])) ? $csv_array[30] : '',
								
								
								
								
                            );
						/* 	echo $csv_array[1];
							echo '<br/>';
							echo $csv_array[2];
							echo '<br/>';
							var_dump($my_data);
							exit; */
                        } else {
							if(empty($employee)){
								$errorEmp++;
							}else if(empty($from_date)){
								$errorFrDt++;
							}else if(empty($to_date)){
								$errorToDt++;
							}
                            
                        }
                        $insert_id++;
                    } else {
                        $compare = array_diff($csv_array, $header_array);
                        if (count($compare) > 0) {
                            $this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> We need proper format to upload. Please check your format before uploading!</p>');
                            if (file_exists($file_path)) {
                                unlink($file_path);
                            }
                            break;
                        }
                    }
                    $count++;
                }
				
				$err_msg = '';
				if(!empty($errorEmp)){
					$err_msg = ' and '.$errorEmp.' rows failed to upload due to blank or wrong Employee id';
				}else if(!empty($errorFrDt)){
					$err_msg = ' and '.$errorFrDt.' rows failed to upload due to blank From date';
				}else if(!empty($errorToDt)){
					$err_msg = ' and '.$errorFrDt.' rows failed to upload due to blank To date';
				}
                if (!empty($my_data)) {
					/*  echo '<pre>';
					var_dump($my_data);
					echo '</pre>';
					exit;  */
                   $this->db->insert_batch('tbl_employee_salary_details', $my_data);

                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
					
                    $this->session->set_flashdata('message', '<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Data Imported Successfully'.$err_msg.'!</p>');
                    redirect(base_url('staff/employee'));
                } else {
                    $this->session->set_flashdata('message', '<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> The file you have uploaded is not uploaded'.$err_msg.'!</p>');
					
                    redirect(base_url('staff/employee'));
                }
            }
        }
		$data['role_list'] = $this->sm->get_all_roles();
		
		$this->load->view('staff/import_staffs_salary',$data);
    }
/*----end of import staff salary data-----*/
/*----deleted employee salary data----*/
	public function delete_salary($empid="",$id=""){
		/*check whether user is logged in or not*/
		$this->common->check_login();

		//$action = $this->uri->segment(3);
		//$id = $this->uri->segment(4);
		 $loginid=$this->session->userdata('emp_id');
		if($this->session->userdata('role_id')==1)
		{
			$delete_emp=$this->common->delete_record('tbl_employee_salary_details',array('id'=>$id));
			if($delete_emp){
				
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Staff Data deleted successfully!</p>');
				redirect(base_url('staff/edit/'.$empid));
			}else{
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
			}
		}
		else
		{
			redirect(base_url('not-authorized'));
		}
	}
/*----end of deleted employee salary data---*/	
	public function historicalpdf1($emp_id=false){
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
			/*----check pdf access by  by specific user----*/
		if($this->session->userdata('role_id')==1 || $this->session->userdata('role_id')==2 || $this->session->userdata('role_id')==3)
		{	
		
		if($this->session->userdata('role_id')==3)
		{
			 $loginid=$this->session->userdata('emp_id');
			$check_emp_leader=$this->sm->check_employee_leader($emp_id,$loginid);
		
			if($check_emp_leader < 1)
			{
				redirect(base_url('not-authorized'));		
				exit;
			}
		}
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					   $perioddb_from=$row_ass->period_from;
					  $data['fromdate']=date('F d, Y',strtotime($sumitdb_from));
					  
					  $data['period_year']=date('Y',strtotime($perioddb_from));
					  $data['period_month']=date('F',strtotime($perioddb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d, Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name,profile_img,join_dbi,role_id'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_historical_detail($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
		$data['num_team_employee'] = $this->sm->num_team_employee($emp_id);
		
		$data['total_assessment'] = $this->common->get_selected_columns('tbl_employee_assessment',array('count(empasid) as totalassessment'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['query_ctitle'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('count(DISTINCT  current_title) as titlechange'),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['total_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('sum(total_bonus) as total_bonus , sum(total_period_bonus) as total_period_bonus, sum(total_review_period_compensation) as total_review_period_compensation,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours)  as avg_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['total_avg_non_billable_hours'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours)  as avg_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		
		$data['title_history_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,current_title '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(base_billable_hours)  as min_base_billable_hours,MAX(base_billable_hours)  as max_base_billable_hours,AVG(base_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,base_billable_hours  as min_base_billable_hours,billable_hours  as max_base_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,MIN(non_billable_hours)  as min_non_billable_hours,MAX(non_billable_hours)  as max_non_billable_hours,AVG(non_billable_hours) '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['nonbibile_chart1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,non_billable_hours  as min_non_billable_hours,basenone_billable  as max_non_billable_hours '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		$data['bonus_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,team_bonus,billable_bonus,discretionary_bonus '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['anual_salary'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,total_period_bonus,current_salary,current_salary_review_period '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		
		$data['compsation_chart'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,billable_bonus,total_bonus,current_salary_review_period,current_salary '),array('emp_id ='=>$emp_id),'multiple',$obj=true);
		
		$data['basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(base_billable_hours)  as total_base_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['no_basebibile_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(non_billable_hours)  as total_non_billable_hours '),array('emp_id ='=>$emp_id),'single',$obj=true);
		
		$data['compensation_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_review_period_compensation)  as total_review_period_compensation '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['salary_sum1'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(current_salary_review_period)  as total_salary '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['previous_salary'] = $this->qm->employee_previous_salary($emp_id);
		$data['first_salary'] = $this->qm->employee_first_salary($emp_id);
		$data['salary_count'] = $this->qm->employee_salary_count($emp_id);
		$data['simulater'] = $this->common->get_selected_columns('tbl_simulater',array('*'),array('id ='=>1),'single',$obj=true);
		
		$data['total_team_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(team_bonus)  as total_team_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);
		$data['total_billable_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(billable_bonus)  as total_billable_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_discretionary_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(discretionary_bonus)  as total_discretionary_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_management_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(management_bonus)  as total_management_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['total_profit_share'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(profit_share)  as total_profit_share '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		
		$data['total_total_bonus'] = $this->common->get_selected_columns('tbl_employee_salary_details',array('DISTINCT (Year(from_date)) as from_date ,sum(total_bonus)  as total_total_bonus '),array('emp_id ='=>$emp_id),'single',$obj=true);		
		$data['simulater_list'] = $this->common->simulater_list();
		$data['team_emp_list'] = $this->sm->team_employee_list($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
	
		   $html = $this->load->view('emp_historical_pdf1',$data,true); 
		  
		
		  // Load library
		  $this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_historical_".$emp_id.".pdf");     
		
		}
		else
		{
			redirect(base_url('not-authorized'));		
		}
	}
	public function team_list($team_id=""){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data['role_name'] = 'employee';
		$data['page'] = 'staff_list';
		$this->load->library('pagination');
		/*Gettin role id for the employee list by their role*/
	/* 	$role = $this->common->get_selected_columns('tbl_roles',$columns = array('id'),$where = array('LOWER(role_name)'=>urldecode(strtolower($role_name))),$reocrd = 'single',$obj=true);
		$role_id = (isset($role->id) && !empty($role->id)) ? $role->id : ''; */
		
		$role_id = 4;
		$config['base_url'] = base_url('staff/index/'.$team_id.'/');
		$config['total_rows'] = $this->sm->num_employees($team_id);
		$config['per_page'] = 10;
		$config['uri_segment'] = 4;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['employee_list'] = $this->sm->get_employees_list($team_id,$config["per_page"], $page);
		$data['team_id'] = $team_id;
		$data['leader_info'] = $this->sm->get_staff_by_id($team_id);
		$this->load->view('staff/team_list',$data);
	}	
}