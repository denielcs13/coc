<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->load->library('form_validation');
		$this->common->check_login();
	}
	
	public function index(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('roles',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data['page'] = 'role_list';
		$this->load->library('pagination');
		$config['base_url'] = base_url('roles/index');
		$config['total_rows'] = $this->sm->num_roles();
		$config['per_page'] = 10;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['role_list'] = $this->sm->get_role_list($config["per_page"], $page);
		$this->load->view('role/role_list',$data);
		
	}
	
	/*
	* Add functionality for Category module
	*/
	public function add(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('roles/add',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$permisssion = array();
		$data['page'] = 'role';
		
		if($this->uri->segment(3) != ''){
			redirect(base_url('roles'));
		}
		if($this->input->post('submit') == 'Add Role'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('role_name', 'Role name', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_role_exist($role_name,'');
				if($check_existance){
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Role already exists!</p>');
					
				}else{
					
					$role_detail = array(
						'role_name' => $role_name,
						'status' => ($status == 1) ? 1 : 0,
						'created_at' => date('Y-m-d H:i:sa'),
					);
					
					//Inserting Role
					$role_id = $this->common->insert_record('tbl_roles',$role_detail);
					if($role_id){
						if(!empty($role_permission)){
							foreach($role_permission as $value){
								$permisssion[] = array(
									'role_id'=>$role_id,
									'role_permission'=>$value,
								);
							}
							$this->db->insert_batch('tbl_role_permission',$permisssion);
						}
					}
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Role added successfully!</p>');
					
					redirect(base_url('roles'));
				}
			}
		}
		$data['all_modules'] = $this->common->get_selected_columns('tbl_modules',$columns = array(),$where=array(),'multiple',$obj=true);
		//$data['modules_action'] = $this->common->get_selected_columns('tbl_modules_action',$columns = array(),$where=array(),'multiple',$obj=true);
		$data['modules_action'] = $this->common->module_list($limit=0,$offset=0);
		$this->load->view('role/add_role',$data);
	}
	
	/*
	* Add functionality for Category module
	*/
	public function edit($role_id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('roles/edit',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$role_permission = array();
		$assgn_role_id = array();
		$insert_role_permission = array();
		$delete_role_permission = array();
		$data['page'] = 'role';
		if($this->uri->segment(3) == ''){
			redirect(base_url('roles'));
		}
		/*
		Get/Edit Indivisual Role detail by id 
		*/
		if(!empty($role_id)){
			$data['role'] = $this->common->get_selected_columns('tbl_roles',$columns = array('id','role_name','status'),$where = array('id'=>$role_id),$reocrd = 'single',$obj=true);
			$role_permissions = $this->common->get_selected_columns('tbl_role_permission',$columns = array(),$where = array('role_id'=>$role_id),$reocrd = 'multiple');
			
			$data['role_permissions'] = $role_permissions;
			if(!empty($role_permissions)){
				$assgn_role_id = array_column($role_permissions,'role_permission');
			}
		}
		
		if($this->input->post('submit') == 'Add Role'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('role_name', 'Role name', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_role_exist($role_name,$role_id);
				if($check_existance){
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Role already exists!</p>');
					
				}else{
					
					$role_detail = array(
						'role_name' => $role_name,
						'status' => ($status == 1) ? 1 : 0,
					);
				
					if(!empty($role_id)){
						
						//updating Role
						$update = $this->common->update_record('tbl_roles',array('id'=>$role_id),$role_detail);
						if($update){
							/* Checking the new question to be assigned to the employee*/
							$insert_role_permission = array_diff($role_permission,$assgn_role_id);
							
							/* Checking the assigned question need to delete for particular employee*/
							$delete_role_permission = array_diff($assgn_role_id,$role_permission);
							
							if(!empty($delete_role_permission)){
					
								foreach($delete_role_permission as $dr){
									$this->common->delete_record('tbl_role_permission',array('role_id'=>$role_id,'role_permission'=>$dr));
								}
								
							}
							if(!empty($insert_role_permission)){
								
								foreach($insert_role_permission as $value){
									$permission_detail[] = array(
										'role_id'=>$role_id,
										'role_permission'=>$value,
									);
								}
								
								$insert = $this->db->insert_batch('tbl_role_permission',$permission_detail);
								
								if($insert){
									
								}else{
									
									$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server error, Please try after some time!</p>');
									
								}
							}
							$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Role updated successfully!</p>');
						}
					}
					redirect(base_url('roles'));
				}
			}
		}
		$data['all_modules'] = $this->common->get_selected_columns('tbl_modules',$columns = array(),$where=array(),'multiple',$obj=true);
		//$data['modules_action'] = $this->common->get_selected_columns('tbl_modules_action',$columns = array(),$where=array(),'multiple',$obj=true);
		$data['modules_action'] = $this->common->module_list($limit=0,$offset=0);
		$data['assgn_role_permission'] = $assgn_role_id;
		$this->load->view('role/add_role',$data);
	}
	
	public function delete_role($id){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('roles/delete_role',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$delete_role = $this->common->update_record('tbl_roles',array('id'=>$id),array('status'=>0,'is_deleted'=>1));
		
		if($delete_role){
			
			$this->common->update_record('tbl_employees',array('role_id'=>$id),array('status'=>0,'is_deleted'=>1));
			
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Role deleted successfully!</p>');
			redirect(base_url('roles'));
			
		}else{
			
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
			
		}
	}
}