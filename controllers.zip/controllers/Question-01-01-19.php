<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Question extends CI_Controller {
	
	function __construct(){
		
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('question_model','qm');
		$this->load->model('common_model','common');
		$this->load->library('form_validation');
		$this->common->check_login();
		
	}
	
	public function index(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$this->load->library('pagination');
		$data['page'] = 'question_list';
		$config['base_url'] = base_url('question/index');
		$config['total_rows'] = $this->qm->num_question();
		$config['per_page'] = 10;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
       // $data["links"] = $this->pagination->create_links();
      
		
		if($this->session->userdata('role_id')=='3')
			{
				$userid = $this->session->userdata('emp_id');
				$data['adminquestion_list'] = $this->qm->getadmin_question_list($limit1=0, $offset1=0);		
				$data['managerquestion_list'] = $this->qm->getmanager_question_list($userid,$limit1=0, $offset1=0);
			}
			else
			{
				//$data['question_list'] = $this->qm->get_question_list($config["per_page"], $page);	
				$data['question_list'] = $this->qm->get_question_list($limit1=0, $offset1=0);
			}
		
		$data['category_list'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		$this->load->view('question/question_list',$data);
		
	}
	
	/*
	* Add functionality for Question module
	*/
	public function add(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/add',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$data = array();
		$data['page'] = 'question';
		if($this->uri->segment(3) != ''){
			redirect(base_url('question'));
		}
		if($this->input->post('submit') == 'Add Question'){
			
			/* Start checking for form validation rules */
			$this->form_validation->set_rules('category_id[]', 'Category', 'trim|required');
			
			$this->form_validation->set_rules('question', 'Question', 'trim|required');
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				$sess_role_id = $this->session->userdata('role_id');
				$ques_detail = array(
					'category' => implode(', ',$category_id),
					'question' => $question,
					'status' => ($status == 1) ? 1 : 0,
					'user_id' => $this->session->userdata('emp_id'),
					'created_at' => date('Y-m-d H:i:sa'),
					'role_id' => $sess_role_id,
				);
				//Inserting Question
				
				$this->common->insert_record('tbl_question',$ques_detail);
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question added successfully!</p>');
				
				redirect(base_url('question'));
			}
		}
		$data['category_list'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		$this->load->view('question/add_question',$data);
	}
	
	/*
	* Add functionality for Question module
	*/
	public function edit($question_id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/edit',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$data['page'] = 'question';
		if($this->uri->segment(3) == ''){
			redirect(base_url('question'));
		}
		/*
		Get/Edit Indivisual Question detail by id 
		*/
		if(!empty($question_id)){
			
			$data['ques'] = $this->common->get_selected_columns('tbl_question',$columns = array('question_id','question','category','status'),$where = array('question_id'=>$question_id),$reocrd = 'single',$obj=true);
			
		}
		
		if($this->input->post('submit') == 'Add Question'){
			
			/* Start checking for form validation rules */
			$this->form_validation->set_rules('category_id[]', 'Category', 'trim|required');
			
			$this->form_validation->set_rules('question', 'Question', 'trim|required');
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				
				$ques_detail = array(
					'category' => implode(', ',$category_id),
					'question' => $question,
					'status' => ($status == 1) ? 1 : 0,
				);
			
				if(!empty($question_id)){
					
					//updating Question
					$this->common->update_record('tbl_question',array('question_id'=>$question_id),$ques_detail);
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question updated successfully!</p>');
					
				}
				redirect(base_url('question'));
			}
		}
		$data['category_list'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		$this->load->view('question/add_question',$data);
	}
	
	
	
	public function delete_question($id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/delete_question',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$delete_ques = $this->common->delete_record('tbl_question',array('question_id'=>$id));
		
		if($delete_ques){
			$this->common->delete_record('tbl_assign_question',array('question'=>$id));
			
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question deleted successfully!</p>');
			redirect(base_url('question'));
			
		}else{
			
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
			
		}
	}
	/*
	* Add functionality for Category module
	*/
	public function add_category(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/add-category',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$data = array();
		$data['page'] = 'category';
		if($this->uri->segment(3) != ''){
			redirect(base_url('question/categories'));
		}
		
		if($this->input->post('submit') == 'Add Category'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('category_name', 'Category name', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_category_exist($category_name,'');
				if($check_existance){
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Category already exists!</p>');
					
				}else{
					
					$cat_detail = array(
						'category_name' => $category_name,
						'status' => ($status == 1) ? 1 : 0,
					);
				
					
					//Inserting Category
					$cat_detail['user_id'] = $this->session->userdata('emp_id');
					$cat_detail['created_at'] = date('Y-m-d H:i:sa');
					$this->common->insert_record('tbl_category',$cat_detail);
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Category added successfully!</p>');
						
					redirect(base_url('question/categories'));
				}
			}
		}
		$this->load->view('category/add_category',$data);
	}
	
	/*
	* Add functionality for Category module
	*/
	public function edit_category($cat_id){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/edit-category',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$data = array();
		$data['page'] = 'category';
		if($this->uri->segment(3) == ''){
			redirect(base_url('question/categories'));
		}
		/*
		Get/Edit Indivisual Category detail by id 
		*/
		
		if(!empty($cat_id)){
			$data['cat'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name','status'),$where = array('category_id'=>$cat_id),$reocrd = 'single',$obj=true);
		}
		
		if($this->input->post('submit') == 'Add Category'){
			
			/* Start checking for form validation rules */
			
			$this->form_validation->set_rules('category_name', 'Category name', 'trim|required');
			
			/* End checking for form validation rules */
			
			if ($this->form_validation->run() == TRUE){
				
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_category_exist($category_name,$cat_id);
				if($check_existance){
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Category already exists!</p>');
					
				}else{
					
					$cat_detail = array(
						'category_name' => $category_name,
						'status' => ($status == 1) ? 1 : 0,
					);
				
					if(!empty($cat_id)){
						
						//updating Category
						$this->common->update_record('tbl_category',array('category_id'=>$cat_id),$cat_detail);
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Category updated successfully!</p>');
						
					}
					redirect(base_url('question/categories'));
				}
			}
		}
		$this->load->view('category/add_category',$data);
	}
	/* Category list function*/
	public function categories(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/categories',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$this->load->library('pagination');
		$data['page'] = 'category_list';
		$config['base_url'] = base_url('question/category');
		$config['total_rows'] = $this->sm->num_category();
		$config['per_page'] = 10;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['category_list'] = $this->sm->get_category_list($config["per_page"], $page);
		$this->load->view('category/category_list',$data);
		
	}
	
	public function delete_category($id){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/delete_category',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$delete_cat = $this->common->delete_record('tbl_category',array('category_id'=>$id));
		
		if($delete_cat){
			
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Category deleted successfully!</p>');
			redirect(base_url('question/categories'));
			
		}else{
			
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
			
		}
	}
	
	public function assign_question($emp_id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('question/assign-question',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$assgn_ques_id = array();
		
		/** Assigned question to employee**/
		$assigned_question = $this->common->get_selected_columns('tbl_assign_question',$columns = array('assign_id','question'),$where = array('emp_id'=>$emp_id,'status'=>1,'review_status'=>0),$reocrd = 'multiple');
		
		if(!empty($assigned_question)){
			$assgn_ques_id = array_column($assigned_question,'question');
		}
		
		if($this->input->post('submit') == 'Assign Question'){
			
			$this->form_validation->set_rules('question[]', 'Question', 'trim|required');
			if ($this->form_validation->run() == TRUE){
				
				$question = $this->input->post('question');
				
				/* Checking the new question to be assigned to the employee*/
				$insert_question = array_diff($question,$assgn_ques_id);
				
				/* Checking the assigned question need to delete for particular employee*/
				$delete_question = array_diff($assgn_ques_id,$question);
				
				if(!empty($delete_question)){
					
					foreach($delete_question as $dq){
						$this->common->delete_record('tbl_assign_question',array('emp_id'=>$emp_id,'question'=>$dq,'status'=>1,'review_status'=>0));
					}
					
				}
				if(!empty($insert_question)){
					
					foreach($insert_question as $ques){
						$assign_detail[] = array(
							'emp_id'=>$emp_id,
							'question'=>$ques,
							'created_at'=>date('Y-m-d H:i:sa'),
							'status'=>1,
							'review_status'=>0,
						);
					}
					
					$insert = $this->db->insert_batch('tbl_assign_question',$assign_detail);
					
					if($insert){
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question Assigned successfully!</p>');
						
					}else{
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server error, Please try after some time!</p>');
						
					}
				}else{
					
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question Assigned successfully!</p>');
					
				}
				redirect(base_url('staff/employee'));
			}
		}
		
		$data['emp_questions'] = $assgn_ques_id;
		/**Fetching Employee name to whom we are assigning the question**/
		$data['emp'] = $this->common->get_selected_columns('tbl_employees',$columns = array('id','CONCAT(first_name," ",last_name) as emp_name'),$where = array('id'=>$emp_id),$reocrd = 'single',$obj=true);
		
		/**Fetching Question List**/
		$data['question_list'] = $this->common->get_selected_columns('tbl_question',$columns = array('question_id','question','category'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		$data['category_list'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		
		$this->load->view('question/assign_question',$data);
	}
/*---Superadmin assign question to manager----*/
	public function team_assign_question($emp_id){
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
	/* 	if(!in_array('question/assign-question',$role_permission)){
			redirect(base_url('not-authorized'));
		} */
		
		$data = array();
		$assgn_ques_id = array();
		
		/** Assigned question to employee**/
		$assigned_question = $this->common->get_selected_columns('tbl_teamassign_question',$columns = array('assign_id','question'),$where = array('emp_id'=>$emp_id,'status'=>1,'review_status'=>0),$reocrd = 'multiple');
		
		if(!empty($assigned_question)){
			$assgn_ques_id = array_column($assigned_question,'question');
		}
		
		if($this->input->post('submit') == 'Assign Question'){
			
			$this->form_validation->set_rules('question[]', 'Question', 'trim|required');
			if ($this->form_validation->run() == TRUE){
				
				$question = $this->input->post('question');
				
				/* Checking the new question to be assigned to the employee*/
				$insert_question = array_diff($question,$assgn_ques_id);
				
				/* Checking the assigned question need to delete for particular employee*/
				$delete_question = array_diff($assgn_ques_id,$question);
				
				if(!empty($delete_question)){
					
					foreach($delete_question as $dq){
						$this->common->delete_record('tbl_teamassign_question',array('emp_id'=>$emp_id,'question'=>$dq,'status'=>1,'review_status'=>0));
					}
					
				}
				if(!empty($insert_question)){
					
					foreach($insert_question as $ques){
						$assign_detail[] = array(
							'emp_id'=>$emp_id,
							'question'=>$ques,
							'created_at'=>date('Y-m-d H:i:sa'),
							'status'=>1,
							'review_status'=>0,
						);
					}
					
					$insert = $this->db->insert_batch('tbl_teamassign_question',$assign_detail);
					
					if($insert){
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question Assigned to Team Leader successfully!</p>');
						
					}else{
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server error, Please try after some time!</p>');
						
					}
				}else{
					
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Question Assigned to Team Leader successfully!</p>');
					
				}
				redirect(base_url('staff/team leader'));
			}
		}
		
		$data['emp_questions'] = $assgn_ques_id;
		/**Fetching Employee name to whom we are assigning the question**/
		$data['emp'] = $this->common->get_selected_columns('tbl_employees',$columns = array('id','CONCAT(first_name," ",last_name) as emp_name'),$where = array('id'=>$emp_id),$reocrd = 'single',$obj=true);
		
		/**Fetching Question List**/
		$data['question_list'] = $this->common->get_selected_columns('tbl_question',$columns = array('question_id','question','category'),$where = array('status'=>1,'role_id'=>1),$reocrd = 'multiple',$obj=true);
		$data['category_list'] = $this->common->get_selected_columns('tbl_category',$columns = array('category_id','category_name'),$where = array('status'=>1),$reocrd = 'multiple',$obj=true);
		
		$this->load->view('question/team_assign_question',$data);
	}
/*---End of superadmin assign question to manager---*/	
}