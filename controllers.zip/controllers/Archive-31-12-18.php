<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Archive extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('question_model','qm');
		$this->load->model('common_model','common');
		$this->load->library('form_validation');
		$this->common->check_login();
	}
	
	public function index(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
	
		
			 if($this->session->userdata('role_id')=='1' ||$this->session->userdata('role_id')=='3')
			{ 
			$leader_id= $this->session->userdata('emp_id');
			$data['page'] = 'archives';
			$this->load->library('pagination');
			$config['base_url'] = base_url('archive/index');
		
				$config['total_rows'] = $this->sm->num_pass_assessment_list();
			
			$config['per_page'] = 10;
			$config['uri_segment'] = 3;
			$data['total_rows'] = $config['total_rows'];
			if (isset($_GET)) {
				$config['enable_query_string'] = TRUE;
				$config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config["base_url"] . $config['suffix'];
			}
			$this->pagination->initialize($config);

			$page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
			$data['page_no'] = $page;
			$last_record_per_page = $config["per_page"] + ($data['page_no']);
			if ($data['total_rows'] < $last_record_per_page) {
				$last_record_per_page = $data['total_rows'];
			}
			$data["last_record_per_page"] = $last_record_per_page;
			$data["links"] = $this->pagination->create_links();
			
			$data['role_list'] = $this->sm->pass_assessment_list($config["per_page"], $page);
			
			$this->load->view('archive/archives',$data);
			}
			else
			{
				redirect(base_url('not-authorized'));
			}
		
		
	}
	
	
	public function archivelist($type="",$period=""){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		 if($this->session->userdata('role_id')=='1' ||$this->session->userdata('role_id')=='3')
			{
		$achivedate=explode("to",$period);
		$data['pfromdate']=$achivedate[0];
		$data['ptodate']=$achivedate[1];
		$frmdateArr= explode("-",$achivedate[0]);
		$fromdate=$frmdateArr[2].'-'.date("m",strtotime($frmdateArr[0])).'-'.$frmdateArr[1];
		$data['fromdate']=$fromdate;
		$todateArr= explode("-",$achivedate[1]);
		$todate=$todateArr[2].'-'.date("m",strtotime($todateArr[0])).'-'.$todateArr[1];
		$data['todate']=$todate;
		$leader_id= $this->session->userdata('emp_id');
			$data['page'] = 'archive_list';
			$this->load->library('pagination');
			$config['base_url'] = base_url('archive/index');
			if($type=='employee')
			{
					
					$config['total_rows'] = $this->sm->num_archive_emp($leader_id,$fromdate=$fromdate,$todate=$todate);
			}
			else
			{
				$config['total_rows'] = $this->sm->num_archive_team($fromdate=$fromdate,$todate=$todate);
			}
			$config['per_page'] = 50;
			$config['uri_segment'] = 3;
			$data['total_rows'] = $config['total_rows'];
			if (isset($_GET)) {
				$config['enable_query_string'] = TRUE;
				$config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config["base_url"] . $config['suffix'];
			}
			$this->pagination->initialize($config);

			//$page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
			$page = 0;
			$data['page_no'] = $page;
			$last_record_per_page = $config["per_page"] + ($data['page_no']);
			if ($data['total_rows'] < $last_record_per_page) {
				$last_record_per_page = $data['total_rows'];
			}
			$data["last_record_per_page"] = $last_record_per_page;
			$data["links"] = $this->pagination->create_links();
			if($type=='employee')
			{
			$data['role_list'] = $this->sm->get_archive_list_emp($leader_id,$fromdate=$fromdate,$todate=$todate,$config["per_page"], $page);
			
			
			}
			else
			{
				$data['role_list'] = $this->sm->get_archive_list_team($fromdate=$fromdate,$todate=$todate,$config["per_page"], $page);
			}
			$this->load->view('archive/archive_list',$data);
			}
			else
			{
				redirect(base_url('not-authorized'));
			}
		
		
	}
	
	
}