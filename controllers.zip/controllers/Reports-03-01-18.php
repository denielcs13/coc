<?php
error_reporting(E_ALL);
error_reporting(1);
ini_set('display_errors', 1);  
/* -----------------------All Export and Import functionality---------------------------------- */

class Reports extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('common_model','common');
        $this->load->library('form_validation');
    }
	
	public function upload_staffs() {
        $this->common->check_login();
        $this->load->library('Excel');
        $arr['error'] = '';    //initialize image upload error array to empty
//$csv_file = $_FILES['upload_csv']['name'];

        if (isset($_FILES) && !empty($_FILES)) {
            $csv_file = $_FILES['upload_csv']['name'];
            $config['upload_path'] = FCPATH . 'assets/uploads/';
            $config['allowed_types'] = 'csv|xls|xlsx';
            //$config['max_size'] = '2000';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('upload_csv')) {
              $arr['error'] = $this->upload->display_errors();
            } else {
				
                $file_data = $this->upload->data();
                $file_path = FCPATH . 'assets/uploads/' . $file_data['file_name'];
                $my_data = array();
                $header_array = Array
                    ('EmployeeId','FromDate','ToDate','CurrentTitle', 'CurrentSalary', 'CurrentSalaryReviewPeriod', 'BaseBillableHours','SurplusBillableHours','NonBillableHours','BillableBonus','DiscretionaryBonus','TeamBonus','AdjustedSalary','AdjustedTitle');
                $count = 0;
                $compare = '';
                $arr_max_id = $this->common->get_max_id('tbl_employee_salary_details');
                $insert_id = $arr_max_id['id'] + 1;
//read file from path
                $objPHPExcel = PHPExcel_IOFactory::load($file_path);
// Get Highest Column
                $highestColumm = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); // e.g. "EL"
// Get Highest Row
                $highestRow = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();  // e.g. 5
                $highestColumm++;
                for ($row = 1; $row < $highestRow + 1; $row++) {
                    $dataset = array();
                    for ($column = 'A'; $column != $highestColumm; $column++) {
                        $dataset[] = $objPHPExcel->setActiveSheetIndex(0)->getCell($column . $row)->getValue();
                    }
                    $datasets[] = $dataset;
                }
				//$from_date = $this->input->post('from_date');
				//$to_date = $this->input->post('to_date');
			
				$errorEmp = 0;
				$errorFrDt = 0;
				$errorToDt = 0;
				
                foreach ($datasets as $csv_array) {
					
				
                    if ($count > 0) {
				
						$employee = $this->common->get_selected_columns('tbl_employees',array('id'),array('employee_id'=>$csv_array[0]),'single',$obj_form=true);
                        if (!empty($employee)) {
							
                            if($csv_array[1]!="")
							{
								
								$fromdate=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($csv_array[1]));
								
							}
							
							if($csv_array[2]!="")
							{
								$todateArr=explode("/",$csv_array[2]);
								$todate=date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($csv_array[2]));
								
							}
										
							$my_data[] = array(
                                'id' => $insert_id,
                                'emp_id' => $employee->id,
                                'from_date' => $fromdate,
                                'to_date' => $todate,
                                'current_title' => (!empty($csv_array[3])) ? ($csv_array[3]) : '',
                                'current_salary' => (!empty($csv_array[4])) ? $csv_array[4] : '',
                                'current_salary_review_period' => (!empty($csv_array[5])) ? $csv_array[5] : '',                                
                                'base_billable_hours' => (!empty($csv_array[6])) ? $csv_array[6] : '',
                                'surplus_billable_hours' => (!empty($csv_array[7])) ? $csv_array[7] : '',                                
                                'non_billable_hours' => (!empty($csv_array[8])) ? $csv_array[8] : '',                                
                                'billable_bonus' => (!empty($csv_array[9])) ? $csv_array[9] : '',
                                'discretionary_bonus' => (!empty($csv_array[10])) ? $csv_array[10] : '',
                                'team_bonus' => (!empty($csv_array[11])) ? $csv_array[11] : '',                                
                                'adjusted_salary' => (!empty($csv_array[12])) ? $csv_array[12] : '',                               
                                'adjusted_title' => (!empty($csv_array[13])) ? $csv_array[13] : '',
                            );
                        } else {
							if(empty($employee)){
								$errorEmp++;
							}else if(empty($from_date)){
								$errorFrDt++;
							}else if(empty($to_date)){
								$errorToDt++;
							}
                            
                        }
                        $insert_id++;
                    } else {
                        $compare = array_diff($csv_array, $header_array);
                        if (count($compare) > 0) {
                            $this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> We need proper format to upload. Please check your format before uploading!</p>');
                            if (file_exists($file_path)) {
                                unlink($file_path);
                            }
                            break;
                        }
                    }
                    $count++;
                }
				
				$err_msg = '';
				if(!empty($errorEmp)){
					$err_msg = ' and '.$errorEmp.' rows failed to upload due to blank or wrong Employee id';
				}else if(!empty($errorFrDt)){
					$err_msg = ' and '.$errorFrDt.' rows failed to upload due to blank From date';
				}else if(!empty($errorToDt)){
					$err_msg = ' and '.$errorFrDt.' rows failed to upload due to blank To date';
				}
                if (!empty($my_data)) {
                    $this->db->insert_batch('tbl_employee_salary_details', $my_data);

                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
					
                    $this->session->set_flashdata('message', '<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Data Imported Successfully'.$err_msg.'!</p>');
                    redirect(base_url('staff/employee'));
                } else {
                    $this->session->set_flashdata('message', '<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> The Csv file you have uploaded is not uploaded'.$err_msg.'!</p>');
					
                    redirect(base_url('staff/employee'));
                }
            }
        }
    }
	public function import_staff_format() {
        $this->load->library('excel');
        $this->excel->setActiveSheetIndex(0);
        //name the worksheet
        $this->excel->getActiveSheet()->setTitle('staff_sheet');
        $k = 1;
        //set cell Heading content with some text
        $this->excel->getActiveSheet()->setCellValue('A' . $k, 'EmployeeId');
		$this->excel->getActiveSheet()->setCellValue('B' . $k, 'FromDate');
		$this->excel->getActiveSheet()->setCellValue('C' . $k, 'ToDate');
        $this->excel->getActiveSheet()->setCellValue('D' . $k, 'CurrentTitle');
        $this->excel->getActiveSheet()->setCellValue('E' . $k, 'CurrentSalary');
        $this->excel->getActiveSheet()->setCellValue('F' . $k, 'CurrentSalaryReviewPeriod');        
        $this->excel->getActiveSheet()->setCellValue('G' . $k, 'BaseBillableHours');
        $this->excel->getActiveSheet()->setCellValue('H' . $k, 'SurplusBillableHours');       
        $this->excel->getActiveSheet()->setCellValue('I' . $k, 'NonBillableHours');       
        $this->excel->getActiveSheet()->setCellValue('J' . $k, 'BillableBonus');
        $this->excel->getActiveSheet()->setCellValue('K' . $k, 'DiscretionaryBonus');
        $this->excel->getActiveSheet()->setCellValue('L' . $k, 'TeamBonus');        
        $this->excel->getActiveSheet()->setCellValue('M' . $k, 'AdjustedSalary');       
        $this->excel->getActiveSheet()->setCellValue('N' . $k, 'AdjustedTitle');
        
        for ($col = ord('A'); $col <= ord('N'); $col++) {
            //$this->excel->getActiveSheet()->getStyle(chr($col) . '1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->getStyle(chr($col) . '1')->getFont()->setSize(12);
            $this->excel->getActiveSheet()->getStyle(chr($col) . '1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //set column dimension
            $this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
            //change the font size
            $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(10);
            $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        
        
        $filename = 'staff_format.xls'; //save our workbook as this file name
        header('Content-Type: application/vnd.ms-excel'); //mime type
        header('Content-Disposition: attachment;filename="' . $filename . '"'); //tell browser what's the file name
        header('Cache-Control: max-age=0'); //no cache
        //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
        //if you want to save it as .XLSX Excel 2007 format
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
        //force user to download the Excel file without writing it to server's HD
        $objWriter->save('php://output');
    }
	
}