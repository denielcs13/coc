<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
error_reporting(1);
ini_set('display_errors', 1);  
class Archive extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('question_model','qm');
		$this->load->model('common_model','common');
		$this->load->library('form_validation');
		$this->common->check_login();
	}
	
	public function index(){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
	
		
			 if($this->session->userdata('role_id')=='1' ||$this->session->userdata('role_id')=='3')
			{ 
			$leader_id= $this->session->userdata('emp_id');

			
			$data['archive_years'] = $this->sm->archive_year();
			
			
			$this->load->view('archive/archives',$data);
			}
			else
			{
				redirect(base_url('not-authorized'));
			}
		
		
	}
	
	
	public function archivelist($period=""){
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		 if($this->session->userdata('role_id')=='1' ||$this->session->userdata('role_id')=='3')
			{
		$data['period']=$period;
		$achivedate=explode("-to-",$period);
		
		$data['pfromdate']=$achivedate[0];
		$data['ptodate']=$achivedate[1];
		$frmdateArr= explode("-",$achivedate[0]);
		$fromdate=$frmdateArr[2].'-'.date("m",strtotime($frmdateArr[0])).'-'.$frmdateArr[1];
		$data['fromdate']=$fromdate;
		
		$todateArr= explode("-",$achivedate[1]);	
		$datemonth = @date_parse($todateArr[0]);
  
		$todate=$todateArr[2].'-'.$datemonth['month'].'-'.$todateArr[1];
		$data['todate']=$todate;
		$leader_id= $this->session->userdata('emp_id');
			
			if($this->session->userdata('role_id')=='1' )
			{
			$data['emp_list'] = $this->sm->get_archive_list_emp_admin($fromdate=$fromdate,$todate=$todate);			
			
			$data['team_list'] = $this->sm->get_archive_list_team($fromdate=$fromdate,$todate=$todate);
			}
			else
			{
				$data['emp_list'] = $this->sm->get_archive_list_emp($leader_id,$fromdate=$fromdate,$todate=$todate);
			}
			
			$this->load->view('archive/archive_list',$data);
			}
			else
			{
				redirect(base_url('not-authorized'));
			}
		
		
	}
	

public function assessmentpdf($emp_id=false,$period=""){
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		
			$achivedate=explode("-to-",$period);
		
		$data['pfromdate']=$achivedate[0];
		$data['ptodate']=$achivedate[1];
		$frmdateArr= explode("-",$achivedate[0]);
		$fromdate=$frmdateArr[2].'-'.date("m",strtotime($frmdateArr[0])).'-'.$frmdateArr[1];
		
		
		$todateArr= explode("-",$achivedate[1]);	
		$datemonth = @date_parse($todateArr[0]);
  
		$todate=$todateArr[2].'-'.$datemonth['month'].'-'.$todateArr[1];
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
		$ass_query=$this->db->query("select * from tbl_open_assessment where submi_from='".$fromdate."' and submi_to='".$todate."'"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['fromdate']=date('F d,Y',strtotime($sumitdb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d,Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_salary_detail($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
		 $html = $this->load->view('emp_assesment_pdf',$data,true);
		// Load library
	
		$this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_assesment_".$emp_id.".pdf"); 
	}	
/*------end of start assessment---*/	
	
	
}