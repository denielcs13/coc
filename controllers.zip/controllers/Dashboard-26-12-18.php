<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	function __construct(){
		
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->load->model('question_model','qm');
		$this->load->library('form_validation');
		$this->load->library('general_functions');
		$this->load->helper('genral_helper');
		
	}
	
	public function home(){
		$sess_emp_id = $this->session->userdata('emp_id');
		$data = array();
		$this->common->check_login();
		$data['count_assesment'] = count($this->qm->get_employee_self_assesment($sess_emp_id,$status=1,$review_status=1));
		$blank_ans = $this->common->get_selected_columns('	tbl_assign_question',array('assign_id'),array('status'=>1,'review_status'=>1,'emp_id'=>$sess_emp_id,'answer'=>''),'multiple');
		$data['count_blank_ans'] = count($blank_ans);
		$this->load->view('dashboard',$data);
	}
	
	/* 
	*********User login***********
	*Post data
	1 - Employee Email as emp_email
	2 - Employee Password as emp_password
	*/
	
	public function index(){
		
		$data = array();
		$role_permission = array();
		$data['action'] = '';
		
		$sess_emp_id = $this->session->userdata('emp_id');
		if(!empty($sess_emp_id)){
			redirect('dashboard');
		}
		
		if($this->input->post('submit') == 'login'){
			
			/*This is login section code*/
			
			$data['action'] = 'login';
			$this->form_validation->set_rules('emp_email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('emp_password', 'Password', 'required');
			
			if ($this->form_validation->run() == TRUE){
				
				$emp_email = $this->input->post('emp_email');
				$emp_password = $this->input->post('emp_password');
				$remember_me = $this->input->post('remember_me');
				$password = md5($emp_password);
				
				//check whether user email is registered or not
				$check_existance = $this->sm->is_employee_exist($emp_email,$id='');
				
				if($check_existance){
					
					$login_data = $this->sm->login($emp_email,$password);
					$ses_role_id = (isset($login_data->role_id)) ? $login_data->role_id : '';
					if(!empty($login_data)){
						$this->session->set_userdata(
							array(
							'emp_id' => $login_data->id,
							'first_name' => $login_data->first_name,
							'last_name' => $login_data->last_name,
							'email' => $login_data->email,
							'role_id' => $login_data->role_id,
							'role_name' => $login_data->role_name,
							'profile_img' => $login_data->profile_img,
							)
						);
						$user_roles = $this->common->get_permission_by_role_id($ses_role_id);
						if(!empty($user_roles)){
							$role_permission = array_column($user_roles,'action_url');
						}
						
						$this->session->set_userdata(array('role_permission'=>$role_permission));
						
						/*Setting cookies if remember me is checked*/
						
						if (isset($remember_me) && $remember_me == "1") {
                            $this->input->set_cookie('remember_email', $emp_email, 86500);
                            $this->input->set_cookie('remember_password', $emp_password, 86500);
                            $this->input->set_cookie('remember_me', 1, 86500);
                        }else{
							
							/*Deleting cookies if remember me is unchecked*/
							
							$this->load->helper('cookie');
							delete_cookie("remember_email");
							delete_cookie("remember_password");
							delete_cookie("remember_me");
							
						}
						
						redirect(base_url('dashboard'));
						
					}else{
						
						/* if user enters wrong username/email or password */
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Email/Password is incorrect!</p>');
						
					}
				}else{
					
					/*If user does not exist with us*/
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> User does not exist!</p>');
					
				}
				
			}
			
		}else if($this->input->post('submit') == 'Forget Password'){
			
			/*This is forget password section*/
			
			$data['action'] = 'Forget Password';
			$this->form_validation->set_rules('forget_email', 'Email', 'trim|required|valid_email');
			
			if($this->form_validation->run() == TRUE){
				
				$forget_email = $this->input->post('forget_email');
				
				/*Checking where employee/user exist with us or not */
				$arr_exist = $this->sm->is_employee_exist($forget_email,'');
				
				if(!empty($arr_exist)){
					
					/* Block for employee exists with us */
					
					$url = base_url().'reset-password?'.'email=' . base64_encode($forget_email);
					
					$message = 'Hi '.$forget_email.',<br />
					Please click the link below to Reset your password.
					<br/>
					<a href="'.$url.'">'.$url.'</a>';
					
					//$send_email = sendmail($forget_email,'Forget Password',$message,'testing10@iwesh.com');
					
					$send_email = $this->general_functions->send_email($from_email="testing10@iwesh.com", $from_name="Employee review", $to_email=$forget_email, $subject="Forget Password",$message,$protocol="");
					
					if($send_email){
						
						$data['msg'] = "<div class='alert alert-success' style='text-align:center;'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Please check your Email !</div>";
						
					}else{
						
						$data['msg'] = "<div class='alert alert-danger' style='text-align:center;'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Problem in Updating Password !</div>";
						
					}
				}else{
					
					$data['msg'] = "<div class='alert alert-danger' style='text-align:center;'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Email not registered with us !</div>";
					
				}
			}
		}
		$this->load->view('login',$data);
	}
	
	public function logout(){
		
		$this->session->set_userdata(
							array(
							'emp_id' => '',
							'first_name' => '',
							'last_name' => '',
							'email' => '',
							'role_id' => '',
							'role_name' => '',
							'profile_img' => '',
							'role_permission' => array(),
							)
						);
		$this->session->sess_destroy();
		redirect(base_url('dashboard'));
		
	}
	public function reset_password() {
		
		$data['email'] = base64_decode($this->input->get('email'));
		
		if($this->input->post()){
			
			$this->form_validation->set_rules('new_pass', 'New password', 'trim|required');
			$this->form_validation->set_rules('confirm_pass', 'Confirm password', 'trim|required');
			if($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				
				if($new_pass == $confirm_pass){
					
					if($this->common->update_record('tbl_employees',array('email'=>$usr_email),array('password'=>md5($confirm_pass)))){
						
						$this->session->set_flashdata('message', '<div class="alert alert-success" style="text-align:center;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> Password Reset Successfully.Please Login to your account !</div>');
						redirect(base_url('dashboard'));
						
					}else{
						
						$this->session->set_flashdata('message', '<div class="alert alert-danger" style="text-align:center;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> Problem in Updating Password.</div>');
						
					}
				}else{
					
					$this->session->set_flashdata('message', '<div class="alert alert-danger" style="text-align:center;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> New Password And Confirm Password Does\'nt Match.</div>');
					redirect(base_url('employees/reset_password?').'email=' . base64_encode($usr_email));
					
				}
			} 
		}
        $this->load->view('reset_password',$data);
    }
	
	
	public function change_password(){
		
        $this->common->check_login();
		$data = array();
		
 		if($this->input->post('action') == 'Change Password'){
			
			$this->form_validation->set_rules('old_pass', 'Old Password', 'trim|required');
			$this->form_validation->set_rules('new_pass', 'New Password', 'trim|required|matches[confirm_pass]');
			$this->form_validation->set_rules('confirm_pass', 'Confirm Password', 'trim|required|matches[new_pass]');
			$post = $this->input->post();
			extract($post);
			
			if($this->form_validation->run() == TRUE){
				
				$emp_id = $this->session->userdata('emp_id');
				
				// This function fetch the old password of user currently in the session
				$saved_password = $this->common->get_selected_columns('tbl_employees',$columns = array('password'),$where = array('id'=>$emp_id),'single');
				$old_password = md5($old_pass);
				$pass_data = array('password' => md5($confirm_pass));
				
				if($saved_password['password'] == $old_password){
					
					if($this->common->update_record('tbl_employees',array('id'=>$emp_id),$pass_data)){ 
					
						$this->session->set_flashdata("cp_message", "<div class='alert alert-success text-center'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Password Change Successfully !</div>");
						redirect(base_url('employees/change-password'),'refresh');
						
					}else{
						
						$this->session->set_flashdata("cp_message", "<div class='alert alert-danger text-center'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Problem in Changing Password !</div>");
						
					}
				}else{
					
					$this->session->set_flashdata("cp_message", "<div class='alert alert-danger text-center'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Old Password and Saved Password Does not match!</div>");
					
				}
			}
		}
        $this->load->view('change_password',$data);
    }
	
	public function profile(){
		$this->common->check_login();
		$data['tab'] = '';
		$user_id = $this->session->userdata('emp_id');
		
		if($this->input->post('sub_basic_info') == 'Basic Info'){
			
			$data['tab'] = 'Update Basic Info';
			$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
			$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
			$this->form_validation->set_rules('email_addr', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('contact_number', 'Contact Number', 'trim|required|regex_match[/^[0-9]{10}$/]|min_length[10]|max_length[10]');
			if($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$basic_info = array(
								'first_name'=>$first_name,
								'last_name'=>$last_name,
								'email'=>$email_addr,
								'phone'=>$contact_number,
				);
				if($this->common->update_record('tbl_employees',array('id'=>$user_id),$basic_info)){
					$this->session->set_userdata(
							array(
							'first_name' => $first_name,
							'last_name' => $last_name,
							'email' => $email_addr
							)
						);
					$data['tab'] = 'View Basic Info';
					$this->session->set_flashdata("prof_message","<div class='col-md-12 alert alert-success text-center'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Basic Info Updated !</div>");
				}else{
					$this->session->set_flashdata("prof_message","<div class='alert alert-danger text-center'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Problem in Updating Basic Info !</div>");
				}
				redirect(base_url('profile'));
			}
		}
		$data['user'] = $this->sm->get_staff_by_id($user_id);
		$this->load->view('profile',$data);
	}
	
	//Uploading user profile images using ajax
	public function upload_image(){
        $del_img = '';
        $config = [
            'upload_path' => './assets/images/staff_image/',
            'allowed_types' => 'jpg|png|jpeg',
        ];
        $user_id = $this->session->userdata('emp_id');
        $this->load->library('upload', $config);
        $this->upload->do_upload('image_upload');
        $filedata = $this->upload->data();
        $imagePath = $filedata['raw_name'] . $filedata['file_ext'];
        $hidden_img = $this->input->post('hidden_img');
        if (!empty($hidden_img) && file_exists(FCPATH . '/assets/images/staff_image/' . $hidden_img)) {
            $del_img = FCPATH . '/assets/images/staff_image/' . $hidden_img;
            unlink($del_img);
        }
        if ($this->common->update_record('tbl_employees', array('id' => $user_id), array('profile_img' => $imagePath))) {
			$this->session->set_userdata(array('profile_img'=>$imagePath));
            $html['msg'] = "Image saved sucessfully !";
            $html['status'] = '1';
            $html['image_logo'] = base_url() . 'assets/images/staff_image/' . $imagePath;
        } else {
            $html['msg'] = "Problem in uploading Image !";
            $html['status'] = '2';
            $html['image_logo'] = '';
        }
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($html));
        die;
    }
}