<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
error_reporting(1);
ini_set('display_errors', 1);  
class Staff extends CI_Controller {
	
	function __construct(){
		
		parent::__construct();
		$this->load->model('staff_model','sm');
		$this->load->model('common_model','common');
		$this->load->model('question_model','qm');
		$this->load->library('form_validation');
		$this->load->library('general_functions');
		$this->load->helper('genral_helper');
		
	}
	public function index($role_name=""){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data['role_name'] = $role_name;
		$data['page'] = 'staff_list';
		$this->load->library('pagination');
		/*Gettin role id for the employee list by their role*/
		$role = $this->common->get_selected_columns('tbl_roles',$columns = array('id'),$where = array('LOWER(role_name)'=>urldecode(strtolower($role_name))),$reocrd = 'single',$obj=true);
		$role_id = (isset($role->id) && !empty($role->id)) ? $role->id : '';
		
		$config['base_url'] = base_url('staff/index/'.$role_name.'/');
		$config['total_rows'] = $this->sm->num_staffs($role_id);
		$config['per_page'] = 10;
		$config['uri_segment'] = 4;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
        $data['employee_list'] = $this->sm->get_staff_list($role_id,$config["per_page"], $page);
		$this->load->view('staff/staff_list',$data);
	}
	
	public function not_authorized(){
		$this->load->view('not_authorized');
	}
	/*
	* Add functionality for Employee module
	*/
	public function add(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/add',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$data = array();
		$salary_detail = array();
		$data['page'] = 'staff';
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('first_name', 'First name', 'trim|required');
			$this->form_validation->set_rules('last_name', 'Last name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('emp_role', 'Employee role', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
			$this->form_validation->set_rules('employee_id', 'Employee id', 'trim|required');
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_employee_exist($email,$id='');
				$check_emp_id = $this->sm->is_employee_id_exist($employee_id,$id='');
				if($check_existance){
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Email already exists!</p>');
				}else if($check_emp_id){
					$this->session->set_flashdata('empid_message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Id already taken!</p>');
				}else{
							$emp_image = $_FILES['emp_image']['name'];
				
					if (isset($emp_image) && !empty($emp_image)) {
						
					$config['upload_path']   =  './assets/images/staff_image/';
				
                $config['allowed_types']        = 'gif|jpg|png';
               

                $this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('emp_image') )
                {
                        $error = array('error' => $this->upload->display_errors());

                      
						$image=$this->input->post('file_path');
                }
				else{
					 $succ = array('upload_data' => $this->upload->data());
				  	$image = $succ['upload_data']['file_name'];
				}
						$del_img = './assets/images/staff_image/' . $this->input->post('hidden_emp_img');
						if ($this->input->post('hidden_emp_img') != '' && file_exists($del_img)) {
							unlink($del_img);
						}
					} else {
						$image = $this->input->post('hidden_emp_img');
					}
					$emp_detail = array(
						'first_name' => $first_name,
						'last_name' => $last_name,
						'email' => $email,
						'phone' => $phone,
						'role_id' => $emp_role,
						'manager_id'=>$manager_id,
						'status' => ($status == 1) ? 1 : 0,
						'created_at' => date('Y-m-d H:i:sa'),
						'password' => md5($password),
						'profile_img' => $image,
						'employee_id' => $employee_id,
					);
					$role_id = $this->session->userdata('role_id');
					if($role_id > 1){
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> You are not authorized for this action!</p>');
						redirect(base_url('staff/'.strtolower($hidden_role_name)));
					}
					
					//Inserting employee
					$emp_id = $this->common->insert_record('tbl_employees',$emp_detail);
					if($emp_id){
						if(isset($from_date) && isset($to_date)){
							for($i=0;$i<count($from_date);$i++){
								if(!empty($from_date[$i]) && !empty($to_date[$i])){
								$salary_detail[] = array(
									'emp_id'=>$emp_id,
									'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
								);	
								}
							}
						}
						if(!empty($salary_detail)){
							$this->db->insert_batch('tbl_employee_salary_details',$salary_detail);
						}
						$message = 'Hi '.$first_name.' '.$last_name.',<br/>
						Your account has been created, Below are the credential to login to your account.<br/>
						Url: '.base_url().'<br/>
						Username/Email : '.$email.'<br/>
						Password : '.$password.'<br/>
						';
						$this->general_functions->send_email($from_email="testing10@iwesh.com", $from_name="Employee review", $to_email=$email, $subject="Employee Registration",$message,$protocol="");
						
						//sendmail($to = $email,$subject = 'Employee Registration',$message,$from = 'testing10@iwesh.com');
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee details added successfully!</p>');
						redirect(base_url('staff/'.strtolower($hidden_role_name)));
					}else{
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some time!</p>');
					}
				}
			}
		}
		$emp_id="";
		$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('id','CONCAT(first_name," ",last_name) as name','email'),array('role_id'=>3,'id !='=>$emp_id),'multiple',$obj=true);
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/add_staff',$data);
	}
	
	public function edit($emp_id){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/edit',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		$data = array();
		$data['page'] = 'staff';
		
		$update_salary_detail = array();
		$insert_salary_detail = array();
		/*
		Get/Edit Indivisual employee detail by id 
		*/
		if(!empty($emp_id)){
			$data['emp'] = $this->sm->get_staff_by_id($emp_id);
			if(isset($data['emp']->role_id) && $data['emp']->role_id == 4){
				$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('id','CONCAT(first_name," ",last_name) as name','email'),array('role_id'=>3,'id !='=>$emp_id),'multiple',$obj=true);
			}
			$data['salary_detail'] = $this->common->get_selected_columns('tbl_employee_salary_details',$columns = array(),$where = array('emp_id'=>$emp_id),$fetch_rec ='multiple',$object_frm=true);
		}
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('first_name', 'First name', 'trim|required');
			$this->form_validation->set_rules('last_name', 'Last name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('emp_role', 'Employee role', 'trim|required');
			$this->form_validation->set_rules('employee_id', 'Employee id', 'trim|required');
			
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$check_existance = $this->sm->is_employee_exist($email,$emp_id);
				$check_emp_id = $this->sm->is_employee_id_exist($employee_id,$emp_id);
				if($check_existance){
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Email already exists!</p>');
				}else if($check_emp_id){
					$this->session->set_flashdata('empid_message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Id already taken!</p>');
				}else{
					$emp_image = $_FILES['emp_image']['name'];
					if (isset($emp_image) && !empty($emp_image)) {
						$config = [
							'upload_path' => './assets/images/staff_image/',
							'allowed_types' => 'jpg|png|jpeg'
						];
						$this->load->library('upload', $config);
						if ($this->upload->do_upload("emp_image")) {
							$filedata = $this->upload->data();
							$file_name = $filedata['file_name'];
							$image = $file_name;
						}
						$del_img = './assets/images/staff_image/' . $this->input->post('hidden_emp_img');
						if ($this->input->post('hidden_emp_img') != '' && file_exists($del_img)) {
							unlink($del_img);
						}
					} else {
						$image = $this->input->post('hidden_emp_img');
					}
					$emp_detail = array(
						'first_name' => $first_name,
						'last_name' => $last_name,
						'email' => $email,
						'phone' => $phone,
						'role_id' => $emp_role,
						'manager_id'=>$manager_id,
						'status' => ($status == 1) ? 1 : 0,
						'profile_img' => $image,
						'employee_id' => $employee_id,
					);
				
					if(!empty($emp_id)){
						if($data['emp']->password != $password){
							$emp_detail['password'] = md5($password);
						}
						//updating employee
						$update = $this->common->update_record('tbl_employees',array('id'=>$emp_id),$emp_detail);
						
						if($update){
							if(isset($from_date) && isset($to_date)){
							for($i=0;$i< count($from_date);$i++){
								if(!empty($row_id[$i]) && !empty($from_date[$i]) && !empty($to_date[$i])){
									$update_salary_detail[] = array(
										'id'=>$row_id[$i],
										'emp_id'=>$emp_id,
										'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
									);
								}
								if(empty($row_id[$i]) && !empty($from_date[$i]) && !empty($to_date[$i])){
									$insert_salary_detail[] = array(
										'emp_id'=>$emp_id,
										'from_date'=>$from_date[$i],
									'to_date'=>$to_date[$i],
									'current_title'=>$current_title[$i],
									'current_salary'=>$current_salary[$i],
									'current_salary_review_period'=>$current_salary_review_period[$i],
									'total_period_bonus'=>$total_period_bonus[$i],
									'total_review_period_compensation'=>$total_review_period_compensation[$i],
									'perc_salary'=>$perc_salary[$i],
									'perc_bonus'=>$perc_bonus[$i],
									'salary_chart'=>$salary_chart[$i],
									'bonus_chart'=>$bonus_chart[$i],
									'base_billable_hours'=>$base_billable_hours[$i],
									'surplus_billable_hours'=>$surplus_billable_hours[$i],
									'billable_surplus_combined'=>$billable_surplus_combined[$i],
									'non_billable_hours'=>$non_billable_hours[$i],
									'total_submitted_hours'=>$total_submitted_hours[$i],
									'base_billable_chart'=>$base_billable_chart[$i],
									'surplus_chart'=>$surplus_chart[$i],
									'non_billable_chart'=>$non_billable_chart[$i],
									'billable_bonus'=>$billable_bonus[$i],
									'discretionary_bonus'=>$discretionary_bonus[$i],
									'team_bonus'=>$team_bonus[$i],
									'total_bonus'=>$total_bonus[$i],
									'perc_billable_bonus'=>$perc_billable_bonus[$i],
									'perc_discretionary_bonus'=>$perc_discretionary_bonus[$i],
									'perc_team_bonus'=>$perc_team_bonus[$i],
									'billable_bonus_chart'=>$billable_bonus_chart[$i],
									'discretionary_bonus_chart'=>$discretionary_bonus_chart[$i],
									'team_bonus_chart'=>$team_bonus_chart[$i],
									'adjusted_salary'=>$adjusted_salary[$i],
									'variance'=>$variance[$i],
									'adjusted_title'=>$adjusted_title[$i],
									);
								}
							}
							}
							
							if(!empty($update_salary_detail)){
								$this->db->update_batch('tbl_employee_salary_details',$update_salary_detail,'id');
							}
							if(!empty($insert_salary_detail)){
								$this->db->insert_batch('tbl_employee_salary_details',$insert_salary_detail);
							}
						}
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee details updated successfully!</p>');
					}
					redirect(base_url('staff/'.strtolower($hidden_role_name)));
				}
			}
		}
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/add_staff',$data);
	}
	
	public function delete_staff(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('staff/delete_staff',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$action = $this->uri->segment(3);
		$id = $this->uri->segment(4);
		$staffinfo=$this->sm->get_staff_by_id($id);
		if($staffinfo->role_id=='3')
		{
			/*--Delete team memeber data----*/
			$this->common->delete_record('tbl_teamassign_question',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_salary_details',array('emp_id'=>$id));
			$this->common->delete_record('tbl_question',array('user_id'=>$id));
			
			$this->common->delete_record('tbl_assign_question',array('leader_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('leader_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('leader_id'=>$id));
			/*
			$update_empquestionry = $this->common->update_record('tbl_assign_question',array('leader_id'=>$id),array('leader_id'=>''));
			
			$update_empassess = $this->common->update_record('tbl_employee_assessment',array('leader_id'=>$id),array('leader_id'=>''));
			$update_empsalary = $this->common->update_record('tbl_employee_assevaluation',array('leader_id'=>$id),array('leader_id'=>''));
			*/
			/*---End of delete team memeber data----*/
		}
		else if($staffinfo->role_id=='4')
		{
			/*--Delete employee data----*/
			$this->common->delete_record('tbl_assign_question',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assessment',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_assevaluation',array('emp_id'=>$id));
			$this->common->delete_record('tbl_employee_salary_details',array('emp_id'=>$id));
			
			
			$update_manager = $this->common->update_record('tbl_employees',array('id'=>$id),array('manager_id'=>0));
			/*--Delete employee data----*/
		}
		$delete_emp=$this->common->delete_record('tbl_employees',array('id'=>$id));
		//$delete_emp = $this->common->update_record('tbl_employees',array('id'=>$id),array('status'=>0,'is_deleted'=>1));
		if($delete_emp){
			//$this->common->delete_record('tbl_assign_question',array('emp_id'=>$id));
			if (!empty($user['profile_img']) && file_exists(FCPATH . '/assets/images/staff_image/' . $staffinfo->profile_img)) {
				$del_img = FCPATH . '/assets/images/staff_image/' . $staffinfo->profile_img;
				unlink($del_img);
			}
			$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Staff deleted successfully!</p>');
			redirect(base_url('staff/'.$action));
		}else{
			$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
		}
	}
	
	/******Employee self assesment******/
	
	public function self_assesment(){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		if(!in_array('employee/self-assesment',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$employee_id = $this->session->userdata('emp_id');
		$data = array();
		$data['page'] = 'assessment';
		
		if($this->session->userdata('role_id')==3)
			{
				/*----Send review by manager----*/
						/*If Answer is submitted by Employee*/
			if($this->input->post('submit') == 'Self Assesment'){
				/*
				*** $answer - posted answer is in form of array, 
				where Answer array -  
				1 - key : assignment id(primary key of assign question tbl)
				2 - value is corresponding answer for that particular question
				*/
				//echo "<pre>";print_r($this->input->post());die;
				$ans = array();
				$answer = $this->input->post('answer');
				$assign_id = $this->input->post('assign_id');
				$curpage = $this->input->post('curpage');
				$ttl_count = count($assign_id);
				$emp_answer = array();
				foreach($answer as $answ){
					$empty = 1;
					foreach($answ as $val){
						if($val != ''){
							$empty--;
							break;
						}
					}
					if($empty == 0 && !empty($answ)){
						$ans_val = json_encode($answ);
					}else{
						$ans_val = '';
					}
					$ans[] = $ans_val;
				}
				$i=0;
				foreach($assign_id as $val){
					/* $key - Assign id*/
					/* $val - Employee Answer for that particular question*/
					$emp_answer = array(
							   'answer'=> $ans[$i]
							  );
					$query = $this->common->update_record('tbl_teamassign_question',array('assign_id'=>$val),$emp_answer);
					$i++;		  
				}
				//$query = $this->db->update_batch('tbl_assign_question',$emp_answer,'assign_id');
				
				if($query){
					//$download_pdf_url = base_url('employee/genrate_pdf');
					
					$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
					//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
					$totalquestion = $this->qm->num_manager_self_assesment($employee_id,$status=1,$review_status=1);
					if($totalquestion > 1)
					{
						if($curpage > 0)
						{
							$nextpage=$curpage+1;
							if($nextpage < $totalquestion)
							{
							redirect(base_url('employee/questionaire/'.$nextpage.'?'));
							}
							else
							{
								redirect(base_url('employee/questionaire/'.$curpage.'?'));
							}
						}
						else
						{
						redirect(base_url('employee/questionaire/1?'));
						}
					}
					else
					{
						redirect(base_url('employee/questionaire/'));
					}
					
				}else{
					
					$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
					
				}
			}
			/*---pagination of questionory---*/
			$this->load->library('pagination');
			$data['page'] = 'question_list';
			$config['base_url'] = base_url('employee/questionaire');
			$config['total_rows'] = $this->qm->num_manager_self_assesment($employee_id,$status=1,$review_status=1);
			$config['per_page'] = 1;
			$config['uri_segment'] = 3;
			$data['total_rows'] = $config['total_rows'];
			if (isset($_GET)) {
				$config['enable_query_string'] = TRUE;
				$config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config["base_url"] . $config['suffix'];
			}
			$this->pagination->initialize($config);

			$page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
			$data['page_no'] = $page;
			$last_record_per_page = $config["per_page"] + ($data['page_no']);
			if ($data['total_rows'] < $last_record_per_page) {
				$last_record_per_page = $data['total_rows'];
			}
			$data["last_record_per_page"] = $last_record_per_page;
			$data["links"] = $this->pagination->create_links();
			
			/*----end of pagination of questionry---*/
			
			$self_assesment = $this->qm->all_manager_self_assesment($employee_id,$status=1,$review_status=1,$config["per_page"], $page);
			
			
			$data['self_assesment'] = $self_assesment;
			$this->load->view('staff/team_self_assesment',$data);
				/*----End of send review by manager---*/
			
		}
		else
		{
		
		/*If Answer is submitted by Employee*/
		if($this->input->post('submit') == 'Self Assesment'){
			/*
			*** $answer - posted answer is in form of array, 
			where Answer array -  
			1 - key : assignment id(primary key of assign question tbl)
			2 - value is corresponding answer for that particular question
			*/
			//echo "<pre>";print_r($this->input->post());die;
			$ans = array();
			$answer = $this->input->post('answer');
			$assign_id = $this->input->post('assign_id');
			$curpage = $this->input->post('curpage');
			$ttl_count = count($assign_id);
			$emp_answer = array();
			foreach($answer as $answ){
				$empty = 1;
				foreach($answ as $val){
					if($val != ''){
						$empty--;
						break;
					}
				}
				if($empty == 0 && !empty($answ)){
					$ans_val = json_encode($answ);
				}else{
					$ans_val = '';
				}
				$ans[] = $ans_val;
			}
			$i=0;
			foreach($assign_id as $val){
				/* $key - Assign id*/
				/* $val - Employee Answer for that particular question*/
				$emp_answer = array(
						   'answer'=> $ans[$i]
						  );
				$query = $this->common->update_record('tbl_assign_question',array('assign_id'=>$val),$emp_answer);
				$i++;		  
			}
			//$query = $this->db->update_batch('tbl_assign_question',$emp_answer,'assign_id');
			
			if($query){
				//$download_pdf_url = base_url('employee/genrate_pdf');
				
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
					$totalquestion = $this->qm->num_employee_self_assesment($employee_id,$status=1,$review_status=1);
					if($totalquestion > 1)
					{
						if($curpage > 0)
						{
							$nextpage=$curpage+1;
							if($nextpage < $totalquestion)
							{
							redirect(base_url('employee/questionaire/'.$nextpage.'?'));
							}
							else
							{
								redirect(base_url('employee/questionaire/'.$curpage.'?'));
							}
						}
						else
						{
						redirect(base_url('employee/questionaire/1?'));
						}
					}
					else
					{
						redirect(base_url('employee/questionaire/'));
					}
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		/*---pagination of questionory---*/
		$this->load->library('pagination');
		$data['page'] = 'question_list';
		$config['base_url'] = base_url('employee/questionaire');
		$config['total_rows'] = $this->qm->num_employee_self_assesment($employee_id,$status=1,$review_status=1);
		$config['per_page'] = 1;
		$config['uri_segment'] = 3;
		$data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
            $config['enable_query_string'] = TRUE;
            $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config["base_url"] . $config['suffix'];
        }
        $this->pagination->initialize($config);

        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
        $data['page_no'] = $page;
        $last_record_per_page = $config["per_page"] + ($data['page_no']);
        if ($data['total_rows'] < $last_record_per_page) {
            $last_record_per_page = $data['total_rows'];
        }
        $data["last_record_per_page"] = $last_record_per_page;
        $data["links"] = $this->pagination->create_links();
		
		/*----end of pagination of questionry---*/
		
		$self_assesment = $this->qm->all_employee_self_assesment($employee_id,$status=1,$review_status=1,$config["per_page"], $page);
		
		
		$data['self_assesment'] = $self_assesment;
		$this->load->view('staff/self_assesment',$data);
		}
	}
	/*Function to add remarks and download assesement as pdf by manager on employee self assessment*/
	public function review($emp_id){
		
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		
		if(!in_array('employee/review',$role_permission)){
			redirect(base_url('not-authorized'));
		}
		
		$employee_id = $emp_id;
		$data = array();
		$data['page'] = 'assessment';
		$staffinfo=$this->sm->get_staff_by_id($emp_id); 
		if($staffinfo->role_id==3)
		{
			
					/*If Answer is submitted by Manager*/
		if($this->input->post('submit') == 'submit remarks'){
			
			$remarks = $this->input->post('remarks');
			$assign_id = $this->input->post('assign_id');
			$i=0;
			foreach($remarks as $val){
				$query = $this->common->update_record('tbl_teamassign_question',array('assign_id'=>$assign_id[$i],'status'=>1,'review_status'=>2),array('remarks'=>$val));
				$i++;
			}
			
			if($query){
				$blank_remarks = $this->common->get_selected_columns('	tbl_teamassign_question',array('assign_id'),array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id,'remarks'=>''),'multiple');
				$count_blank_remarks = count($blank_remarks);
				if($count_blank_remarks == 0){
					//$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>3));
					$this->common->update_record('tbl_teamassign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>2));
				}
				//$download_pdf_url = base_url('employee/genrate_pdf/'.$emp_id);
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
				//redirect(base_url('employee/review/'.$emp_id));
				redirect(base_url('staff/team leader/'));
				
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		$self_assesment = $this->qm->get_manager_self_assesment($employee_id,$status=1,$review_status=2);
		$data['self_assesment'] = $self_assesment;
		//echo "<pre>";print_r($data);die;
		$this->load->view('staff/team_review_assesment',$data);
		}
		else
		{
		/*If Answer is submitted by Employee*/
		if($this->input->post('submit') == 'submit remarks'){
			
			$remarks = $this->input->post('remarks');
			$assign_id = $this->input->post('assign_id');
			$i=0;
			foreach($remarks as $val){
				$query = $this->common->update_record('tbl_assign_question',array('assign_id'=>$assign_id[$i],'status'=>1,'review_status'=>2),array('remarks'=>$val));
				$i++;
			}
			
			if($query){
				$blank_remarks = $this->common->get_selected_columns('	tbl_assign_question',array('assign_id'),array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id,'remarks'=>''),'multiple');
				$count_blank_remarks = count($blank_remarks);
				if($count_blank_remarks == 0){
					//$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>3));
					$this->common->update_record('tbl_assign_question',array('status'=>1,'review_status'=>2,'emp_id'=>$emp_id),array('review_status'=>2));
				}
				//$download_pdf_url = base_url('employee/genrate_pdf/'.$emp_id);
				$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Thank you for your review!</p>');
				//$this->session->set_flashdata('download_link','<a href="'.$download_pdf_url.'" class="btn btn-primary">Download PDF</a>');
				//redirect(base_url('employee/review/'.$emp_id));
				redirect(base_url('staff/employee/'));
				
				
			}else{
				
				$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some ime!</p>');
				
			}
		}
		$self_assesment = $this->qm->get_employee_self_assesment($employee_id,$status=1,$review_status=2);
		$data['self_assesment'] = $self_assesment;
		//echo "<pre>";print_r($data);die;
		$this->load->view('staff/review_assesment',$data);
		}
	}
	
	/*Function to generate pdf of self assesment*/
	public function genrate_pdf($emp_id=false){
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$employee_id = ($emp_id) ? $emp_id : $this->session->userdata('emp_id');
		/*if employee has been logged in then status will be 2 otherwise 3 in case of manager*/
		$status = ($this->session->userdata('role_id') == 4) ? 2 : 3;
		//$data['self_assesment'] = $this->qm->get_employee_self_assesment($employee_id,$status=1,$review_status=3);
			$staffinfo=$this->sm->get_staff_by_id($emp_id); 
		if($staffinfo->role_id==4)
		{
		$data['self_assesment'] = $this->qm->get_employee_self_assesment($employee_id,$status=1,$review_status=2);
			}
			else
			{
			
				$data['self_assesment'] = $this->qm->get_manager_self_assesment($employee_id,$status=1,$review_status=2);
				
			}
			
		// Load all views as normal
		$html = $this->load->view('self_assesment_pdf',$data,true);
		// Load library
		$this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("self_assesment.pdf");
	}
	
	public function import_staffs_data() {
        $this->common->check_login();
        $this->load->library('Excel');
        $arr['error'] = '';    //initialize image upload error array to empty
//$csv_file = $_FILES['upload_csv']['name'];
        if (isset($_FILES) && !empty($_FILES)) 
		{
            $csv_file = $_FILES['upload_csv']['name'];
            $config['upload_path'] = FCPATH . 'assets/uploads/';
            $config['allowed_types'] = 'csv|xls|xlsx';
            //$config['max_size'] = '2000';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('upload_csv')) {
              $arr['error'] = $this->upload->display_errors();
            } else {
				
                $file_data = $this->upload->data();
                $file_path = FCPATH . 'assets/uploads/' . $file_data['file_name'];
                $my_data = array();
                $header_array = Array
                    ('EmployeeId','FirstName', 'LastName', 'Email', 'Phone', 'Role', 'Manager', 'Photo', 'Password');
                $count = 0;
                $compare = '';
                $arr_max_id = $this->common->get_max_id('tbl_employee_salary_details');
                $insert_id = $arr_max_id['id'] + 1;
//read file from path
                $objPHPExcel = PHPExcel_IOFactory::load($file_path);
// Get Highest Column
                $highestColumm = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn(); // e.g. "EL"
// Get Highest Row
                $highestRow = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();  // e.g. 5
                $highestColumm++;
                for ($row = 1; $row < $highestRow + 1; $row++) {
                    $dataset = array();
                    for ($column = 'A'; $column != $highestColumm; $column++) {
                        $dataset[] = $objPHPExcel->setActiveSheetIndex(0)->getCell($column . $row)->getValue();
                    }
                    $datasets[] = $dataset;
                }
			
				$errorEmp = 0;
				$errorFrDt = 0;
				$errorToDt = 0;
                foreach ($datasets as $csv_array) {
                    if ($count > 0) {
						$employee = $this->common->get_selected_columns('tbl_employees',array('id'),array('email'=>$csv_array[3]),'single',$obj_form=true);
                        if (empty($employee)) {
						
						$manager = $this->common->get_selected_columns('tbl_employees',array('id'),array('employee_id'=>$csv_array[6]),'single',$obj_form=true);
							$createdate1=date("Y-m-d H:i:s");
                            $my_data[] = array(
                                'id' => $insert_id,
                                'employee_id' => (!empty($csv_array[0])) ? ($csv_array[0]) : '',                                
                                'first_name' => (!empty($csv_array[1])) ? ($csv_array[1]) : '',
                                'last_name' => (!empty($csv_array[2])) ? $csv_array[2] : '',
                                'email' => (!empty($csv_array[3])) ? $csv_array[3] : '',
                                'password' => (!empty($csv_array[8])) ? md5($csv_array[8]) : '',
                                'phone' => (!empty($csv_array[4])) ? $csv_array[4] : '',
                                'role_id' => (!empty($csv_array[5])) ? $csv_array[5] : '',
                                'manager_id' => $manager->id,
                                'profile_img' => (!empty($csv_array[7])) ? $csv_array[7] : '',
                                'created_at' => $createdate1,
                                'status' => '1',
                            );
                        } else {
							
								$errorEmp++;
							
                            
                        }
                        $insert_id++;
                    } else {
                        $compare = array_diff($csv_array, $header_array);
                        if (count($compare) > 0) {
                            $this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> We need proper format to upload. Please check your format before uploading!</p>');
                            if (file_exists($file_path)) {
                                unlink($file_path);
                            }
                            break;
                        }
                    }
                    $count++;
                }
				
				$err_msg = '';
				if(!empty($errorEmp)){
					$err_msg = ' and '.$errorEmp.' rows failed to upload due to blank or duplicate Email';
				}
                if (!empty($my_data)) {
                    $this->db->insert_batch('tbl_employees', $my_data);

                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
					
                    $this->session->set_flashdata('message', '<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Staffs Data Imported Successfully'.$err_msg.'!</p>');
                    redirect(base_url('staff/employee'));
                } else {
                    $this->session->set_flashdata('message', '<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> The Csv file you have uploaded is not uploaded'.$err_msg.'!</p>');
					
                    redirect(base_url('staff/employee'));
                }
            }
        }
		$data['role_list'] = $this->sm->get_all_roles();
		$this->load->view('staff/import_staffs_data',$data);
    }
	
	public function questionaire_preview(){
				$this->common->check_login();
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$employee_id = $this->session->userdata('emp_id');
		/*if employee has been logged in then status will be 2 otherwise 3 in case of manager*/
		
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['sumitdb_from']=$row_ass->submi_from;;
					  }
					  else
						{
							
							 $sumitdb_from="";
							  $data['sumitdb_from']="";
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['sumitdb_to']=$row_ass->submi_to;
				}
				else
				{
				
					$sumitdb_to="";
					 $data['sumitdb_to']="";
				}
			}
		
			if($this->session->userdata('role_id')==3)
			{
		
				$data['self_assesment'] = $this->qm->mamanger_questionry($employee_id,$status=1,$from=$sumitdb_from,$todate=$sumitdb_to);
				$this->load->view('staff/team_questionaire_preview',$data);
			}
			else
			{
				$data['self_assesment'] = $this->qm->employee_questionry($employee_id,$status=1,$from=$sumitdb_from,$todate=$sumitdb_to);
				$this->load->view('staff/questionaire_preview',$data);
			}
		
	}

/*------start assessment-------*/
	public function employee_assessment($emp_id){
		/*check whether user is logged in or not*/
		$this->common->check_login();
		
		/*check whether user is authorized to access this page or not*/
		$role_permission = $this->session->userdata('role_permission');
		/* if(!in_array('staff/add',$role_permission)){
			redirect(base_url('not-authorized'));
		} */
	
	
		$data = array();
		$data['emp_id']=$emp_id;
		$salary_detail = array();
		$data['page'] = 'staff';
		if($this->input->post('submit') == 'Add Employee'){
			/*
			Start checking for form validation rules
			*/
			$this->form_validation->set_rules('goalof_1', 'Goal', 'trim|required');
			$this->form_validation->set_rules('currentof_1', 'Current Goal', 'trim|required');
			$this->form_validation->set_rules('goaltype_1', 'Type', 'trim|required');
			
			/*
			End checking for form validation rules
			*/
			if ($this->form_validation->run() == TRUE){
				$post = $this->input->post();
				extract($post);
				$goalof_1 = $this->input->post('goalof_1');
				$currentof_1 = $this->input->post('currentof_1');
				$goaltype_1 = $this->input->post('goaltype_1');
				
				$goalof_2 = $this->input->post('goalof_2');
				$currentof_2 = $this->input->post('currentof_2');
				$goaltype_2 = $this->input->post('goaltype_2');
				
				$goalof_3 = $this->input->post('goalof_3');
				$currentof_3 = $this->input->post('currentof_3');
				$goaltype_3 = $this->input->post('goaltype_3');
				
				
				$emp_id = $this->input->post('emp_id');
				$leader_id=$this->session->userdata('emp_id');
						
					$emp_detail = array(
						'emp_id' => $emp_id,
						'leader_id' => $leader_id,
						'billable_goal' => $goalof_1,
						'billable_current' => $currentof_1,
						'billable_type' => $goaltype_1,
						'nobillable_goal' => $goalof_2,
						'nobillable_current' => $currentof_2,
						'nobillable_type' => $goaltype_2,
						'complete_goal' => $goalof_3,
						'complete_current' => $currentof_3,
						'complete_type' => $goaltype_3,						
						'goal_period' => date('Y-m-d H:i:sa'),
						
					);
										
					//Inserting employee
					$ass_id = $this->common->insert_record('tbl_employee_assessment',$emp_detail);
					if($ass_id){
					
							for($i=0;$i<count($editgoal);$i++){
								if(!empty($editgoal[$i]) && !empty($editgoal_type[$i])){
								$salary_detail[] = array(
									'empasid'=>$ass_id,
									'emp_id'=>$emp_id,
									'leader_id'=>$leader_id,
									'editable_goal'=>$editgoal[$i],
									'editable_type'=>$editgoal_type[$i],
									'editable_date' => date('Y-m-d H:i:sa'),
								);	
								}
							}
						
						if(!empty($salary_detail)){
							$this->db->insert_batch('tbl_employee_assevaluation',$salary_detail);
						}
					
						
						//sendmail($to = $email,$subject = 'Employee Registration',$message,$from = 'testing10@iwesh.com');
						
						$this->session->set_flashdata('message','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Employee Assessment added successfully!</p>');
						redirect(base_url('employee/assessment/'.$emp_id));
					}else{
						$this->session->set_flashdata('message','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Server Error, Please try after some time!</p>');
					}
				
			}
		}
		
		$data['manager_list'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id !='=>$emp_id),'single',$obj=true);
		$data['role_list'] = $this->sm->get_all_roles();
		
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
				$leader_id=$this->session->userdata('emp_id');
				$data['emp_assesment'] = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
			}
		$data['emp_salary'] = $this->qm->employee_salary_detail($emp_id);	
		$this->load->view('staff/employee_assessment',$data);
	}
	
	public function assessmentpdf($emp_id=false){
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['fromdate']=date('F d,Y',strtotime($sumitdb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d,Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_salary_detail($emp_id);
		//$this->load->view('employee_assesment_pdf',$data);
		
		 $html = $this->load->view('emp_assesment_pdf',$data,true);
		// Load library
		$this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_assesment_".$emp_id.".pdf"); 
	}	
/*------end of start assessment---*/
/*------Start Historical data---*/
	public function historicalpdf($emp_id=false){
		$this->common->check_login();
		/*if employee has been logged in then employee id will be session user id otherwise we pass paramenter for employee id*/
		$leader_id= $this->session->userdata('emp_id');
		$emp_id=$emp_id;
		$ass_query=$this->db->query("select * from tbl_open_assessment where CURDATE() >= submi_from AND submi_to >= CURDATE() order by asid desc"); 
		$num_ass=$ass_query->num_rows();
		$data['num_ass']=$num_ass;
	
		if($num_ass > 0)
			{	
					
					$row_ass=$ass_query->row();
					if(!empty($row_ass->submi_from))
					  { 
					
					  $sumitdb_from=$row_ass->submi_from;
					  $data['fromdate']=date('F d,Y',strtotime($sumitdb_from));
					
					  }
					  else
						{
							
							 $sumitdb_from="";
							 
						}
						
				if(!empty($row_ass->submi_to))
				{
					 
					   $sumitdb_to=$row_ass->submi_to;
					   $data['todate']=date('F d,Y',strtotime($sumitdb_to));
				}	  
				else
				{
				
					
					 $sumitdb_to="";
				}
		
		if($this->session->userdata('role_id')==3)
			{
				
				$emp_assesment = $this->qm->employee_assessment_list($emp_id,$leader_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
			
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				$data['leader_name']=$this->session->userdata('first_name').' '.$this->session->userdata('last_name');
			}
		else if($this->session->userdata('role_id')==1)
			{
				$emp_assesment = $this->qm->employee_assessment_list_admin($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
				$data['emp_assesment']=$emp_assesment;
				$data['emp_ashistory'] = $this->qm->employee_assessment_editable($emp_assesment->empasid);
				
				$leader = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_assesment->leader_id),'single',$obj=true);
				$data['leader_name']=$leader->name;
			}
			
	}	

			
		// Load all views as normal
		$data['emp_name'] = $this->common->get_selected_columns('tbl_employees',array('CONCAT(first_name," ",last_name) as name'),array('id ='=>$emp_id),'single',$obj=true);
		$data['emp_salary'] = $this->qm->employee_historical_detail($emp_id,$from=$sumitdb_from,$todate=$sumitdb_to);
		//$this->load->view('employee_assesment_pdf',$data);
		
		 $html = $this->load->view('emp_historical_pdf',$data,true);
		// Load library
		$this->load->library('dompdf_gen');
		// Convert to PDF
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		//$this->dompdf->stream("self_assesment.pdf",array('Attachment'=>0));
		$this->dompdf->stream("employee_historical_".$emp_id.".pdf"); 
	}	
/*------end of Historical data---*/				
}